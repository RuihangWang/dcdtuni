# Actual React physical-facet coalescence experiment

Root clicked the normal React mesh button for isolated Shinaide_Liquid_PhysicalCoalesce_CUA, with base size 0.25 m and eight ranks. The UI returned to its enabled run button after the strict mesh job ended. The source mesh/STL geometry and physics match the prior literal-union experiment; only case and export identity changed.

The full stock checkMesh invocation included allTopology and allGeometry and rejected the mesh: three failed checks, 969 underdetermined cells, 100 low-weight faces and two low-volume-ratio faces. Skew failures are zero; 763 nonorthogonal faces remain. No solver was started and the experimental operators remain OFF by default.

The normal click-to-first-observed completion is a conservative 183.296 s upper bound, including React preparation/export and mesh/check work. Native generation reported 141.139 s. Exact backend monotonic timing was not captured and these scopes must not be conflated.

The operator accepted 164 bounded two-cell unions: 131 qualified exact-axis physical-facet joins and 33 literal-shell joins. Its maximum measured per-rank total was 0.280076 s; cache, census and local maxima are independently reduced values and are not additive. Independent written reconstruction of all 164 records is still pending; neither local acceptance nor reduced failure counts constitute a full quality pass.

The raw archive holds 216 source/written diagnostic and core polyMesh/zone payloads (1,697,519,885 bytes), with every extracted payload SHA verified. Native binary and source archives, actual UI observations, all accepted JSONL records, quality sets, full SSE and stdout are retained. Main must rebuild/relink the AIR-path native artifacts before worktree cleanup.
