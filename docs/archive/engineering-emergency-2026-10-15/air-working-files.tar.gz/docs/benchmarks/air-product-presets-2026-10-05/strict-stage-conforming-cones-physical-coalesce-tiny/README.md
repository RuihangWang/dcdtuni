# Physical same-source-facet operator: MPI2 API regression

Job `198308e1` used the production server's real React exporter, closed its owned software browser, then ran the normal mesh API with two ranks. The source is exactly b1e1411 and the library is c739b642; the application hash remains 533086 because its source did not change. Only owned ports 8394/8395 were restarted, with CUDA visibility empty and CPU affinity 8–15.

The complete `checkMesh -allTopology -allGeometry -parallel` output reports Mesh OK, 511 cells, no failed checks and no warnings. The mesh identity is byte-identical to the prior strictly accepted 511-cell channel. Export took 19.898782 seconds, browser close 4.996347, mesh API 3.075214 and the complete recorded sequence 28.445497 seconds. Native generation took 0.040346141 seconds.

The literal operator examined and accepted zero pairs; the new physical operator tried and accepted zero and all six refusal counters are zero. This is a real standard lifecycle regression, not coverage of the positive union/coalescence path. The separate current large-case offline stencil proves that positive mathematical candidate; only a subsequent actual full-case run can verify the compiled acceptance path. No solver or full-case native job was launched here.

The actual one processor pair has 64 faces per side, exact relative polygons, point zero and same-start reverse order, with zero mismatches and zero coordinate distance. This fixture has no cyclic or processorCyclic faces and does not prove those categories. All raw case payloads and compiled-source/build/ldd identities are archived and hash verified. No default experimental flag was promoted.
