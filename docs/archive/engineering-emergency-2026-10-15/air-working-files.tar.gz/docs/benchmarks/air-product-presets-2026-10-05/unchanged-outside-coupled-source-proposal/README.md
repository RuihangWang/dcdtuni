# Unchanged outside coupled source proposal

This is a source-only, default-OFF experiment. The current target remains rejected by stock checkMesh -allTopology -allGeometry: 969 determinant cells, 100 low-weight faces, 2 low-volume-ratio faces and 763 non-orthogonal faces; skew failures are zero. No solver seed is authorized from this result.

## Exact scope

The existing fixed two-child union still forbids a coupled cavity or a changed coupled face. The proposal permits a processor, processorCyclic or cyclic face on a complete outside cell only when its finite local CC/V representations, ordered point IDs and coordinates, first point, Sf/FC, owner/neighbour, patch/zone/type all remain bit-exact. Unknown coupling types, nonfinite values, any bit change, and changed cavity interfaces are refused. In particular, scalar equality does not stand in for DP-byte equality: +0/-0 differ and equal NaN/Inf payloads fail.

No remote CC/V is guessed or evaluated as a physical boundary. The statement is an equality argument: the unchanged local inputs retain the old interface metric for unchanged remote inputs. All ranks enforce the same rule. Actual written CC/V and reciprocal interface rings must still be checked, because this source preflight does not prove the writer's final accumulation order.

The one unconditional end-of-local-work gather now has 21 entries rather than 19. There is no candidate-loop collective. The 1024-pair/rank, two-round bound and original thresholds are unchanged. The new log counts accepted candidates with unchanged-outside certificates and unsupported/nonfinite/unequal certificate refusals; it does not describe all rejected candidates.

## Two independently reconstructed candidates

The complete original-family and outside-cell fixtures are in the two physical-candidate-parent*-input.json files. The independent full-stencil results preserve all original nodes, role identities, volumes/moments and every inherited passing role.

| Diagnostic source parent | Minimum D | Minimum weight | Minimum volume ratio | Maximum skew | Maximum non-orthogonality |
| --- | ---: | ---: | ---: | ---: | ---: |
| 636463 | 0.0609588452 | 0.3584642173 | 0.2103212770 | 0.3639152031 | 62.0215995° |
| 615045 | 0.0844018421 | 0.3584642173 | 0.2103212770 | 0.3633177443 | 53.1006603° |

Each has one processor and one cyclic outside face whose local states are unchanged. Their own cavities have no coupled faces. The existing unconditional outside-coupled veto would refuse each if examined; the current raw log does not prove that a particular unaccepted pair was examined before the attempt cap. The source has no parent/cell/face/case-ID specialization.

The 13 pure fixtures include these two actual positives, first-point rotation and ring reversal, one-ULP coordinate and volume differences, patch and zone identity, unknown coupling, cavity ownership, signed zero and nonfinite representations. portable-pure-tests.log was run from this evidence directory with only its bundled readers. These tests do not execute native C++.

## Stock coplanarity distinction

The subdivided-box JSON and primary source copies show why restoring a mathematically convex original mother is insufficient. Installed primitiveMeshCheck.C treats distinct coplanar face centres as concave-or-planar (normalized dot 0 exceeds -1e-6), and the full-geometry check caller increments its failed-check count. A seven-facet subdivided unit box is mathematically convex and closed but triggers this specific stock predicate. This was a pure geometry/source audit, not a native checkMesh invocation. Faces against distinct outside neighbours were not merged.

## Frozen identity and remaining validation

source-identity.json binds the exact b1 source, proposal source, incremental patch and unchanged APP/lib bytes. Both source snapshots are preserved as deterministic gzip payloads. The b1 APP/lib are still being used for root cancellation validation and have not been rebuilt.

No new native run, service action, browser action, git index update or default promotion occurred. native-validation-plan.md describes the next required positive native path and the strict limits on its claims.
