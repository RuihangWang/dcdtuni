import copy
import sys
from pathlib import Path
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parent))
import unchanged_coupled_guard as g

def context():
 return g.build(636463)[2:]

def test_actual_coupled_outside_equality():
 doc,candidate,cells=context()
 r=g.coupled_equivalence(doc,candidate,cells)
 assert r["allPass"] and len(r["coupledFaces"])==2

def test_actual_other_physical_candidate_equality():
 doc,candidate,cells=g.build(615045)[2:]
 r=g.coupled_equivalence(doc,candidate,cells)
 assert r["allPass"] and len(r["coupledFaces"])==2

def test_first_point_rotation_is_refused():
 doc,candidate,cells=context()
 r=g.coupled_equivalence(doc,candidate,cells);f=r["coupledFaces"][0]["face"]
 bad=copy.deepcopy(candidate);p=bad["faces"][str(f)]["pointIDs"]
 bad["faces"][str(f)]["pointIDs"]=p[1:]+p[:1]
 assert not g.coupled_equivalence(doc,bad,cells)["allPass"]

def test_one_ulp_coordinate_move_is_refused():
 doc,candidate,cells=context()
 p=g.coupled_equivalence(doc,candidate,cells)["coupledFaces"][0]["pointIDs"][0]
 bad=copy.deepcopy(candidate)
 bad["points"][str(p)][0]=float(np.nextafter(bad["points"][str(p)][0],np.inf))
 assert not g.coupled_equivalence(doc,bad,cells)["allPass"]

def test_one_ulp_owner_volume_is_refused():
 assert not g.bit_equal(1.,np.nextafter(1.,np.inf))

def test_patch_identity_change_is_refused():
 doc,candidate,cells=context();f=g.coupled_equivalence(doc,candidate,cells)["coupledFaces"][0]["face"]
 bad=copy.deepcopy(candidate);bad["faces"][str(f)]["patch"]["name"]="different"
 assert not g.coupled_equivalence(doc,bad,cells)["allPass"]


def test_equal_nan_payload_is_refused():
 assert not g.bit_equal(float("nan"),float("nan"))

def test_equal_infinity_is_refused():
 assert not g.bit_equal(float("inf"),float("inf"))

def test_signed_zero_representation_is_refused():
 assert not g.bit_equal(0.,-0.)

def test_zone_identity_change_is_refused():
 doc,candidate,cells=context();f=g.coupled_equivalence(doc,candidate,cells)["coupledFaces"][0]["face"]
 bad=copy.deepcopy(candidate);bad["faces"][str(f)]["zone"]=1
 assert not g.coupled_equivalence(doc,bad,cells)["allPass"]

def test_unknown_coupled_kind_is_refused_even_unchanged():
 doc,candidate,cells=context();f=g.coupled_equivalence(doc,candidate,cells)["coupledFaces"][0]["face"]
 old=copy.deepcopy(doc);new=copy.deepcopy(candidate)
 old["faces"][str(f)]["patch"]["type"]="cyclicAMI"
 new["faces"][str(f)]["patch"]["type"]="cyclicAMI"
 assert not g.coupled_equivalence(old,new,cells)["allPass"]

def test_changed_cavity_owner_cannot_use_unchanged_certificate():
 doc,candidate,cells=context()
 owner=g.coupled_equivalence(doc,candidate,cells)["coupledFaces"][0]["cell"]
 assert not g.coupled_equivalence(doc,candidate,cells,{owner})["allPass"]

def test_reversed_ring_is_refused():
 doc,candidate,cells=context();f=g.coupled_equivalence(doc,candidate,cells)["coupledFaces"][0]["face"]
 bad=copy.deepcopy(candidate);p=bad["faces"][str(f)]["pointIDs"]
 bad["faces"][str(f)]["pointIDs"]=[p[0]]+p[:0:-1]
 assert not g.coupled_equivalence(doc,bad,cells)["allPass"]
