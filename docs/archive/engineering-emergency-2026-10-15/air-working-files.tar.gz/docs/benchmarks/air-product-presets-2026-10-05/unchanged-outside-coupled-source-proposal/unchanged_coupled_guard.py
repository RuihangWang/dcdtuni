"""Pure local equality certificate for unmodified coupled faces; no native edit."""
from pathlib import Path
import sys,json,copy,hashlib
import numpy as np
E=Path(__file__).resolve().parent
sys.path.insert(0,str(E/"readers"))
import audit_air_cone_small_union_independent as I

def bit_equal(a,b):
 aa=np.asarray(a,dtype=np.float64);bb=np.asarray(b,dtype=np.float64)
 return aa.shape==bb.shape and np.isfinite(aa).all() and np.isfinite(bb).all() and np.array_equal(aa.view(np.uint64),bb.view(np.uint64))

def coupled_equivalence(doc,candidate,affected,cavity=()):
 old=I.WrittenStencil(doc,doc["originalApex"])
 new=I.WrittenStencil(candidate,candidate["originalApex"])
 rows=[]
 for c in sorted(affected):
  for f in old.cells[c]["faces"]:
   before=old.faces[f];patch=before["patch"]
   if not patch or not any(x in patch["type"].lower() for x in ("processor","cyclic","mapped","ami")):continue
   after=new.faces.get(f)
   oldg=old.cell(c);newg=new.cell(c)
   sf,fc=old.face(f);ns,nf=new.face(f) if after else (None,None)
   coords_same=bool(after and all(bit_equal(old.points[p],new.points[p]) for p in before["pointIDs"]))
   same={"supportedType":patch["type"] in ("processor","processorCyclic","cyclic"),
    "outsideCavityOwner":before["owner"] not in cavity,
    "sameFaceRolesPointIDsPatchZoneBase":after==before,
    "samePointCoordinates":coords_same,"sameFirstPoint":bool(after and after["pointIDs"][0]==before["pointIDs"][0]),
    "sameAreaVector":bit_equal(sf,ns) if ns is not None else False,
    "sameFaceCentre":bit_equal(fc,nf) if nf is not None else False,
    "sameOwnerCellCentre":bit_equal(oldg[2],newg[2]),
    "sameOwnerCellVolume":bit_equal(oldg[3],newg[3])}
   rows.append({"cell":c,"face":f,"patch":patch,"checks":same,"passes":all(same.values()),
    "pointIDs":before["pointIDs"],"pointCoordinates":[old.points[p].tolist() for p in before["pointIDs"]],
    "Sf":sf.tolist(),"FC":fc.tolist(),"oldCC":oldg[2].tolist(),"newCC":newg[2].tolist(),"oldV":oldg[3],"newV":newg[3]})
 return {"scope":"Exact own-side equivalence for unaffected coupled facets; no remote CC/V guessed. Both ranks must apply this condition to any coupled-cell moment change before local acceptance.",
  "allPass":all(x["passes"] for x in rows),"coupledFaces":rows,
  "algebra":"Unchanged SF,FC,ownCC,ownV and identical coupled polygon/role make stock W/R/N/S identical for every unchanged remote CC/V. Candidate cells themselves may not own coupled facets. All ranks retain the same rule; their coupled owners are therefore unchanged on both sides."}

def build(parent):
 raw=json.loads((E/f"physical-candidate-parent{parent}-input.json").read_text())
 r=json.loads((E/f"physical-candidate-parent{parent}-full-stencil.json").read_text())
 doc=I.labelled_input(raw);candidate,_,outer=I.union_document(doc,r["group"])
 candidate,_,_=I.coalesce_physical_faces(candidate,r["joinedPhysicalOutline"]["originalFaces"],min(r["group"]))
 candidate,_=I.canonicalize_internal_roles(candidate)
 affected=set(r["group"])
 for f in outer:
  row=doc["faces"][str(f)]
  for c in (row["owner"],row["neighbour"]):
   if c is not None:affected.add(c)
 # Removed group member is not an outside coupled owner and cannot be queried.
 affected-=set(r["group"])-{min(r["group"])}
 return raw,r,doc,candidate,affected

def main():
 out=[]
 for parent in (636463,615045):
  raw,r,doc,candidate,affected=build(parent)
  proof=coupled_equivalence(doc,candidate,affected,r["group"])
  proof.update(parent=parent,group=r["group"],affectedCells=sorted(affected),
    completeGeometryPass=r["passesCandidateGeometry"],
    fullFiveMetricLineagePass=r["passesFullFamilyFiveMetricLineagePareto"],
    absoluteFiveMetricPass=r["passesAllFiveAbsoluteLocalQuality"],metrics=r["metrics"],
    nativeAcceptance=False,
    inputSha256=hashlib.sha256((E/f"physical-candidate-parent{parent}-input.json").read_bytes()).hexdigest())
  out.append(proof)
  print(json.dumps({"parent":parent,"coupledFaces":len(proof["coupledFaces"]),"allPass":proof["allPass"]}),flush=True)
 (E/"unchanged-coupled-physical-candidates.json").write_text(json.dumps(out,indent=2)+"\n")
if __name__=="__main__":main()
