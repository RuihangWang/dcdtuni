from pathlib import Path,PurePosixPath
from concurrent.futures import ThreadPoolExecutor
from collections import Counter
from datetime import datetime,timezone
import json,os,time,re,hashlib,tarfile,io,zlib
N=Path('/mnt/lv/home/litianyu/mycode/dcdtuni/.codex-tmp/fresh-fe-unfiltered-final-20261007')
B=Path('/mnt/lv/home/litianyu/mycode/dcdtuni');C=N/'dcdtuni';FE=C/'src/frontend/react'
L=N/'full-suite-v3';BD=N/'production-build-v3';OLD=N/'FROZEN-FINAL-PUBLIC-FE-v1';F=N/'FINAL-FE-PASS-v3'
S='e9ec16b9bef7ef02ed226e74cd2963cdba1025f5';OLDHASH='bc8d4aebcfc41e9445aaa6299b299a51ef2be02bba2415f3178f481a691db7f2'
os.sched_setaffinity(0,{28,29});start=time.monotonic();created=datetime.now(timezone.utc).isoformat()
def digest(b):return hashlib.sha256(b).hexdigest()
def load(p):return json.loads(p.read_bytes())
def desc(p):b=p.read_bytes();return {'bytes':len(b),'sha256':digest(b)}
def safe(rel):
 r=PurePosixPath(rel);assert rel and not r.is_absolute() and '..' not in r.parts;return r
def write(name,obj):(F/name).write_text(json.dumps(obj,indent=2,ensure_ascii=True)+'\n')
assert N.resolve().is_relative_to(B.resolve()) and not F.exists()
assert desc(OLD/'MANIFEST.json')['sha256']==OLDHASH
oldm=load(OLD/'MANIFEST.json');oldbefore={'MANIFEST.json':desc(OLD/'MANIFEST.json')}
for name,d in oldm['payload'].items():
 assert desc(OLD/name)==d;oldbefore[name]=desc(OLD/name)
oldrec=load(OLD/'ACTUAL-VALIDATION-RECEIPT.json')
assert oldrec['status']=='TIMEOUT' and oldrec['suite']['rc']==-15 and oldrec['suite']['capSeconds']==600 and not oldrec['suite']['finalJsonAvailable']
author=load(N/'AUTHORIZED-PUBLIC-COMMIT-v3.json')
assert author['expectedPublicCommit']==S and author['suiteRunAuthorized'] and author['newTimeoutSeconds']==1200
run=load(L/'actual-run-result.json');build=load(BD/'actual-run-result.json');ctl=load(N/'root-full-controller-v3/controller.json')
j=load(L/'vitest.json');saved=load(L/'vitest-counters.json')
assert run['publicSha']==build['publicSha']==ctl['publicSha']==S
assert run['rc']==build['rc']==0 and not run['timedOut'] and not build['timedOut']
assert run['timeoutSeconds']==ctl['suiteCapSeconds']==1200 and build['timeoutSeconds']==ctl['meshCapSeconds']==300
assert run['allowedCpus']==build['allowedCpus']==[40,41,42,43]
assert run['environment']['CUDA_VISIBLE_DEVICES']==build['environment']['CUDA_VISIBLE_DEVICES']==''
assert run['unfiltered'] and run['ordinaryRepoConfig'] and not run['fixtureOverrides'] and run['maxWorkers']==run['minWorkers']==1
assert run['argv'][6:]==['run','--maxWorkers=1','--minWorkers=1','--reporter=default','--reporter=json','--outputFile='+str(L/'vitest.json')]
assert build['argv'][5:]==['run','build'] and build['ordinaryRepoBuild']
assert build['suiteResultSha256']==desc(L/'actual-run-result.json')['sha256']
assert build['suiteSourceParitySha256']==desc(L/'source-parity.json')['sha256'] and build['sourceEqualToPassedSuite']
raw={}
for d in [L,BD]:
 for name in ['stdout','stderr','time.txt']:
  raw[(d.name,name)]=(d/name).read_bytes().decode('utf-8')
  if name=='time.txt':assert '\tExit status: 0\n' in raw[(d.name,name)]
files=j['testResults'];assert len(files)==len({r['name'] for r in files})==442
aa=[a for r in files for a in r['assertionResults']];ast=Counter(a['status'] for a in aa)
assert len(aa)==4388 and ast==Counter({'passed':4384,'skipped':4})
assert j['success'] and j['numTotalTests']==4388 and j['numPassedTests']==4384 and j['numPendingTests']==4 and j['numFailedTests']==j['numTodoTests']==0
assert j['numTotalTestSuites']==j['numPassedTestSuites']==1325 and j['numFailedTestSuites']==j['numPendingTestSuites']==0
assert saved=={k:j[k] for k in saved} and load(L/'failures.json')==[]
assert all(r['status']=='passed' and not r['message'] and r['assertionResults'] for r in files)
assert all(not a['failureMessages'] for a in aa)
frows=[]
for r in files:
 rel=Path(r['name']).relative_to(FE).as_posix();safe(rel);st=Counter(a['status'] for a in r['assertionResults'])
 frows.append({'file':rel,'jsonFileStatus':r['status'],'assertions':len(r['assertionResults']),'statuses':dict(st),'allSkipped':st['skipped']==len(r['assertionResults']),'startTime':r['startTime'],'endTime':r['endTime'],'skipped':[a['fullName'] for a in r['assertionResults'] if a['status']=='skipped']})
rep={}
for line in raw[(L.name,'stdout')].splitlines():
 m=re.match(r'^ ([\u2713\u2193]) (test/\S+) \((\d+) tests?(?: \| (\d+) skipped)?\)',line)
 if m:
  symbol,name,total,skip=m.groups();assert name not in rep
  rep[name]={'symbol':symbol,'tests':int(total),'skipped':int(skip or 0),'rawLine':line}
assert len(rep)==442 and Counter(v['symbol'] for v in rep.values())==Counter({'\u2713':439,'\u2193':3})
for r in frows:
 a=rep[r['file']];assert a['tests']==r['assertions'] and a['skipped']==r['statuses'].get('skipped',0)
 assert (a['symbol']=='\u2193')==r['allSkipped']
assert re.search(r'Test Files\s+439 passed \| 3 skipped \(442\)',raw[(L.name,'stdout')])
assert re.search(r'Tests\s+4384 passed \| 4 skipped \(4388\)',raw[(L.name,'stdout')])
assert 'JSON report written to '+str(L/'vitest.json') in raw[(L.name,'stdout')]
maps={};receipts=[]
for d in [L,BD]:
 par=load(d/'source-parity.json');assert par['sourceHeld'] and par['changedEntries']==[]
 for label in ['before','after']:
  rows=load(d/(label+'-source.json'));rec=load(d/(label+'-source-receipt.json'))
  assert len(rows)==rec['trackedEntries']==20819 and rec['head']==S and rec['status']=='?? src/frontend/react/node_modules\n'
  assert rec['regularFiles']==20815 and rec['symlinks']==4 and rec['trackedBytes']==1358923355
  assert sum(x['bytes'] for x in rows.values())==rec['trackedBytes'] and Counter(x['type'] for x in rows.values())==Counter({'regular':20815,'symlink':4})
  idx={}
  for record in (d/(label+'-git-index.raw')).read_bytes().split(b'\0'):
   if not record:continue
   ent,path=record.split(b'\t',1);mode,blob,stage=ent.decode().split();rel=path.decode();safe(rel);assert stage=='0' and rel not in idx
   idx[rel]=(mode,blob)
  assert set(idx)==set(rows)
  for rel,x in rows.items():
   safe(rel);assert idx[rel]==(x['gitMode'],x['gitBlob']) and re.fullmatch('[0-9a-f]{64}',x['sha256'])
   assert x['bytes']>=0 and re.fullmatch('0o[0-7]+',x['actualMode'])
  maps[d.name+'/'+label]=rows;receipts.append({'path':d.name+'/'+label,'receipt':rec,'manifest':desc(d/(label+'-source.json')),'rawIndex':desc(d/(label+'-git-index.raw'))})
base=next(iter(maps.values()));assert all(x==base for x in maps.values())
mods=FE/'node_modules';assert mods.is_symlink() and mods.resolve()==(N/'npm-environment/node_modules').resolve()
head=(C/'.git/HEAD').read_text().strip();assert head==S
gitbefore={'HEAD':desc(C/'.git/HEAD'),'index':desc(C/'.git/index')}
def current_one(item):
 rel,x=item;q=C/rel
 if x['type']=='symlink':
  assert q.is_symlink();b=os.readlink(q).encode();mode=oct(q.lstat().st_mode&0o777)
  assert len(b)==x['bytes'] and digest(b)==x['sha256'] and mode==x['actualMode'] and b.decode()==x['literalTarget'],rel
 else:
  assert q.is_file() and not q.is_symlink() and q.resolve().is_relative_to(C.resolve());mode=oct(q.stat().st_mode&0o777)
  h=hashlib.sha256();size=0
  with q.open('rb') as f:
   for b in iter(lambda:f.read(1048576),b''):h.update(b);size+=len(b)
  assert size==x['bytes'] and h.hexdigest()==x['sha256'] and mode==x['actualMode'],rel
 return rel
ht=time.monotonic()
with ThreadPoolExecutor(max_workers=2) as pool:verified=list(pool.map(current_one,base.items()))
hashsecs=time.monotonic()-ht;assert len(verified)==20819
for name,p in author['packageByteGuardsHeld'].items():
 expected={'bytes':p['bytes'],'sha256':p['sha256']}
 assert desc(FE/name)==desc(N/'npm-environment'/name)==expected
sp=load(L/'owned-process.json');bp=load(BD/'owned-process.json')
assert sp['pid']==sp['pgid']==919883 and bp['pid']==bp['pgid']==950765 and ctl['pid']==919441
ids={ctl['pid'],sp['pid'],bp['pid']}
def proc_observation():
 matches=[];scanned=0
 for p in Path('/proc').iterdir():
  if not p.name.isdigit():continue
  try:
   tail=(p/'stat').read_text().rsplit(')',1)[1].split();pid=int(p.name);pgid=int(tail[2]);sid=int(tail[3]);scanned+=1
   if pid in ids or pgid in ids or sid in ids:matches.append({'pid':pid,'pgid':pgid,'sid':sid,'state':tail[0],'startTicks':tail[19]})
  except (FileNotFoundError,ProcessLookupError,PermissionError):continue
 return {'observedUTC':datetime.now(timezone.utc).isoformat(),'scannedStatRecords':scanned,'matches':matches}
gone=proc_observation();assert not gone['matches']
dist=FE/'dist';logged={}
for line in raw[(BD.name,'stdout')].splitlines():
 m=re.match(r'^dist/(\S+)\s+([\d,]+\.\d+) kB(?: \u2502 gzip:\s+([\d,]+\.\d+) kB)?',line)
 if m:logged[m[1]]={'displayedKB':float(m[2].replace(',','')),'gzipKB':None if m[3] is None else float(m[3].replace(',','')),'rawLine':line}
dfiles=sorted(q for q in dist.rglob('*') if q.is_file());assert len(dfiles)==len(logged)==11 and all(not q.is_symlink() for q in dfiles)
assert set(logged)=={q.relative_to(dist).as_posix() for q in dfiles}
drows=[]
for q in dfiles:
 rel=q.relative_to(dist).as_posix();b=q.read_bytes();units=len(b.decode().encode('utf-16-le'))//2;display=logged[rel];methods=[]
 if abs(display['displayedKB']*1000-len(b))<=5.1:methods.append('UTF8-bytes')
 if abs(display['displayedKB']*1000-units)<=5.1:methods.append('UTF16-code-units')
 assert methods,rel
 co=zlib.compressobj(level=-1,wbits=31);gz=co.compress(b)+co.flush()
 if display['gzipKB'] is not None:assert abs(display['gzipKB']*1000-len(gz))<=5.1,rel
 mt=q.stat().st_mtime;assert bp['startWallUnix']-1<=mt<=bp['startWallUnix']+build['elapsedS']+1
 drows.append({'path':q.relative_to(N).as_posix(),**desc(q),'mode':oct(q.stat().st_mode&0o777),'mtimeUnix':mt,'utf16CodeUnits':units,'gzipBytesDefaultZlib':len(gz),'log':display,'sizeDisplayCompatibleWith':methods})
refs=re.findall(r'(?:src|href)="/(assets/[^"]+)"',(dist/'index.html').read_text());assert len(refs)==2 and all(x in logged for x in refs)
hy=L/'hybrid-artifacts';hfiles=sorted(q for q in hy.rglob('*') if q.is_file())
assert {q.name for q in hfiles}=={'after.liquidrun','after.cfdrun','before.cfdrun','frontend-report.json'} and all(not q.is_symlink() for q in hfiles)
hr=load(hy/'frontend-report.json');printed=[json.loads(x.split(' ',1)[1]) for x in raw[(L.name,'stdout')].splitlines() if x.startswith('SHINAIDE_CROSS_COMPILER ')]
assert printed==[hr] and hr['scope']=='CPU pure export/geometry contract; no WebGL renderer, mesh, CFD or DAE solve'
assert hr['source_sha256']==base['case/Shinaide_Liquid/Shinaide_liquid.cfdproj']['sha256']
hrows=[]
for q in hfiles:hrows.append({'path':q.relative_to(N).as_posix(),**desc(q),'mode':oct(q.stat().st_mode&0o777),'jsonRootType':type(load(q)).__name__})
vjson=N/'npm-environment/node_modules/vitest/dist/chunks/index.DsZFoqi9.js';vvite=N/'npm-environment/node_modules/vite/dist/node/chunks/dep-BK3b2jBa.js'
v1=vjson.read_text().splitlines();v2=vvite.read_text().splitlines()
assert 'const suites = getSuites(files);' in '\n'.join(v1[4300:4398]) and 'size: chunk.code.length,' in '\n'.join(v2[17900:17955])
lfs=load(N/'lfs-prepare-v2/receipt.json');assert lfs['publicSha']==S and lfs['frontendEntries']==79 and lfs['frontendAllPayloadOidVerified']
F.mkdir()
write('AUTH-SCOPE.json',{'kind':'read-only independent archival authorization','source':'Parent /root messages in this task, 2026-10-08 SGT','instruction':'Freeze FINAL-FE-PASS-v3 in N from complete actual JSON/raw receipts; no tracked/Git/service/browser/Kit/GPU/native modifications or new suite/build run; preserve prior600 TIMEOUT','suiteAuthorizationRaw':str(N/'AUTHORIZED-PUBLIC-COMMIT-v3.json'),'secondAttemptSameCloneAndNpmEnvironment':True,'mesh300Unchanged':True,'fullGoalComplete':False})
write('TEST-FILE-RESULTS.json',{'fileRecords':442,'reporterPassedFiles':439,'reporterAllSkippedFiles':3,'jsonFileStatuses':dict(Counter(r['status'] for r in files)),'assertionCounters':dict(ast),'reportedSuiteGroups':1325,'suiteGroupsAreNotFiles':True,'fileRows':sorted(frows,key=lambda x:x['file']),'completeOriginalJsonRetainedInArchive':True})
write('SOURCE-AUDIT.json',{'publicSha':S,'fourRecordedMapsEqual':True,'trackedEntries':20819,'regularFiles':20815,'literalSymlinks':4,'trackedBytes':1358923355,'maps':receipts,'currentDiskAllTrackedVerified':True,'currentDiskHashElapsedS':hashsecs,'currentHeadLiteral':head,'expectedOnlyStatus':'?? src/frontend/react/node_modules\n','dependencyLinkLiteral':os.readlink(mods),'gitHeadAndIndexUnchangedDuringArchival':True,'sourceOrGitCommandsExecutedByArchivalUtility':False})
write('PROCESS-GONE.json',{'method':'Read /proc/*/stat; check all recorded exact PID, PGID and SID values. No signalling, service or environment access.','controller':ctl,'suiteOwned':sp,'buildOwned':bp,'observation':gone,'allOwnedPidGroupSessionValuesAbsent':True,'parentStatement':'Root reports exec session7850 closed RC0; archival utility does not have independent access to that session result.'})
write('BUILD-ARTIFACTS.json',{'ordinaryCommand':'npm run build => tsc -b && vite build','actualRc':0,'elapsedS':build['elapsedS'],'loggedVitePhaseSeconds':11.12,'artifactCount':11,'artifactBytes':sum(x['bytes'] for x in drows),'allLogNamesAndSizesAndGzipAgreeWithActual':True,'allMtWithinActualBuildInterval':True,'indexHtmlLocalAssetRefs':refs,'sizeNote':'Vite uses JS chunk.code.length (UTF16 code units), asset.source.length; UTF8 disk bytes can differ. Disk hashes and bytes are authoritative for frozen members.','artifacts':drows})
write('HYBRID-ARTIFACTS.json',{'actualNewOutputDirectory':str(hy),'artifactCount':len(hrows),'artifactBytes':sum(x['bytes'] for x in hrows),'completePrintedReportEqualsArtifact':True,'sourceShaMatchesHeldSource':True,'printedReport':hr,'members':hrows,'stlPayloadFilesPresent':False,'scope':'Only the four actual v3 output files are copied. Printed13 STL hashes remain report observations; absent STL payloads are not invented.'})
write('PRIOR600-IMMUTABLE.json',{'path':str(OLD),'manifestSha256':OLDHASH,'status':'TIMEOUT','actualRc':-15,'capSeconds':600,'finalJsonAvailable':False,'allOriginalPacketPayloadsBefore':oldbefore,'allOriginalPacketPayloadsHeldAfter':True,'originalArchiveNotDuplicatedOrRewritten':True})
write('RAW-LOG-AUDIT.json',{'allOriginalLogBytesRead':True,'suiteStdoutLines':len(raw[(L.name,'stdout')].splitlines()),'suiteStderrLines':len(raw[(L.name,'stderr')].splitlines()),'buildStdoutLines':len(raw[(BD.name,'stdout')].splitlines()),'buildStderrLines':len(raw[(BD.name,'stderr')].splitlines()),'defaultReporterRows':rep,'suiteTimeExitStatus':0,'buildTimeExitStatus':0,'warningsPreserved':'Suite stderr retains jsdom canvas, act, reused console.time labels, parse-refusal output. Suite stdout includes an SDK-mock failure diagnostic in a passed input test. Build stderr retains default-export notices, mixed import and chunk-size warnings. RC0 is not warning-free.'})
(F/'PRIMARY-REPORTER-EXCERPTS.txt').write_text(str(vjson)+' SHA256='+desc(vjson)['sha256']+'\nLines4301-4398\n'+'\n'.join(v1[4300:4398])+'\n\n'+str(vvite)+' SHA256='+desc(vvite)['sha256']+'\nLines17901-17955\n'+'\n'.join(v2[17900:17955])+'\n')
selected=[]
for name in ['AUTHORIZED-PUBLIC-COMMIT-v3.json','AUTHORIZED-PUBLIC-COMMIT.json','PREPARE-PLAN.json','PACKAGE-LOCK-PREPARE-BINDING.json','FULL-SUITE-GUARD-CORRECTION-v2.json','LFS-SCOPE-FIRST-REFUSAL.json','D-GUARD-FIRST-REFUSAL.json','RUN_FULL_UNFILTERED-v3.py','RUN_FULL_UNFILTERED-v2.py','RUN_FULL_UNFILTERED-initial.py','RUN_FULL_UNFILTERED.py','RUN_PRODUCTION_BUILD_IF_PASS-v3.py','RUN_PRODUCTION_BUILD_IF_PASS.py','FREEZE_FINAL_VALIDATION.py','FREEZE_FINAL_FE_PASS_v3.py','FROZEN-FINAL-PUBLIC-FE-v1-INDEPENDENT-REOPEN.json']:
 q=N/name;assert q.is_file(),name;selected.append(q)
for dirname in ['clone-prepare','npm-prepare','public-source-prepare','lfs-prepare','lfs-prepare-v2','root-full-controller-v3','full-suite-v3','production-build-v3','FROZEN-PREPARE-v1']:
 d=N/dirname;assert d.is_dir()
 for q in sorted(d.rglob('*')):
  if q.is_file() and 'tmp' not in q.relative_to(d).parts:
   assert not q.is_symlink();selected.append(q)
for name in ['package.json','package-lock.json']:selected.append(N/'npm-environment'/name)
for name in ['MANIFEST.json','REPORT.md','ACTUAL-VALIDATION-RECEIPT.json','ARCHIVE-MEMBERS.json']:selected.append(OLD/name)
for rel in ['AGENTS.md','src/frontend/react/vite.config.ts','src/frontend/react/package.json','src/frontend/react/package-lock.json']:selected.append(C/rel)
selected.extend(dfiles);selected=sorted(set(selected));assert all(q.resolve().is_relative_to(N.resolve()) and not q.is_symlink() for q in selected)
index=[];expanded=0
with tarfile.open(F/'LOSSLESS-EVIDENCE.tar.gz','w:gz',compresslevel=6) as tar:
 for q in selected:
  rel=q.relative_to(N).as_posix();safe(rel);b=q.read_bytes();mode=q.stat().st_mode&0o777
  ti=tarfile.TarInfo(rel);ti.size=len(b);ti.mode=mode;ti.mtime=int(q.stat().st_mtime);tar.addfile(ti,io.BytesIO(b))
  index.append({'path':rel,'bytes':len(b),'sha256':digest(b),'mode':oct(mode)});expanded+=len(b)
with tarfile.open(F/'LOSSLESS-EVIDENCE.tar.gz','r:gz') as tar:
 mm=tar.getmembers();assert len(mm)==len(index)
 for m,row in zip(mm,index):
  safe(m.name);assert m.isfile() and m.name==row['path'] and m.mode==int(row['mode'],8)
  b=tar.extractfile(m).read();assert len(b)==row['bytes'] and digest(b)==row['sha256']
write('ARCHIVE-MEMBERS.json',{'count':len(index),'expandedBytes':expanded,'compression':'lossless gzip level6 tar','allMembersIndividuallyReopenedAndVerified':True,'safeRelativeMembersOnly':True,'members':index})
for name,d in oldbefore.items():assert desc(OLD/name)==d
assert gitbefore=={'HEAD':desc(C/'.git/HEAD'),'index':desc(C/'.git/index')}
gone2=proc_observation();assert not gone2['matches']
write('ACTUAL-VALIDATION-RECEIPT.json',{'publicSha':S,'status':'PASS','scope':'Second1200cap ordinary full unfiltered frontend acceptance and conditional production build, reusing previously fresh clone and fresh npmci tree. No fresh OV E2E or whole-goal acceptance.','suite':run,'fileCount':442,'passedFileCountDefaultReporter':439,'allSkippedFilesDefaultReporter':3,'counters':saved,'independentAssertionCounts':dict(ast),'build':build,'source':{'allFourMapsEqual':True,'currentAllTrackedHashesTypesModesHeld':True,'trackedEntries':20819,'trackedBytes':1358923355},'processGoneFirst':gone,'processGoneFinal':gone2,'prior600PacketHeld':True,'prior600ManifestSha256':OLDHASH,'oldTimeOutNotRetagged':True,'buildArtifacts':{'count':len(drows),'bytes':sum(x['bytes'] for x in drows)},'hybridActualNewArtifacts':len(hrows),'archive':{'members':len(index),'expandedBytes':expanded,'allMemberHashesReopened':True},'createdUTC':created,'archivalOnlyElapsedS':time.monotonic()-start,'archivalUtilityCpuAffinity':sorted(os.sched_getaffinity(0)),'archivalCudaVisibleDevices':os.environ.get('CUDA_VISIBLE_DEVICES'),'candidateOrTestOrBuildExecutedByArchival':False,'normalSourceGitServicesBrowserGpuTouched':False,'fullGoalComplete':False})
report='\n\n'.join([
'# FINAL FE PASS v3: independent raw-evidence packet',
'PASS for this frontend scope. The second actual ordinary unfiltered complete Vitest attempt at exact detached public source '+S+' finished RC0, timedOut=false, 745.0226207850501s under the separately authorized1200s diagnostic cap. It reuses clone '+str(C)+' and the existing independently prepared fresh npm-ci environment '+str(N/'npm-environment/node_modules')+'; this is not a second new clone or npm install. The earlier600s TIMEOUT packet remains immutable at '+str(OLD)+', manifest SHA256 '+OLDHASH+', RC-15 without final JSON. The native/product mesh300s budget is unchanged.',
'Complete original Vitest JSON and every assertion were read. There are442 unique file records: default reporter439 passed files +3 wholly skipped files; JSON labels all442 passed because there is no failure. Assertions reconcile exactly:4388 total =4384 passed +4 skipped +0 failed; todo0. Three capture/dump files supply3 skips and liquidTransportSolid supplies the fourth. JSON1325 suite count comes from getSuites(files), including nested suites, and is not a file count. Every file assertion/skip count agrees with its default reporter row. TEST-FILE-RESULTS.json provides the full442-row independent index; complete1,382,858B raw JSON is retained losslessly.',
'Source closure: suite-before/suite-after/build-before/build-after complete maps are equal; each raw stage0 index has the same20,819 paths/modes/blob IDs.20,815 regular files +4 literal symlinks total1,358,923,355 hashed bytes. Every current tracked file was independently reread and SHA256/type/actualmode matched, including literal symlink targets. Source manifests are retained instead of copying1.36GB source. Literal HEAD equals publice9. Recorded status throughout is only the exact owned frontend node_modules symlink to N dependencies. Package/lock bytes match npm preparation. The archival utility invoked no Git/candidate/Vitest/npm build/service/browser/Kit/GPU/native pipeline; .git/HEAD and .git/index stayed held.',
'Process receipts bind suitePID/PGID919883, buildPID/PGID950765 and controllerPID919441. Read-only /proc stat inventory found no matching PID, PGID or SID, again at freeze completion. No signals were sent. Root separately reports exec session7850 closed RC0; that statement is attributed, not fabricated as an independent session receipt.',
'Conditional ordinary production npm run build (tsc -b && vite build) launched only after full suite PASS/source parity and finished RC0,35.586444571847096s, cap300s. Suite result/source-parity SHA bindings match originals. All11 actual dist files are losslessly archived and hashed; names, displayed sizes/gzip sizes and mtimes agree with actual build interval/log. Vite phase reports11.12s/794 transformed modules; total time also includes tsc/process overhead. Vite uses chunk.code.length and asset.source.length for displayed kB: UTF16 characters can differ from actual UTF8 bytes (index JS3,076.81 displayed kB vs3,118,499 actual bytes). Both are preserved; disk hashes are authoritative. index.html refers to the actual index JS/CSS assets. BUILD-ARTIFACTS.json lists exact sizes/hashes.',
'Raw stdout/stderr/GNU time/argv/result JSON/PID receipts/allsourcepre-post/controller logs/complete runners/auth/preparation/LFS/dependency receipts and actual new hybrid outputs are retained. Nonempty stderr remains intact: jsdom canvas/React act/timer/parse-refusal output and build default-export/mixed-import/chunk-size notices. SDK-mock failure diagnostics appear inside a passed input test. RC0 does not claim warning-free output or actual SDK/video verification.',
'Only4 actually emitted v3 hybrid files are copied: before.cfdrun, after.cfdrun, after.liquidrun, frontend-report.json. Printed Shinaide report equals its artifact, source SHA equals held source. Its scope is CPU export/geometry contracts, without WebGL/mesh/CFD/DAE solve. Thirteen STL hashes remain printed observations; absent STL artifact bytes are not invented. No oldv2 hybrid directory is copied.',
'Original preparation receipt OID-verifies79 React/shared LFS payloads. Optional OV example pointers and other repo files do not become a freshclone OV E2E claim. This packet establishes this ordinary full frontend regression and production-build scope only, not fresh OV/browser E2E, encoded grid pixels, CFD/checkMesh or numerical DAE acceptance. Overall goal is not complete.',
'LOSSLESS-EVIDENCE.tar.gz holds '+str(len(index))+' safe relative regular-file members, '+str(expanded)+' expanded bytes. Every member was reopened and matched by SHA256/mode; ARCHIVE-MEMBERS.json gives each hash. Source/node_modules/toolchain trees are not duplicated. MANIFEST.json binds all direct payloads. All old600 packet payload hashes were rechecked unchanged. Root must independently reopen/hash before public archival.'
])+'\n'
(F/'REPORT.md').write_text(report)
payload={q.name:desc(q) for q in sorted(F.iterdir()) if q.is_file()}
manifest={'publicSha':S,'kind':'FINAL FE PASS v3 frozen actual second1200cap frontend-only evidence','status':'PASS','sourceFreshCloneReused':True,'freshNpmEnvironmentReused':True,'prior600ManifestSha256':OLDHASH,'fileRecords':442,'assertions':4388,'mesh300Unchanged':True,'freshOvE2eEstablished':False,'fullGoalComplete':False,'payload':payload,'payloadBytes':sum(x['bytes'] for x in payload.values())}
write('MANIFEST.json',manifest)
for name,d in payload.items():assert desc(F/name)==d
print(json.dumps({'path':str(F),'manifestSha256':desc(F/'MANIFEST.json')['sha256'],'status':'PASS','fileRecords':442,'tests':4388,'passed':4384,'skipped':4,'failed':0,'payloadCount':len(payload),'payloadBytes':manifest['payloadBytes'],'archiveMembers':len(index),'expandedBytes':expanded,'reportBytes':desc(F/'REPORT.md')['bytes'],'archivalElapsedS':time.monotonic()-start},indent=2),flush=True)

