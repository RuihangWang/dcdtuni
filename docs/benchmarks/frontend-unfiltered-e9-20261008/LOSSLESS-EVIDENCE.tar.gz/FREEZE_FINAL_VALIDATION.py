from pathlib import Path,PurePosixPath
import json,os,hashlib,tarfile,io
N=Path(__file__).resolve().parent;L=N/'full-suite-v2';C=N/'dcdtuni';F=N/'FROZEN-FINAL-PUBLIC-FE-v1';S='e9ec16b9bef7ef02ed226e74cd2963cdba1025f5';os.sched_setaffinity(0,{40,41,42,43})
run=json.loads((L/'actual-run-result.json').read_text());par=json.loads((L/'source-parity.json').read_text());assert par['before']['head']==par['after']['head']==S
raw=(L/'stdout').read_text();rows=[x for x in raw.splitlines() if x.startswith((' ✓ ',' ❯ ',' ↓ '))];progress={'passFileLines':sum(x.startswith(' ✓ ') for x in rows),'failFileLines':sum(x.startswith(' ❯ ') for x in rows),'allSkippedFileLines':sum(x.startswith(' ↓ ') for x in rows),'scope':'completed default reporter rows only; not missing final suite counters'}
j=json.loads((L/'vitest.json').read_text()) if (L/'vitest.json').exists() else None
counts=None if j is None else {k:j.get(k) for k in ['numTotalTests','numPassedTests','numFailedTests','numPendingTests','numTotalTestSuites','numPassedTestSuites','numFailedTestSuites','numPendingTestSuites']}
BD=N/'production-build';build=json.loads((BD/'actual-run-result.json').read_text()) if (BD/'actual-run-result.json').exists() else None
bp=json.loads((BD/'source-parity.json').read_text()) if (BD/'source-parity.json').exists() else None
status='TIMEOUT' if run['timedOut'] else 'PASS' if run['rc']==0 and j is not None and j.get('success') and par['sourceHeld'] else 'RED'
F.mkdir();selected=[]
for name in ['AUTHORIZED-PUBLIC-COMMIT.json','PREPARE-PLAN.json','PACKAGE-LOCK-PREPARE-BINDING.json','LFS-SCOPE-FIRST-REFUSAL.json','FULL-SUITE-GUARD-CORRECTION-v2.json','RUN_FULL_UNFILTERED.py','RUN_FULL_UNFILTERED-initial.py','RUN_FULL_UNFILTERED-v2.py','RUN_PRODUCTION_BUILD_IF_PASS.py','FREEZE_FINAL_VALIDATION.py','D-GUARD-FIRST-REFUSAL.json']:
 q=N/name
 if q.exists():selected.append(q)
for dirname in ['clone-prepare','npm-prepare','public-source-prepare','lfs-prepare','lfs-prepare-v2','full-suite','full-suite-v2','production-build','FROZEN-PREPARE-v1']:
 d=N/dirname
 if d.exists():
  for q in d.rglob('*'):
   if q.is_file() and 'tmp' not in q.relative_to(d).parts:
    assert not q.is_symlink();selected.append(q)
for name in ['package.json','package-lock.json']:selected.append(N/'npm-environment'/name)
selected=sorted(set(selected));index=[];expanded=0
with tarfile.open(F/'LOSSLESS-EVIDENCE.tar.gz','w:gz',compresslevel=6) as t:
 for q in selected:
  rel=q.relative_to(N).as_posix();p=PurePosixPath(rel);assert not p.is_absolute() and '..' not in p.parts;b=q.read_bytes();h=hashlib.sha256(b).hexdigest();a=tarfile.TarInfo(rel);a.size=len(b);a.mode=q.stat().st_mode&0o777;a.mtime=int(q.stat().st_mtime);t.addfile(a,io.BytesIO(b));index.append({'path':rel,'bytes':len(b),'sha256':h,'mode':oct(a.mode)});expanded+=len(b)
with tarfile.open(F/'LOSSLESS-EVIDENCE.tar.gz','r:gz') as t:
 mm=t.getmembers();assert len(mm)==len(index)
 for m,x in zip(mm,index):
  assert m.isfile() and m.name==x['path'] and not PurePosixPath(m.name).is_absolute() and '..' not in PurePosixPath(m.name).parts;b=t.extractfile(m).read();assert len(b)==x['bytes'] and hashlib.sha256(b).hexdigest()==x['sha256']
(F/'ARCHIVE-MEMBERS.json').write_text(json.dumps({'count':len(index),'expandedBytes':expanded,'verifiedByValue':True,'members':index},indent=2)+'\n')
lfs=json.loads((N/'lfs-prepare-v2/receipt.json').read_text());rec={'publicSha':S,'status':status,'suite':{'rc':run['rc'],'timedOut':run['timedOut'],'elapsedS':run['elapsedS'],'capSeconds':600,'unfiltered':True,'ordinaryRepoConfig':True,'maxWorkers':1,'minWorkers':1,'finalJsonAvailable':j is not None,'finalJsonCounters':counts,'testResultFiles':None if j is None else len(j.get('testResults',[])),'completedReporterRows':progress},'allTrackedSourceParity':par,'build':build,'buildSourceParity':bp,'lfs':lfs,'initialHarnessVitestStarts':0,'ownModules':str(N/'npm-environment/node_modules'),'sourceRootRetained':str(C),'normalActions':False,'archive':{'members':len(index),'expandedBytes':expanded,'verifiedByValue':True}}
(F/'ACTUAL-VALIDATION-RECEIPT.json').write_text(json.dumps(rec,indent=2)+'\n')
report='\n\n'.join([
'# Public-source unfiltered frontend validation',
'Exact detached public source `'+S+'` in new independent clone `'+str(C)+'`. Ordinary repository Vitest config, no file/name filter, fixture overrides, added skip, test/source fixes. CPU40–43, CUDA empty, math2, max/min workers1. Frontend diagnostic cap600s does not change the native mesh300s budget.',
'Unique actual suite: **'+status+'**, RC '+str(run['rc'])+', timeout '+str(run['timedOut'])+', elapsed '+str(run['elapsedS'])+'s. Final JSON available: '+str(j is not None)+'. Completed reporter file rows: '+json.dumps(progress)+'. These are partial progress when timed out. Final JSON counters: '+json.dumps(counts)+'. No final counters or unseen tests are fabricated.',
'Alltracked before/after: '+str(par['before']['trackedEntries'])+' entries, '+str(par['before']['regularFiles'])+' regular files, '+str(par['before']['symlinks'])+' literal symlinks, '+str(par['before']['trackedBytes'])+' bytes. Changed entries '+str(len(par['changedEntries']))+'; held '+str(par['sourceHeld'])+'. Complete SHA/type/mode maps and raw status are retained. Status includes only the exact known untracked frontend node_modules symlink to N own fresh npm-ci dependencies. Other dirty paths remain refused. Original empty-status preflight refusal occurred before any Vitest child; original driver/output preserved and v2 only accepts this exact owned link.',
'React/shared LFS:79 real payloads, individually exact canonical size/OID verified,22,874,452B. AllLFS504; other425 remain pointers. Frontend total137 includes58 optional OV example pointers. Original overbroad79 assertion preserved/corrected before fetch. Shared asset validation is not all freshclone OV E2E acceptance.',
'Ordinary production build: '+json.dumps(None if build is None else {k:build[k] for k in ['rc','timedOut','elapsedS']})+'. It launches only after complete green suite and source parity; red/timeout leaves it unstarted. No normal source/Git, services, browser, Kit, GPU or native pipeline action.',
'All new files/caches/tmp are inside N under dcdtuni. OldD original stash remains36 tracked WIP paths+1 third-parent helper=37 saved paths; no pop/drop. Original full public2b RED remains immutable.',
'LOSSLESS-EVIDENCE.tar.gz preserves '+str(len(index))+' raw preparation/guard/allsource-SHA/argv/log/result/artifact files, '+str(expanded)+' expanded bytes. All safe relative members reopened/SHA verified. Public Git source and own npm dependencies retained separately; no duplicate1.36GB source or extra toolchain tree. This scope does not establish CFD/checkMesh, DAE numerical acceptance, encoded grid pixels or live OV/browser acceptance.'
])+'\n'
assert len(report.encode())<=5000;(F/'REPORT.md').write_text(report);payload={q.name:{'bytes':q.stat().st_size,'sha256':hashlib.sha256(q.read_bytes()).hexdigest()} for q in sorted(F.iterdir()) if q.is_file()}
manifest={'publicSha':S,'kind':'frozen actual public-source FE validation','payload':payload,'payloadBytes':sum(x['bytes'] for x in payload.values())};(F/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
for name,x in payload.items():b=(F/name).read_bytes();assert len(b)==x['bytes'] and hashlib.sha256(b).hexdigest()==x['sha256']
print(json.dumps({'path':str(F),'manifestSha256':hashlib.sha256((F/'MANIFEST.json').read_bytes()).hexdigest(),'status':status,'payloadCount':len(payload),'payloadBytes':manifest['payloadBytes'],'losslessMembers':len(index),'reportBytes':len(report.encode())}),flush=True)
