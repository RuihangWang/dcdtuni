const fs = require('node:fs');
const path = require('node:path');
const zlib = require('node:zlib');
const crypto = require('node:crypto');
const n = '/mnt/lv/home/litianyu/mycode/dcdtuni/.codex-tmp/fresh-fe-unfiltered-final-20261007';
const root = path.join(n, 'dcdtuni/src/frontend/react/dist');
const artifacts = [];
function visit(dir) {
  for (const e of fs.readdirSync(dir, {withFileTypes: true}).sort((a,b)=>a.name.localeCompare(b.name))) {
    const q = path.join(dir,e.name);
    if (e.isDirectory()) visit(q);
    else {
      if (!e.isFile()) throw new Error('unexpected dist member');
      const b = fs.readFileSync(q);
      artifacts.push({path:path.relative(root,q), bytes:b.length, sha256:crypto.createHash('sha256').update(b).digest('hex'), gzipBytes:zlib.gzipSync(b).length});
    }
  }
}
visit(root);
console.log(JSON.stringify({kind:'pure readonly artifact compression observation; no product/test/build execution',node:process.version,zlib:process.versions.zlib,nodeBinary:process.execPath,nodeSha256:crypto.createHash('sha256').update(fs.readFileSync(process.execPath)).digest('hex'),createdUTC:new Date().toISOString(),artifacts},null,2));

