from pathlib import Path, PurePosixPath
from concurrent.futures import ThreadPoolExecutor
import os,json,subprocess,time,signal,hashlib
N=Path(__file__).resolve().parent; C=N/'dcdtuni';S='e9ec16b9bef7ef02ed226e74cd2963cdba1025f5'
B=N.parent.parent;O=B/'.codex-tmp/fresh-clone-actual-20261007/dcdtuni/.codex-tmp/source-all-fe-final-private-20261007';T=O/'toolchain/node-v24.12.0-linux-x64';FE=C/'src/frontend/react'
os.sched_setaffinity(0,{40,41,42,43})
author=json.loads((N/'AUTHORIZED-PUBLIC-COMMIT.json').read_text());assert author['expectedPublicCommit']==S and author['suiteRunAuthorized']
lfs=json.loads((N/'lfs-prepare-v2/receipt.json').read_text());assert lfs['frontendEntries']==79 and lfs['frontendAllPayloadOidVerified'] and lfs['publicSha']==S
assert subprocess.check_output(['git','-C',str(C),'rev-parse','HEAD'],text=True).strip()==S
assert subprocess.check_output(['git','-C',str(C),'status','--porcelain=v1'],text=True)==''
mods=FE/'node_modules';assert not mods.exists() and not mods.is_symlink();mods.symlink_to(N/'npm-environment/node_modules',target_is_directory=True)
L=N/'full-suite';L.mkdir();(L/'tmp').mkdir()
env=os.environ.copy();env.update({'PATH':str(T/'bin')+':'+env['PATH'],'CUDA_VISIBLE_DEVICES':'','OMP_NUM_THREADS':'2','OPENBLAS_NUM_THREADS':'2','MKL_NUM_THREADS':'2','NUMEXPR_NUM_THREADS':'2','TMPDIR':str(L/'tmp'),'TMP':str(L/'tmp'),'TEMP':str(L/'tmp'),'XDG_CACHE_HOME':str(L/'tmp'),'NODE_COMPILE_CACHE':str(L/'tmp/node-compile-cache'),'NPM_CONFIG_CACHE':str(N/'npm-cache'),'NO_COLOR':'1','CI':'1','HYBRID_COMPILER_OUTPUT_DIR':str(L/'hybrid-artifacts')})
def read_snapshot(label):
 t=time.monotonic();raw=subprocess.check_output(['git','-C',str(C),'ls-files','--stage','-z']);(L/(label+'-git-index.raw')).write_bytes(raw);items=[]
 for record in raw.split(b'\0'):
  if not record:continue
  entry,path=record.split(b'\t',1);mode,blob,stage=entry.decode().split();rel=path.decode();rp=PurePosixPath(rel);assert not rp.is_absolute() and '..' not in rp.parts and stage=='0';items.append((rel,mode,blob))
 def hash_item(item):
  rel,mode,blob=item;q=C/rel
  if q.is_symlink():r=os.readlink(q).encode();kind='symlink';actualMode=oct(q.lstat().st_mode&0o777)
  else:
   assert q.is_file(),rel
   h=hashlib.sha256();n=0
   with q.open('rb') as f:
    for z in iter(lambda:f.read(1048576),b''):h.update(z);n+=len(z)
   return rel,{'gitMode':mode,'gitBlob':blob,'type':'regular','bytes':n,'sha256':h.hexdigest(),'actualMode':oct(q.stat().st_mode&0o777)}
  return rel,{'gitMode':mode,'gitBlob':blob,'type':kind,'bytes':len(r),'sha256':hashlib.sha256(r).hexdigest(),'literalTarget':r.decode(),'actualMode':actualMode}
 with ThreadPoolExecutor(max_workers=4) as pool:rows=dict(pool.map(hash_item,items))
 status=subprocess.check_output(['git','-C',str(C),'status','--porcelain=v1'],text=True);head=subprocess.check_output(['git','-C',str(C),'rev-parse','HEAD'],text=True).strip();assert head==S
 for name,args in [('status',['status','--porcelain=v1']),('lfs',['lfs','ls-files','--long']),('submodules',['submodule','status']),('stash',['stash','list'])]:
  p=subprocess.run(['git','-C',str(C),*args],capture_output=True,text=True);(L/(label+'-'+name+'.stdout')).write_text(p.stdout);(L/(label+'-'+name+'.stderr')).write_text(p.stderr);assert p.returncode==0,name
 receipt={'head':head,'status':status,'trackedEntries':len(rows),'regularFiles':sum(e['type']=='regular' for e in rows.values()),'symlinks':sum(e['type']=='symlink' for e in rows.values()),'trackedBytes':sum(e['bytes'] for e in rows.values()),'elapsedS':time.monotonic()-t};(L/(label+'-source.json')).write_text(json.dumps(rows,indent=2)+'\n');(L/(label+'-source-receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n');return rows,receipt
before,pre=read_snapshot('before');assert pre['status']=='';print('SOURCE_BEFORE',json.dumps(pre),flush=True)
argv=['/usr/bin/time','-v','-o',str(L/'time.txt'),str(T/'bin/node'),str(FE/'node_modules/vitest/vitest.mjs'),'run','--maxWorkers=1','--minWorkers=1','--reporter=default','--reporter=json','--outputFile='+str(L/'vitest.json')]
meta={'publicSha':S,'argv':argv,'cwd':str(FE),'timeoutSeconds':600,'budgetKind':'unfiltered FE diagnostic; native mesh300 unchanged','allowedCpus':sorted(os.sched_getaffinity(0)),'maxWorkers':1,'minWorkers':1,'unfiltered':True,'ordinaryRepoConfig':True,'fixtureOverrides':False,'artifactOutputDirectoryOnly':env['HYBRID_COMPILER_OUTPUT_DIR'],'runtime':{'node':subprocess.check_output([str(T/'bin/node'),'--version'],text=True).strip(),'npm':subprocess.check_output([str(T/'bin/npm'),'--version'],text=True,env=env).strip(),'nodeSha256':hashlib.sha256((T/'bin/node').read_bytes()).hexdigest()},'environment':{k:env[k] for k in ['CUDA_VISIBLE_DEVICES','OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','TMPDIR','XDG_CACHE_HOME','NODE_COMPILE_CACHE','NPM_CONFIG_CACHE','CI']}}
(L/'argv.json').write_text(json.dumps(meta,indent=2)+'\n');t=time.monotonic();timeout=False
with (L/'stdout').open('w') as out,(L/'stderr').open('w') as err:
 p=subprocess.Popen(argv,cwd=FE,env=env,stdout=out,stderr=err,start_new_session=True);(L/'owned-process.json').write_text(json.dumps({'pid':p.pid,'pgid':p.pid,'publicSha':S,'argv':argv,'startWallUnix':time.time()},indent=2)+'\n');print('SUITE_STARTED',p.pid,flush=True)
 try:rc=p.wait(timeout=600)
 except subprocess.TimeoutExpired:
  timeout=True;os.killpg(p.pid,signal.SIGTERM)
  try:rc=p.wait(timeout=5)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);rc=p.wait(timeout=5)
meta.update({'rc':rc,'timedOut':timeout,'elapsedS':time.monotonic()-t});(L/'actual-run-result.json').write_text(json.dumps(meta,indent=2)+'\n');print('SUITE_RESULT',json.dumps(meta),flush=True)
after,post=read_snapshot('after');changed=[k for k in sorted(set(before)|set(after)) if before.get(k)!=after.get(k)];(L/'source-parity.json').write_text(json.dumps({'changedEntries':changed,'before':pre,'after':post,'sourceHeld':not changed and post['status']==''},indent=2)+'\n');print('SOURCE_PARITY',json.dumps({'changedEntries':changed,'sourceHeld':not changed and post['status']==''}),flush=True)
if (L/'vitest.json').exists():
 j=json.loads((L/'vitest.json').read_text());c={k:j.get(k) for k in ['numTotalTests','numPassedTests','numFailedTests','numPendingTests','numTotalTestSuites','numPassedTestSuites','numFailedTestSuites','numPendingTestSuites']};(L/'vitest-counters.json').write_text(json.dumps(c,indent=2)+'\n');print('COUNTERS',json.dumps(c),flush=True)
 failures=[]
 for suite in j.get('testResults',[]):
  for a in suite.get('assertionResults',[]):
   if a['status']=='failed':failures.append({'file':suite['name'],'fullName':a['fullName'],'failureMessages':a.get('failureMessages',[])})
 (L/'failures.json').write_text(json.dumps(failures,indent=2)+'\n');print('FAILED_NAMES',json.dumps([{'file':f['file'],'name':f['fullName']} for f in failures]),flush=True)
