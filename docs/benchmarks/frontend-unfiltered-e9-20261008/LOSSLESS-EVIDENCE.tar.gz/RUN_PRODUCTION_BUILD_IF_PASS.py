from pathlib import Path, PurePosixPath
from concurrent.futures import ThreadPoolExecutor
import os,json,subprocess,time,signal,hashlib
N=Path(__file__).resolve().parent;C=N/'dcdtuni';FE=C/'src/frontend/react';S='e9ec16b9bef7ef02ed226e74cd2963cdba1025f5'
B=N.parent.parent;T=B/'.codex-tmp/fresh-clone-actual-20261007/dcdtuni/.codex-tmp/source-all-fe-final-private-20261007/toolchain/node-v24.12.0-linux-x64'
L=N/'production-build';P=N/'full-suite-v2';os.sched_setaffinity(0,{40,41,42,43})
a=json.loads((P/'actual-run-result.json').read_text());parity=json.loads((P/'source-parity.json').read_text());j=json.loads((P/'vitest.json').read_text())
assert a['rc']==0 and not a['timedOut'] and parity['sourceHeld'] and j['numFailedTests']==0 and j['success'], 'full ordinary suite must pass first'
assert subprocess.check_output(['git','-C',str(C),'rev-parse','HEAD'],text=True).strip()==S
mods=FE/'node_modules';assert mods.is_symlink() and mods.resolve()==(N/'npm-environment/node_modules').resolve()
expectedStatus='?? src/frontend/react/node_modules\n';assert subprocess.check_output(['git','-C',str(C),'status','--porcelain=v1'],text=True)==expectedStatus
L.mkdir();(L/'tmp').mkdir()
env=os.environ.copy();env.update({'PATH':str(T/'bin')+':'+env['PATH'],'CUDA_VISIBLE_DEVICES':'','OMP_NUM_THREADS':'2','OPENBLAS_NUM_THREADS':'2','MKL_NUM_THREADS':'2','NUMEXPR_NUM_THREADS':'2','TMPDIR':str(L/'tmp'),'TMP':str(L/'tmp'),'TEMP':str(L/'tmp'),'XDG_CACHE_HOME':str(L/'tmp'),'NODE_COMPILE_CACHE':str(L/'tmp/node-compile-cache'),'NPM_CONFIG_CACHE':str(N/'npm-cache'),'NO_COLOR':'1','CI':'1'})
def snapshot(label):
 t=time.monotonic();raw=subprocess.check_output(['git','-C',str(C),'ls-files','--stage','-z']);(L/(label+'-git-index.raw')).write_bytes(raw);items=[]
 for z in raw.split(b'\0'):
  if not z:continue
  entry,path=z.split(b'\t',1);mode,blob,stage=entry.decode().split();rel=path.decode();rp=PurePosixPath(rel);assert stage=='0' and not rp.is_absolute() and '..' not in rp.parts;items.append((rel,mode,blob))
 def one(item):
  rel,mode,blob=item;q=C/rel
  if q.is_symlink():
   b=os.readlink(q).encode();return rel,{'gitMode':mode,'gitBlob':blob,'type':'symlink','bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'literalTarget':b.decode(),'actualMode':oct(q.lstat().st_mode&0o777)}
  assert q.is_file(),rel
  h=hashlib.sha256();n=0
  with q.open('rb') as f:
   for b in iter(lambda:f.read(1048576),b''):h.update(b);n+=len(b)
  return rel,{'gitMode':mode,'gitBlob':blob,'type':'regular','bytes':n,'sha256':h.hexdigest(),'actualMode':oct(q.stat().st_mode&0o777)}
 with ThreadPoolExecutor(max_workers=4) as pool:rows=dict(pool.map(one,items))
 status=subprocess.check_output(['git','-C',str(C),'status','--porcelain=v1'],text=True);head=subprocess.check_output(['git','-C',str(C),'rev-parse','HEAD'],text=True).strip();assert head==S
 receipt={'head':head,'status':status,'trackedEntries':len(rows),'regularFiles':sum(v['type']=='regular' for v in rows.values()),'symlinks':sum(v['type']=='symlink' for v in rows.values()),'trackedBytes':sum(v['bytes'] for v in rows.values()),'elapsedS':time.monotonic()-t}
 (L/(label+'-source.json')).write_text(json.dumps(rows,indent=2)+'\n');(L/(label+'-source-receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n');return rows,receipt
before,pre=snapshot('before');suiteSource=json.loads((P/'after-source.json').read_text());assert before==suiteSource and pre['status']==expectedStatus,'source closure changed since suite'
argv=['/usr/bin/time','-v','-o',str(L/'time.txt'),str(T/'bin/npm'),'run','build'];meta={'publicSha':S,'argv':argv,'cwd':str(FE),'timeoutSeconds':300,'budgetKind':'ordinary production build diagnostic; product mesh300 unchanged','allowedCpus':sorted(os.sched_getaffinity(0)),'ordinaryRepoBuild':True,'suiteResultSha256':hashlib.sha256((P/'actual-run-result.json').read_bytes()).hexdigest(),'suiteSourceParitySha256':hashlib.sha256((P/'source-parity.json').read_bytes()).hexdigest(),'sourceEqualToPassedSuite':True,'environment':{k:env[k] for k in ['CUDA_VISIBLE_DEVICES','OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','TMPDIR','XDG_CACHE_HOME','NODE_COMPILE_CACHE','NPM_CONFIG_CACHE','CI']},'runtime':{'node':subprocess.check_output([str(T/'bin/node'),'--version'],text=True).strip(),'npm':subprocess.check_output([str(T/'bin/npm'),'--version'],text=True,env=env).strip()}}
(L/'argv.json').write_text(json.dumps(meta,indent=2)+'\n');t=time.monotonic();timeout=False
print('BUILD_SOURCE_BEFORE',json.dumps(pre),flush=True)
with (L/'stdout').open('w') as out,(L/'stderr').open('w') as err:
 p=subprocess.Popen(argv,cwd=FE,env=env,stdout=out,stderr=err,start_new_session=True);(L/'owned-process.json').write_text(json.dumps({'pid':p.pid,'pgid':p.pid,'argv':argv,'startWallUnix':time.time()},indent=2)+'\n');print('BUILD_STARTED',p.pid,flush=True)
 try:rc=p.wait(timeout=300)
 except subprocess.TimeoutExpired:
  timeout=True;os.killpg(p.pid,signal.SIGTERM)
  try:rc=p.wait(timeout=5)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);rc=p.wait(timeout=5)
meta.update({'rc':rc,'timedOut':timeout,'elapsedS':time.monotonic()-t});(L/'actual-run-result.json').write_text(json.dumps(meta,indent=2)+'\n');print('BUILD_RESULT',json.dumps(meta),flush=True)
after,post=snapshot('after');changed=[k for k in sorted(set(before)|set(after)) if before.get(k)!=after.get(k)];held=not changed and pre['status']==post['status']==expectedStatus
(L/'source-parity.json').write_text(json.dumps({'changedEntries':changed,'before':pre,'after':post,'sourceHeld':held},indent=2)+'\n');print('BUILD_SOURCE_PARITY',json.dumps({'changedEntries':changed,'sourceHeld':held}),flush=True)
