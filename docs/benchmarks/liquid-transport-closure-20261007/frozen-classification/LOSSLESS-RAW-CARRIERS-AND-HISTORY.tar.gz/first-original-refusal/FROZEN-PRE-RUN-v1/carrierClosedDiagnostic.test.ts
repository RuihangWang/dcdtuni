/** PRIVATE observation of one actual saved project, not a closure repair. */
import { createHash } from 'node:crypto'
import { readFileSync,writeFileSync } from 'node:fs'
import { resolve } from 'node:path'
import * as THREE from 'three'
import { it } from 'vitest'
import '../src/legacy/geometryBuilder'
import { liveProject } from '../src/transient/model'
import { stateV4 } from '../src/legacy/cfdprojModules'
import { createSceneBuilder,emptyRegistries,type SceneHost } from '../src/interaction/sceneBuilder'
import type { CfdProject,Construction } from '../src/schema/cfdproj'
import * as store from '../src/projectStore'
it('observes the exact old Shinaide fixture through its real scene exporter once',()=>{
  const sourcePath=resolve(process.cwd(),'../../../case/Shinaide_Liquid/Shinaide_liquid.cfdproj')
  const source=readFileSync(sourcePath,'utf8');const sourceSha=createHash('sha256').update(source).digest('hex')
  if(sourceSha!=='594558e17f9618bf216fefd1f8788c31f7332b1bca00b6a7cadc25247316e626')throw new Error('fixture hash mismatch')
  store.loadProject(stateV4().normalizeStateV4(JSON.parse(source)) as unknown as CfdProject,null)
  const input=store.getProject()!
  const project=liveProject(stateV4().normalizeStateV4(JSON.parse(JSON.stringify(input))) as unknown as CfdProject,0)
  const globalGroup=new THREE.Group(),wrapperGroup=new THREE.Group(),root=new THREE.Group()
  root.add(wrapperGroup);wrapperGroup.add(globalGroup)
  const host:SceneHost={globalGroup,wrapperGroup,registries:emptyRegistries(),selectedUid:()=>null,
    project:()=>project,webglAvailable:false,previewMode:()=>false}
  const globals=window as unknown as {allModels?:()=>Construction[]};const oldModels=globals.allModels
  globals.allModels=()=>stateV4().allModels(project) as Construction[]
  const builder=createSceneBuilder(host);const started=performance.now();let error:unknown
  try {
    builder.rebuild();wrapperGroup.updateMatrixWorld(true)
    const ids=(stateV4().allModels(project) as Construction[]).map(model=>model.uid)
    const files=builder.api.buildGroupedStlMap(ids,false)
    writeFileSync(process.env.CARRIER_DIAG_RECEIPT!,JSON.stringify({sourcePath,sourceSha,projectUid:project.uid,
      exportCalls:1,elapsedMs:performance.now()-started,fileCount:Object.keys(files).length,unexpectedExportSuccess:true},null,2))
  } catch(e) {
    error=e;writeFileSync(process.env.CARRIER_DIAG_RECEIPT!,JSON.stringify({sourcePath,sourceSha,projectUid:project.uid,
      exportCalls:1,elapsedMs:performance.now()-started,errorType:e instanceof Error?e.name:typeof e,
      error:e instanceof Error?e.message:String(e),stack:e instanceof Error?e.stack:undefined},null,2))
  } finally {
    builder.clear();if(oldModels)globals.allModels=oldModels;else delete globals.allModels
  }
  if(error)throw error // Preserve the product refusal as RED.
},60_000)
