import { readFileSync } from 'node:fs'
import { resolve } from 'node:path'
import { expect, it } from 'vitest'
import { OV_SLICE_RAMP, OV_VOLUME_RAMP, sampleRamp } from '../src/renderer/ovColormaps'

/** The OV legend must be painted from the ramps Kit renders with. These parse
 * the Python sources the bridge actually executes; editing a colour on one
 * side without the other fails here instead of in a screenshot. */
const BRIDGE = resolve(__dirname, '../../omniverse/cfd_demo/kit/extensions/dc.cfd_bridge/dc/cfd_bridge')
const nums = (s: string) => (s.match(/-?\d+(?:\.\d+)?/g) ?? []).map(Number)

it('slice ramp mirrors slice_render._RAMP', () => {
  const src = readFileSync(resolve(BRIDGE, 'slice_render.py'), 'utf8')
  const block = src.slice(src.indexOf('_RAMP = ['), src.indexOf(']\n\n', src.indexOf('_RAMP = [')))
  const stops = [...block.matchAll(/\(([\d.]+),\s*\(([^)]*)\)\)/g)].map(m => [Number(m[1]), nums(m[2]!)])
  expect(stops).toEqual(OV_SLICE_RAMP.map(([t, c]) => [t, [...c]]))
})

it('volume ramp mirrors the IndeX thermal colormap (RGB of rgbaPoints at xPoints)', () => {
  const src = readFileSync(resolve(BRIDGE, 'scene.py'), 'utf8')
  const xs = nums(src.match(/GetAttribute\("xPoints"\)\.Set\(\[([^\]]*)\]\)/)![1]!)
  const rgbaBlock = src.slice(src.indexOf('GetAttribute("rgbaPoints").Set(['), src.indexOf('])', src.indexOf('GetAttribute("rgbaPoints").Set([')))
  const rgba = [...rgbaBlock.matchAll(/Gf\.Vec4f\(([^)]*)\)/g)].map(m => nums(m[1]!))
  expect(xs).toEqual(OV_VOLUME_RAMP.map(([t]) => t))
  expect(rgba.map(c => c.slice(0, 3))).toEqual(OV_VOLUME_RAMP.map(([, c]) => [...c]))
})

it('sampleRamp clamps, interpolates, and greys NaN like scalar_to_rgb', () => {
  const close = (a: number[], b: number[]) => a.forEach((v, i) => expect(v).toBeCloseTo(b[i]!, 12))
  close(sampleRamp(OV_SLICE_RAMP, -1), [0.10, 0.25, 0.85])
  close(sampleRamp(OV_SLICE_RAMP, 2), [0.90, 0.15, 0.10])
  expect(sampleRamp(OV_SLICE_RAMP, NaN)).toEqual([0.5, 0.5, 0.5])
  const mid = sampleRamp(OV_SLICE_RAMP, 0.125)
  expect(mid[0]).toBeCloseTo(0.10)
  expect(mid[1]).toBeCloseTo(0.50)
})
