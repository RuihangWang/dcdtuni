import { readFileSync } from 'node:fs'
import { resolve } from 'node:path'
import { act, StrictMode } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import * as THREE from 'three'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { LIVE_FOLLOW_MS, OvLiquidSection } from '../src/components/OvPostProcessPanel'
import { OvCommandClient, type RenderAck } from '../src/renderer/ovProtocol'
import { requestLiquidResultGrant } from '../src/renderer/ovDataset'
import { liquidDisplayPreference, rememberLiquidDisplay, resetOvDisplayPreferences } from '../src/renderer/ovDisplayPreferences'
import { ovSession, setOvSession } from '../src/renderer/ovSession'
import { buildSceneSnapshot } from '../src/renderer/sceneSnapshot'
import { fetchLiquidResults, resetLiquidRun } from '../src/liquid/liquidSession'
import { createRuntimeSession, refreshRuntimeFrames, resetRuntimeClient } from '../src/liquid/liquidRuntimeClient'
import { liquidFrame, liquidGlobalDomains, mappedPipeTemperatures, setResultSample } from '../src/liquid/liquidTempColor'

const TESTDATA = resolve(__dirname, '../../shared/testdata')
const fixture = () => JSON.parse(readFileSync(resolve(TESTDATA, 'liquid_result_fixture.json'), 'utf8'))
const expected = () => JSON.parse(readFileSync(resolve(TESTDATA, 'liquid_colour_expected.json'), 'utf8'))
const json = (value: unknown, status = 200) => new Response(JSON.stringify(value), { status, headers: { 'Content-Type': 'application/json' } })

describe('liquid colour contract (Python liquid_colour.py <-> React liquidTempColor.ts)', () => {
  it('pipe temperatures match the shared contract at every sample', () => {
    const raw = fixture()
    const frames = expected().frames as Record<string, Record<string, { T: number }>>
    for (const [sample, targets] of Object.entries(frames)) {
      const pipes = mappedPipeTemperatures(raw, Number(sample))
      for (const [key, v] of Object.entries(targets)) {
        const [kind, uid] = key.split('|')
        if (kind !== 'pipe') continue
        expect(pipes.get(uid!)).toBeCloseTo(v.T, 9)
      }
    }
  })
})

describe('liquid colour contract — every part, T and colour', () => {
  it('liquidFrame reproduces the Python contract for all parts and both scales', () => {
    const raw = fixture()
    const frames = expected().frames as Record<string, Record<string, { T: number; rgb: number[]; group: string }> & { __domains__: Record<string, number[]> }>
    for (const [sample, exp] of Object.entries(frames)) {
      const fr = liquidFrame(raw, Number(sample))!
      const { __domains__: domains, ...targets } = exp
      expect(fr.domains).toEqual(domains)
      const got = Object.fromEntries(fr.targets.map(t => [[t.kind, t.modelUid, t.equipmentUid, t.liquidPart].join('|'), t]))
      expect(Object.keys(got).sort()).toEqual(Object.keys(targets).sort())
      for (const [key, v] of Object.entries(targets)) {
        expect(got[key]!.T).toBeCloseTo(v.T, 9)
        expect([(got[key]!.color >> 16) & 255, (got[key]!.color >> 8) & 255, got[key]!.color & 255]).toEqual(v.rgb)
      }
    }
  })
})

describe('liquid OV protocol', () => {
  it('sends exactly the bridge-validated key sets', async () => {
    const sent: { command_name: string; message: string }[] = []
    const client = new OvCommandClient(async payload => { sent.push(payload) })
    const grant = { payload: { kind: 'liquidResult' }, signature: 'f'.repeat(64) }
    void client.loadLiquidResult(grant).catch(() => {})
    void client.setLiquidFrame(3, null).catch(() => {})
    void client.clearLiquidColours().catch(() => {})
    await Promise.resolve(); await Promise.resolve()
    const keys = Object.fromEntries(sent.map(s => [s.command_name, Object.keys(JSON.parse(s.message)).sort()]))
    expect(keys).toEqual({ loadLiquidResult: ['grant', 'requestId'], setLiquidFrame: ['domains', 'requestId', 'sample'], clearLiquidColours: ['requestId'] })
    client.dispose()
  })

  it('surfaces the missing keys of an unbound (legacy) result', async () => {
    const f = vi.fn(async () => json({ code: 'liquid_result_unbound', error: 'Result is not displayable', missing: ['object_bindings'] }, 422))
    await expect(requestLiquidResultGrant('a'.repeat(32), f)).rejects.toThrow(/object_bindings/)
  })
})

it('snapshots export the un-painted material while Kit colours liquid results', () => {
  const root = new THREE.Group()
  const original = new THREE.MeshStandardMaterial({ color: 0x2196f3 })
  const painted = new THREE.MeshStandardMaterial({ color: 0xff0000 })
  const mesh = new THREE.Mesh(new THREE.BoxGeometry(1, 1, 1), painted)
  mesh.userData.modelId = 'pipe-1'
  root.add(mesh)
  const colour = (p: ReturnType<typeof buildSceneSnapshot>) => p.primitives[0]!.material.color
  expect(colour(buildSceneSnapshot({ root, project: { uid: 'p' } }))).toEqual([1, 0, 0])
  const orig = buildSceneSnapshot({ root, project: { uid: 'p' }, materialOf: m => (m === mesh ? original : undefined) })
  expect(colour(orig)[2]).toBeGreaterThan(0.8)
})

describe('OvLiquidSection', () => {
  let host: HTMLDivElement, root: Root
  beforeEach(() => {
    ;(globalThis as any).IS_REACT_ACT_ENVIRONMENT = true
    resetLiquidRun(); resetOvDisplayPreferences()
    host = document.createElement('div'); document.body.append(host); root = createRoot(host)
  })
  afterEach(() => { act(() => root.unmount()); host.remove(); resetLiquidRun(); resetOvDisplayPreferences(); setOvSession({ liquidActive: false, sceneIdle: null }); vi.restoreAllMocks() })

  it('grants, loads, follows the slider latest-wins, and clears', async () => {
    const raw = fixture()
    vi.spyOn(globalThis, 'fetch').mockImplementation(async (input: any) => String(input).startsWith('/api/liquid/results')
      ? json(raw)
      : json({ grant: { payload: { kind: 'liquidResult' }, signature: 'c'.repeat(64) }, runId: raw.run_id, status: 'completed', samples: 3, solver: raw.solver }))
    await act(async () => { await fetchLiquidResults() })
    const calls: { name: string; args: unknown[] }[] = []
    const ok = (extra: Partial<RenderAck>) => async (...args: unknown[]) => { calls.push({ name: '', args }); return { requestId: 'x', ok: true, ...extra } as RenderAck }
    const client = {
      loadLiquidResult: vi.fn(ok({ liquid: { runId: raw.run_id, solver: raw.solver, status: 'completed', samples: 3, times: [0, 600], targets: { pipe: 2 }, projectUid: 'proj_Shinaide', projectContentMatches: false } })),
      setLiquidFrame: vi.fn(ok({ liquidFrame: { sample: 2, timeSeconds: 600, groups: { network: { domain: [290, 300], source: 'frame min..max', count: 5 } }, targets: { pipe: 2 }, painted: 9, unmatched: { manifold: 2 } } })),
      clearLiquidColours: vi.fn(ok({ cleared: 9 })),
    } as unknown as OvCommandClient
    await act(async () => root.render(<OvLiquidSection client={client} degraded={false} />))
    const box = host.querySelector<HTMLInputElement>('input[type=checkbox]')!
    expect(box.disabled).toBe(false)
    await act(async () => { box.click() })
    await act(async () => { await new Promise(r => setTimeout(r, 0)) })
    expect(client.loadLiquidResult).toHaveBeenCalledWith({ payload: { kind: 'liquidResult' }, signature: 'c'.repeat(64) })
    expect(ovSession().liquidActive).toBe(true)
    expect(host.querySelector('[data-ov-liquid-painted="9"]')).not.toBeNull()
    expect(host.textContent).toMatch(/manifold 2/)          // unmatched parts are reported, not hidden
    expect(host.textContent).toMatch(/修改|changed/)        // project changed after solve is labelled
    await act(async () => { setResultSample(1) })
    await act(async () => { await new Promise(r => setTimeout(r, 0)) })
    expect((client.setLiquidFrame as any).mock.calls.map((c: unknown[]) => c[0])).toContain(1)
    await act(async () => { box.click() })
    await act(async () => { await new Promise(r => setTimeout(r, 0)) })
    expect(client.clearLiquidColours).toHaveBeenCalled()
    expect(ovSession().liquidActive).toBe(false)
  })

  it('re-grants on a new run identity and follows the live experiment of the displayed run', async () => {
    vi.useFakeTimers({ toFake: ['setTimeout', 'clearTimeout', 'Date'] })
    try {
      const older = { ...fixture(), run_id: 'a'.repeat(32) }
      const liveRun = 'b'.repeat(32)
      let liveSamples = 2
      const liveResult = () => ({ ...fixture(), run_id: liveRun, status: 'running', time_s: fixture().time_s.slice(0, liveSamples) })
      const resultUrls: string[] = []
      const frame = (seq: number) => ({ kind: 'frame', run_id: liveRun, seq, time_s: seq, node_pressure_Pa: [], node_temperature_K: [],
        edge_flow_kg_s: [], chip_temp_K: [], edge_outlet_temp_K: [], controls: {}, diagnostics: {} })
      vi.spyOn(globalThis, 'fetch').mockImplementation(async (input: any, init?: any) => {
        const url = String(input)
        if (url.startsWith('/api/liquid/results')) { resultUrls.push(url); return json(url.includes(liveRun) ? liveResult() : older) }
        if (url === '/api/liquid/runs' && init?.method === 'POST') return json({ run_id: liveRun, status: 'running', config_hash: 'h',
          metadata: { node_ids: [], edge_ids: [], cp_edge_ids: [], total_sample_count: 10, dt_s: 1, object_bindings: {} }, frame: frame(0) })
        if (url.includes('/frames')) return json({ frames: [frame(1), frame(2)], status: 'running' })
        return json({ grant: { payload: { kind: 'liquidResult' }, signature: 'd'.repeat(64) }, runId: url, status: 'running', samples: 2, solver: 'x' })
      })
      await act(async () => { await fetchLiquidResults() })
      const loads: string[] = []
      const client = {
        loadLiquidResult: vi.fn(async () => {
          const cur = (await import('../src/liquid/liquidSession')).liquidRunState().results as any
          loads.push(`${cur.run_id.slice(0, 1)}:${cur.time_s.length}`)
          return { requestId: 'x', ok: true, liquid: { runId: cur.run_id, solver: 'x', status: cur.status ?? 'completed', samples: cur.time_s.length,
            times: cur.time_s, targets: {}, projectUid: 'p', projectContentMatches: true } } as RenderAck
        }),
        setLiquidFrame: vi.fn(async () => ({ requestId: 'x', ok: true, liquidFrame: { sample: 0, timeSeconds: 0, groups: {}, targets: {}, painted: 1, unmatched: {} } }) as RenderAck),
      } as unknown as OvCommandClient
      await act(async () => root.render(<OvLiquidSection client={client} degraded={false} />))
      await act(async () => { host.querySelector<HTMLInputElement>('input[type=checkbox]')!.click() })
      await act(async () => { await vi.advanceTimersByTimeAsync(0) })
      expect(loads).toEqual([`a:${older.time_s.length}`])
      // A live experiment on another run: offered, never adopted silently.
      await act(async () => { await createRuntimeSession({}, [], 1) })
      const follow = [...host.querySelectorAll('button')].find(b => b.textContent!.includes(liveRun.slice(0, 8)))!
      expect(follow).toBeTruthy()
      expect(loads).toHaveLength(1)
      // Adopting it switches the run identity: a fresh grant even though it has
      // fewer samples, and the slider returns to the latest sample of the new run.
      await act(async () => { setResultSample(older.time_s.length - 1); await vi.advanceTimersByTimeAsync(0) })
      await act(async () => { follow.click(); await vi.advanceTimersByTimeAsync(0) })
      expect(loads).toEqual([`a:${older.time_s.length}`, 'b:2'])
      expect((client.setLiquidFrame as any).mock.calls.at(-1)[0]).toBe(-1)
      expect(host.querySelector('[data-ov-liquid-following="running"]')).not.toBeNull()
      // New frames re-read the result (first at once, then at most once per LIVE_FOLLOW_MS) and the grown result re-grants.
      liveSamples = 3
      const before = resultUrls.length
      await act(async () => { await refreshRuntimeFrames(); await vi.advanceTimersByTimeAsync(0) })
      expect(resultUrls.slice(before)).toEqual([`/api/liquid/results?run=run-${liveRun}`])
      expect(loads.at(-1)).toBe('b:3')
      await act(async () => { await refreshRuntimeFrames(); await vi.advanceTimersByTimeAsync(LIVE_FOLLOW_MS / 2) })
      expect(resultUrls.length - before).toBe(1)
      await act(async () => { await vi.advanceTimersByTimeAsync(LIVE_FOLLOW_MS) })
      expect(resultUrls.length - before).toBe(2)
    } finally { resetRuntimeClient(); vi.useRealTimers() }
  })

  it('waits for an in-flight scene transfer before loading the result', async () => {
    const raw = fixture()
    vi.spyOn(globalThis, 'fetch').mockImplementation(async (input: any) => String(input).startsWith('/api/liquid/results')
      ? json(raw)
      : json({ grant: { payload: { kind: 'liquidResult' }, signature: 'e'.repeat(64) }, runId: raw.run_id, status: 'completed', samples: 3, solver: raw.solver }))
    await act(async () => { await fetchLiquidResults() })
    let sceneDone!: () => void
    setOvSession({ sceneIdle: () => new Promise<void>(r => { sceneDone = r }) })
    const client = {
      loadLiquidResult: vi.fn(async () => ({ requestId: 'x', ok: true, liquid: { runId: raw.run_id, solver: raw.solver, status: 'completed', samples: 3,
        times: [0, 600], targets: {}, projectUid: 'p', projectContentMatches: true } }) as RenderAck),
      setLiquidFrame: vi.fn(async () => ({ requestId: 'x', ok: true }) as RenderAck),
    } as unknown as OvCommandClient
    try {
      await act(async () => root.render(<OvLiquidSection client={client} degraded={false} />))
      await act(async () => { host.querySelector<HTMLInputElement>('input[type=checkbox]')!.click(); await new Promise(r => setTimeout(r, 0)) })
      expect(client.loadLiquidResult).not.toHaveBeenCalled()
      expect(host.textContent).toMatch(/场景同步|scene sync/)
      await act(async () => { sceneDone(); await new Promise(r => setTimeout(r, 0)) })
      expect(client.loadLiquidResult).toHaveBeenCalledTimes(1)
    } finally { setOvSession({ sceneIdle: null }) }
  })

  it('restores colouring, fixed scale and the current sample on a fresh acknowledged client', async () => {
    const raw = fixture()
    let grants = 0
    vi.spyOn(globalThis, 'fetch').mockImplementation(async (input: any) => String(input).startsWith('/api/liquid/results')
      ? json(raw)
      : json({ grant: { payload: { kind: 'liquidResult', runId: raw.run_id }, signature: String(++grants).repeat(64) },
          runId: raw.run_id, status: 'completed', samples: 3, solver: raw.solver }))
    await act(async () => { await fetchLiquidResults(); setResultSample(2) })
    const makeClient = () => ({
      loadLiquidResult: vi.fn(async () => ({ requestId: 'x', ok: true, liquid: {
        runId: raw.run_id, solver: raw.solver, status: 'completed', samples: 3, times: [0, 600],
        targets: {}, projectUid: 'p', projectContentMatches: true } }) as RenderAck),
      setLiquidFrame: vi.fn(async () => ({ requestId: 'x', ok: true }) as RenderAck),
      clearLiquidColours: vi.fn(async () => ({ requestId: 'x', ok: true }) as RenderAck),
    } as unknown as OvCommandClient)
    const first = makeClient()
    await act(async () => root.render(<OvLiquidSection client={first} degraded={false} projectUid="p" />))
    await act(async () => { host.querySelector<HTMLInputElement>('input[type=checkbox]')!.click() })
    await act(async () => { host.querySelectorAll<HTMLInputElement>('input[type=checkbox]')[1]!.click() })
    expect(liquidDisplayPreference('p', raw.run_id)).toEqual({ enabled: true, fixedScale: true })
    expect(grants).toBe(1)
    act(() => root.unmount()); root = createRoot(host)
    setOvSession({ liquidActive: false })
    let sceneDone!: () => void
    const sceneIdle = new Promise<void>(resolve => { sceneDone = resolve })
    setOvSession({ sceneIdle: () => sceneIdle })
    const second = makeClient()
    // Production uses StrictMode. Its setup/cleanup replay must not send an
    // abandoned grant or claim the restored checkbox before the fresh ACK.
    await act(async () => root.render(<StrictMode><OvLiquidSection client={second} degraded={false} projectUid="p" /></StrictMode>))
    expect(second.loadLiquidResult).not.toHaveBeenCalled()
    expect(grants).toBe(1)
    expect(host.querySelector<HTMLInputElement>('input[type=checkbox]')!.checked).toBe(false)
    await act(async () => { sceneDone(); await new Promise(r => setTimeout(r, 0)) })
    expect(grants).toBe(2)
    expect(second.loadLiquidResult).toHaveBeenCalledWith({ payload: { kind: 'liquidResult', runId: raw.run_id }, signature: '2'.repeat(64) })
    expect(second.setLiquidFrame).toHaveBeenLastCalledWith(2, liquidGlobalDomains(raw))
    const boxes = host.querySelectorAll<HTMLInputElement>('input[type=checkbox]')
    expect(boxes[0]!.checked).toBe(true); expect(boxes[1]!.checked).toBe(true)
  })

  it('never restores a preference into a different project or selected run', async () => {
    const raw = fixture()
    let displayed = raw
    const fetching = vi.spyOn(globalThis, 'fetch').mockImplementation(async (input: any) => String(input).startsWith('/api/liquid/results')
      ? json(displayed)
      : json({ grant: { payload: {}, signature: 'c'.repeat(64) } }))
    rememberLiquidDisplay('p', raw.run_id, { enabled: true, fixedScale: true })
    await act(async () => { await fetchLiquidResults() })
    const client = { loadLiquidResult: vi.fn(), setLiquidFrame: vi.fn() } as unknown as OvCommandClient
    await act(async () => root.render(<OvLiquidSection client={client} degraded={false} projectUid="other-project" />))
    expect(client.loadLiquidResult).not.toHaveBeenCalled()
    expect(host.querySelector<HTMLInputElement>('input[type=checkbox]')!.checked).toBe(false)
    displayed = { ...raw, run_id: 'a'.repeat(32) }
    await act(async () => { await fetchLiquidResults() })
    act(() => root.unmount()); root = createRoot(host)
    await act(async () => root.render(<OvLiquidSection client={client} degraded={false} projectUid="p" />))
    expect(client.loadLiquidResult).not.toHaveBeenCalled()
    expect(fetching.mock.calls.map(([input]) => String(input))).not.toContain('/api/ov/liquid-result-grant')
  })

  it('discards a grant that returns after the old viewer unmounts', async () => {
    const raw = fixture()
    let grantDone!: (response: Response) => void
    const waiting = new Promise<Response>(resolve => { grantDone = resolve })
    vi.spyOn(globalThis, 'fetch').mockImplementation(async (input: any) => String(input).startsWith('/api/liquid/results') ? json(raw) : waiting)
    rememberLiquidDisplay('p', raw.run_id, { enabled: true, fixedScale: true })
    await act(async () => { await fetchLiquidResults() })
    const client = { loadLiquidResult: vi.fn(), setLiquidFrame: vi.fn() } as unknown as OvCommandClient
    await act(async () => { root.render(<OvLiquidSection client={client} degraded={false} projectUid="p" />); await new Promise(r => setTimeout(r, 0)) })
    act(() => root.unmount()); root = createRoot(host)
    await act(async () => { grantDone(json({ grant: { payload: {}, signature: 'd'.repeat(64) } })); await new Promise(r => setTimeout(r, 0)) })
    expect(client.loadLiquidResult).not.toHaveBeenCalled()
    expect(client.setLiquidFrame).not.toHaveBeenCalled()
  })

  it('refuses to offer colouring for a legacy result without bindings', async () => {
    vi.spyOn(globalThis, 'fetch').mockImplementation(async () => json({ converged: true, time_s: [0], rack_summaries: [] }))
    await act(async () => { await fetchLiquidResults() })
    const client = {} as OvCommandClient
    await act(async () => root.render(<OvLiquidSection client={client} degraded={false} />))
    expect(host.querySelector<HTMLInputElement>('input[type=checkbox]')!.disabled).toBe(true)
    expect(host.textContent).toMatch(/hybrid/)
  })
})

it('rack manifolds and their stubs export their side as liquidPart, and the schema accepts it', async () => {
  const { validateSceneSnapshot: validateScene } = await import('../src/renderer/validateScene')
  const root = new THREE.Group()
  const mk = (userData: Record<string, unknown>) => { const m = new THREE.Mesh(new THREE.BoxGeometry(1, 1, 1), new THREE.MeshStandardMaterial()); m.userData = userData; root.add(m); return m }
  mk({ isLiquidManifold: true, pipeType: 'supply', modelId: 'rack-1' })
  mk({ isLiquidManifold: true, stubType: 'return', modelId: 'rack-1' })
  mk({ modelId: 'rack-1' })
  const packet = buildSceneSnapshot({ root, project: { uid: 'p' } })
  expect(packet.primitives.map(p => p.liquidPart ?? null)).toEqual(['supply-manifold', 'return-manifold', null])
  expect(() => validateScene(packet)).not.toThrow()
  const bad = JSON.parse(JSON.stringify(packet)); bad.primitives[0].liquidPart = 'chiller'
  expect(() => validateScene(bad)).toThrow(/schema/i)
})


it('a fixed colour scale spans every sample of both scales', () => {
  const raw = fixture()
  const g = liquidGlobalDomains(raw)
  const frames = [0, 1, 2].map(s => liquidFrame(raw, s)!.domains)
  expect(g.network).toEqual([Math.min(...frames.map(f => f.network![0])), Math.max(...frames.map(f => f.network![1]))])
  expect(g.chips).toEqual([Math.min(...frames.map(f => f.chips![0])), Math.max(...frames.map(f => f.chips![1]))])
})
