
"""Repository boundary for bridge-created display textures (no Kit imports)."""
import os
from pathlib import Path


def render_texture_cache_path(environment=None):
    """Require an explicit checkout-local path before any texture write.

    The normal owner supplies its own runtime/render-textures. Direct bridge
    use must opt into a repository path too; cwd and inherited /tmp defaults
    must never decide where product-created textures are written.
    """
    environment = os.environ if environment is None else environment
    value = environment.get("DCDTUNI_RENDER_TEXTURE_CACHE")
    if not isinstance(value, str) or not value.strip():
        raise ValueError("DCDTUNI_RENDER_TEXTURE_CACHE must explicitly name a directory inside this checkout")
    candidate = Path(value)
    if not candidate.is_absolute():
        raise ValueError("DCDTUNI_RENDER_TEXTURE_CACHE must be an absolute directory inside this checkout")
    root = Path(__file__).resolve().parents[9]
    resolved = candidate.resolve()
    if not resolved.is_relative_to(root):
        raise ValueError("DCDTUNI_RENDER_TEXTURE_CACHE must stay inside this checkout")
    return str(resolved)
