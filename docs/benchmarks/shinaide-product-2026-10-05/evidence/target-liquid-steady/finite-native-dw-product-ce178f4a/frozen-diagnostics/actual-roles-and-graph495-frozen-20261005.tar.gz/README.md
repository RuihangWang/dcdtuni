# Actual written zone/coupled screen and native D/W graph replay

This is a read-only metadata audit of the actual R0 written mesh from job 495546f2. The product still has stock Failed2: D909/W100, R0. These counts describe a failed mesh, not acceptance. No point proposal, quality evaluation, optimizer, native process, API, browser, source change or index operation was run here.

## Actual zones and scope of the old screen

All eight current polyMesh ranks contain zero cellZones, zero pointZones and five empty faceZones. Consequently there are zero examples of a homogeneous **nonempty actual written** cellZone cavity in this mesh. The earlier P classification's touchedSourceZone is a trace/source-face classification, not a written cellZone membership. Removing that old screening condition does not authorize movement of a written zone boundary.

The full historical D/W/R seed pool has 2,410 distinct rank-local points. Binary face incidence was rebuilt over the whole actual rank, and complete core and outside cells were rebuilt from owner/neighbour. The original P topology/point-star identities and all current D/W set SHA values match. Current point coordinates are bound to the actual 495 binary64 files; the four accepted R-prefix changes are read from the exact delta receipt rather than built into the selector.

The old P screen admitted 307 free triangular interior points; current topology/role/cap qualification admits 340. Of the 33 additions, 30 had only the old trace-source-zone rejection, one had only outside-coupled rejection and two had both. The three outside-coupled additions have no coupled owner in their core. They are only metadata-eligible: eventual outside CC/V identity and the earliest coupled certificate still have to hold after any movement.

Direct bad-D incident coverage rises from 584 to 689 (+105), and complete adjacent bad-W coverage from 77 to 79 (+2). Of the old 291 no-internal/no-flat D cases, 103 acquire this necessary point qualification. This is not a prediction of 105 repaired cells or two repaired faces. The old screen's exclusions do not prove the other cells mathematically irreparable.

## Native-equivalent seed co-occurrence graph

The graph uses every initial bad-D cell and both actual owner/neighbour cells of every initial bad-W and bad-R face. Original R2 seeds remain because the native selector runs against the earliest installed oracle before its accepted R prefix; current R0 does not erase those original seed cells. Points are connected only when they coexist in one such seed cell. Opposite face sides are never connected merely by concatenating two stars.

The complete current seed-cell vertex pool equals the original P point pool on every rank. The graph prefilter is recomputed from actual written roles: no boundary point, no nontriangular incident face, no coupled-owner cell in the complete core, point-star <=512, core <=128, actual zones empty, finite coordinates. It is separately asserted equal to the full-stencil census qualification on these inputs.

There are 1,052 rank-local seed cells, 2,410 examined points and 340 graph nodes total. Every per-rank seed4096/examined8192/graph512 cap fits; those limits are per rank, not global. Components are 327 singletons, one two-node, one three-node and two K2,2 components. All 33 newly qualified points are singletons. Thus they change necessary D/W coverage but do not add a nine-parameter component in the present grammar.

The three-node component selects [23651,569594,569592] through incident-valence and world-coordinate ordering. Its proposal has 131 core cells, and joining the actual accepted R prefix produces 158. Both exceed the core128 cap; score29 is not allowed to shadow an admissible smaller mode.

The two K2,2 modes remain:

| Moving set | Proposal core/outside/faces/points | R-prefix joint core/outside/faces/points | Joint second halo | Score |
|---|---|---|---|---|
| 23237,42335,569586 | 71 / 43 / 280 / 54 | 98 / 64 / 415 / 89 | 102 | 6 D + 1 W = 7 |
| 23239,42338,569589 | 73 / 44 / 286 / 54 | 100 / 65 / 421 / 89 | 101 | 6 D + 1 W = 7 |

All core and outside cell faces and their vertex sets are retained; second-halo cells are actual endpoints outside those complete core/outside cells, not an assumed ideal neighborhood. Both K2 proposals and both R-prefix joint stencils satisfy the metadata caps and core-coupled/actual-zone gates. They do not yet satisfy a candidate quality or installed-DP proof.

Both have the same priority score; world-coordinate lexicographic order chooses [23237,42335,569586]. Labels in this table are evidence identities only. The replay's selection rule uses component topology, complete point-star valence and actual coordinates. It contains no case/native-label/success-coordinate selector predicate. The R-prefix identities are derived from changedPoints in the current binary delta receipt.

## Files and reproduction

- audit_actual_roles.py / actual-role-census.json: eight-rank actual binary role/incidence/cap census and all point rows.
- recovered-points-and-graph.json: the 33 additions and old-reason/direct-coverage decomposition.
- actual-role-census-with-graph.json: the first component derivation, retained as an intermediate snapshot.
- derive_graph_and_caps.py / native-equivalent-graph-and-caps.json: reproducible actual seed graph, complete proposal/joint/second-halo topology and selection ordering.
- observed-v4-selector.H: a copied WIP source observation, not promoted production or a final source certification.
- source-and-command-identity.json: current refs, reader/source/receipt SHA bindings and exact command.
- manifest.json: every owned payload's bytes/SHA.

Run only the isolated Python metadata script, with CPU36–39, CUDA empty and no bytecode. The exact absolute command is in source-and-command-identity.json. It rechecks all 88 original census input bindings before reading, derives accepted-prefix identities from actual delta metadata, and copies the currently observed WIP header into this directory. Therefore an independent rerun should use a new output copy if preserving this frozen audit; production source is never changed.

## Remaining unproved obligations

No candidate was moved. There is no new compact-vs-installed arithmetic binding, positive-tet/concavity/volume/moment proof, passing-role/no-new quality proof, outside DP identity after movement, global point-gap validation, N-ceiling check, stage-time availability proof, final MPI cache refresh or final writer-certificate acceptance. This audit only removes misleading source-zone attribution and provides the actual graph and cap inputs for an independently verified implementation. The optional cross-parent union search was deferred while this metadata task took priority.

The observed V4 header is explicitly WIP. The immutable first 28f590c2 snapshot and the observed later header have separate hashes. Source ranges in the JSON are navigation hints; the copied header hash is the identity. Clock checks are not simulated by a metadata-only replay. A 300-second watchdog is an upper lifetime control and does not make this failed mesh successful.
