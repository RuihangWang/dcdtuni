from pathlib import Path
import sys,json,re,hashlib,collections,time,datetime,numpy as np
B=Path('/mnt/lv/home/litianyu/mycode/dcdtuni');T=B/'.codex-tmp/goal-20261005/integration';A=B/'.codex-tmp/goal-20261005/air'
O=T/'.codex-tmp/actual-zone-and-coupled-screen-20261005';M=T/'.codex-tmp/cases/Shinaide_PointRepairR_CUA/Mesh'
sys.path[:0]=[str(T/'tools'),str(T/'src')]
from audit_air_mesh_geometry import Geometry
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def cfaces(g,c):return g.cell_faces[g.cell_offsets[c]:g.cell_offsets[c+1]]
def coupled(kind):return kind in {'processor','processorCyclic','cyclic','cyclicAMI','cyclicACMI'}
bind={};out=[];tot=collections.Counter();start=time.monotonic()
classif=json.loads((A/'.codex-tmp/installed-writer-cua-7785c33f/classification.json').read_text());actualW={r['rank']:[f for f in r['failedFaces']if'W'in f['failedFlags']]for r in classif['ranks']}
for rank in range(8):
 tick=time.monotonic();poly=M/f'processor{rank}/constant/polyMesh';P=A/'.codex-tmp/shared-point-components-7785-20261005'/f'rank{rank}-mobility-bound.json'
 d=json.loads(P.read_text());bind[str(P)]=sha(P);zones={}
 for name in ['pointZones','cellZones','faceZones']:
  path=poly/name;raw=path.read_text();bind[str(path)]=sha(path)
  payload=raw[raw.index('// * * *'):].split('// ************************************************************************')[0]
  if name in ['pointZones','cellZones']:
   assert re.search(r'\n\s*0\s*\(\s*\)',payload),f'nonempty actual {name} unsupported by this census'
   zones[name]={'zones':0,'members':0}
  else:
   labels=re.findall(r'faceLabels\s+List<label>\s+(\d+)',payload)
   assert len(labels)==5 and all(int(n)==0 for n in labels),'nonempty actual faceZone unsupported by this census'
   zones[name]={'zones':5,'members':0,'names':re.findall(r'(?m)^([^\s{}()]+)\s*$',payload)[-5:]}
 for name in ['owner','neighbour','faces','boundary']:
  p=poly/name;value=sha(p);bind[str(p)]=value
  assert value==d['sourceBinarySHA256']['Mesh/'+str(p.relative_to(M))],f'current topology differs: {p}'
 for name in ['points','sets/underdeterminedCells','sets/lowWeightFaces']:
  p=poly/name;bind[str(p)]=sha(p)
  if name.startswith('sets/'):assert bind[str(p)]==d['sourceBinarySHA256']['Mesh/'+str(p.relative_to(M))]
 g=Geometry(poly);ninternal=len(g.neighbour)
 patchKinds={r[3]for r in g.patches};assert patchKinds<={'wall','patch','cyclic','processor','processorCyclic','empty','symmetry','symmetryPlane','wedge'}
 covered=np.zeros(g.n_faces-ninternal,dtype=bool);coOwners=set()
 for f,n,nm,k in g.patches:
  assert f>=ninternal and f+n<=g.n_faces
  covered[f-ninternal:f+n-ninternal]=True
  if coupled(k):coOwners.update(map(int,g.owner[f:f+n]))
 assert covered.all()
 pids=np.array([x['point']for x in d['pointRows']],dtype=np.int64)
 hits=np.flatnonzero(np.isin(g.vertices,pids,kind='table'));faceid=np.searchsorted(g.offsets[1:],hits,side='right')
 pf=collections.defaultdict(set)
 for q,f in zip(g.vertices[hits],faceid):pf[int(q)].add(int(f))
 rows=[];oldFree=set();newFree=set();recovered=set();outsideOnly=set()
 for old in d['pointRows']:
  q=old['point'];inc=np.array(sorted(pf[q]),dtype=np.int64)
  assert inc.tolist()==old['incidentFaces'],'actual complete incidence mismatch'
  core=set(map(int,g.owner[inc]));core.update(int(g.neighbour[f])for f in inc if f<ninternal)
  assert sorted(core)==old['coreCells']
  cf=np.unique(np.concatenate([cfaces(g,c)for c in core]))
  outside=set(map(int,g.owner[cf]));outside.update(int(g.neighbour[f])for f in cf if f<ninternal);outside-=core
  assert sorted(outside)==old['outsideCells']
  fullcf=np.unique(np.concatenate([cfaces(g,c)for c in core|outside]));allp=set()
  for f in fullcf:allp.update(map(int,g.ids(int(f))))
  boundary=bool(np.any(inc>=ninternal));tri=bool(np.all(np.diff(g.offsets)[inc]==3))
  cco=sorted(core&coOwners);oco=sorted(outside&coOwners)
  cap=len(core)<=128 and len(outside)<=256 and len(fullcf)<=2048 and len(allp)<=8192
  eligible=not boundary and tri and not cco and cap
  if old['freeInternalTrianglePointEligible']:oldFree.add(q)
  if eligible:newFree.add(q)
  if eligible and not old['freeInternalTrianglePointEligible']:recovered.add(q)
  if eligible and oco and not cco:outsideOnly.add(q)
  reasons=[]
  if boundary:reasons.append('boundaryPoint')
  if not tri:reasons.append('nonTriangularIncidentFace')
  if cco:reasons.append('coreCoupledOwner')
  if not cap:reasons.append('completeStencilCap')
  rows.append({'point':q,'nativePoint':old['nativePoint'],'actualCoordinate':g.points[q].tolist(),'oldReasons':old['reasons'],
   'currentTopologyRoleEligibleTriPoint':eligible,'oldStrongFreeEligible':old['freeInternalTrianglePointEligible'],
   'coreCells':sorted(core),'outsideCells':sorted(outside),'coreCoupledOwnerCells':cco,'outsideCoupledOwnerCells':oco,
   'counts':{'core':len(core),'outside':len(outside),'faces':len(fullcf),'points':len(allp)},
   'actualCellZoneMembershipEachCore':[],'homogeneousNonemptyCellZoneCandidate':False,'actualReasons':reasons})
 pointrow={x['point']:x for x in rows}
 D0={x['cell']for x in d['badD']if x['eligiblePoints']}
 D1={x['cell']for x in d['badD']if set(x['points'])&newFree}
 Drec=D1-D0
 W0=set();W1=set()
 for f in actualW[rank]:
  cs={f['owner']['cell'],f['neighbour']['cell']}
  if any(cs&set(x['coreCells'])for x in d['pointRows']if x['freeInternalTrianglePointEligible']):W0.add(f['face'])
  if any(cs&set(x['coreCells'])for x in rows if x['currentTopologyRoleEligibleTriPoint']):W1.add(f['face'])
 oldNor={x['cell']for x in d['badD']if not x['eligiblePoints'] and not x['hasTangentialNecessaryPoint']}
 summary={'rank':rank,'seedPointPool':len(rows),'oldStrongEligiblePoints':len(oldFree),'actualTriPointRoleCapEligible':len(newFree),
  'recoveredPoints':len(recovered),'eligibleOutsideOnlyCoupledPoints':len(outsideOnly),
  'oldEligibleDroppedByCurrent128Caps':len(oldFree-newFree),'oldDInternalCoverage':len(D0),'actualDPotentialTriCoverage':len(D1),
  'newDCoverageOutsideOldInternal':len(Drec),'fromOldNeither291':len(Drec&oldNor),'oldWCoverage':len(W0),
  'actualWPotentialTriCoverage':len(W1),'newWCoverageOutsideOld77':len(W1-W0),'nonemptyCellZoneCandidates':0,
  'elapsedSeconds':time.monotonic()-tick}
 tot.update({k:v for k,v in summary.items()if isinstance(v,int)and k!='rank'})
 out.append({'summary':summary,'zones':zones,'patchKinds':sorted(patchKinds),'recoveredPointIDs':sorted(recovered),
  'outsideOnlyCoupledEligiblePointIDs':sorted(outsideOnly),'recoveredDCellIDs':sorted(Drec),'recoveredWFaceIDs':sorted(W1-W0),'pointRows':rows})
 print(json.dumps(summary),flush=True)
 del g
report={'format':'actual495-zone-and-coupled-screen/v1','scope':'Read-only current binary topology/role/caps census of the full historical D/W/R seed-point pool. No metric evaluations, optimization, candidate movement or native acceptance.',
 'actualMesh':str(M),'inputSHA256':bind,'ranks':out,'totals':dict(tot),'elapsedSeconds':time.monotonic()-start,
 'zeroHomogeneousNonemptyZoneCandidates':True,
 'limitations':['Actual written cellZones/pointZones and all5 faceZone membership lists are empty on all8 ranks.',
 'P touchedSourceZone is a source trace marker, not actual written zone membership; it is not used as a native eligibility gate here.',
 'Outside-only coupled candidates remain potential eligibility only: actual DP outside state and earliest final writer certificate must hold after any proposal.',
 'Core coupled owner cells remain forbidden, including internal points not on coupled faces.',
 'Coverage uses complete owner/neighbour stars, fullcore/outside faces and current128/256/2048/8192 caps.',
 'Only the historical complete seed-point pool is classified; no whole-mesh point candidate expansion.',
 'Current geometry/finite/pointgap/minTetQuality/face planar guards and new graph/selector must be evaluated separately.']}
(O/'actual-role-census.json').write_text(json.dumps(report,indent=2)+'\n')
print('TOTAL',json.dumps(report['totals']),flush=True)
