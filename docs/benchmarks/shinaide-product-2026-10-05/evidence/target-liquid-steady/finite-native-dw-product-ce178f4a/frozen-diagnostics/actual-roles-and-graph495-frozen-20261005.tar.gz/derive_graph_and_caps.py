from pathlib import Path
import sys,json,hashlib,collections,itertools,math,time,numpy as np
B=Path('/mnt/lv/home/litianyu/mycode/dcdtuni')
T=B/'.codex-tmp/goal-20261005/integration';A=B/'.codex-tmp/goal-20261005/air'
O=T/'.codex-tmp/actual-zone-and-coupled-screen-20261005'
M=T/'.codex-tmp/cases/Shinaide_PointRepairR_CUA/Mesh'
sys.path[:0]=[str(T/'tools'),str(T/'src')]
from audit_air_mesh_geometry import Geometry
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def cfaces(g,c):return list(map(int,g.cell_faces[g.cell_offsets[c]:g.cell_offsets[c+1]]))
def key(p,rows):return tuple(rows[p]['actualCoordinate'])
def select_three(component,adj,rows,pf):
 component=set(component)
 if len(component)not in(3,4):return None
 if any(p not in rows or p not in adj for p in component):return None
 coords=[key(p,rows)for p in component]
 if any(len(c)!=3 or not all(math.isfinite(x)for x in c)for c in coords)or len(set(coords))!=len(coords):return None
 if len(component)==3:return sorted(component,key=lambda p:(-len(pf[p]),key(p,rows)))
 if any(len(adj[p]&component)!=2 for p in component):return None
 candidates=[]
 for a,b in itertools.combinations(component,2):
  common=adj[a]&adj[b]&component
  if b in adj[a]or common!=component-{a,b}:continue
  hubs=sorted([a,b],key=lambda p:(-len(pf[p]),key(p,rows)))
  candidates.append((-(len(pf[a])+len(pf[b])),tuple(key(p,rows)for p in hubs),hubs,common))
 if not candidates:return None
 _,_,hubs,common=min(candidates,key=lambda c:c[:2])
 return hubs+[min(common,key=lambda p:key(p,rows))]
def stencil(g,moving,pf,coOwners):
 core=set()
 for p in moving:
  for f in pf[p]:
   core.add(int(g.owner[f]))
   if f<len(g.neighbour):core.add(int(g.neighbour[f]))
 cf=set().union(*(set(cfaces(g,c))for c in core))
 outside=set()
 for f in cf:
  if f<len(g.neighbour):
   a,b=int(g.owner[f]),int(g.neighbour[f])
   if a not in core:outside.add(a)
   if b not in core:outside.add(b)
 fs=cf|set().union(*(set(cfaces(g,c))for c in outside))
 pts=set().union(*(set(map(int,g.ids(f)))for f in fs))
 second=set()
 for f in fs:
  for c in [int(g.owner[f])]+([int(g.neighbour[f])]if f<len(g.neighbour)else[]):
   if c not in core and c not in outside:second.add(c)
 counts=dict(core=len(core),outside=len(outside),faces=len(fs),points=len(pts),secondHaloCells=len(second))
 capReasons=[]
 for k,cap in [('core',128),('outside',256),('faces',2048),('points',8192)]:
  if counts[k]>cap:capReasons.append(k+'Cap')
 if core&coOwners:capReasons.append('coreOwnsCoupledFace')
 coords=g.points[list(pts)];scale=float(np.ptp(coords,axis=0).max())if len(pts)else 0
 if not np.isfinite(coords).all()or not math.isfinite(scale)or scale<=3e-6:capReasons.append('nonfiniteOrTinyScale')
 return dict(movingPoints=list(map(int,moving)),counts=counts,coreCells=sorted(core),outsideCells=sorted(outside),
  fullFaceIDs=sorted(fs),fullPointIDs=sorted(pts),secondHaloCells=sorted(second),
  coreCoupledOwnerCells=sorted(core&coOwners),outsideCoupledOwnerCells=sorted(outside&coOwners),
  actualAllParticipatingCellZoneMembershipEmpty=True,scaleM=scale,
  completeStencilTopologyRoleCapEligible=not capReasons,refusalReasons=capReasons)
def run():
 started=time.monotonic();censusPath=O/'actual-role-census.json';census=json.loads(censusPath.read_text())
 bindings=dict(census['inputSHA256']);bindings[str(censusPath)]=sha(censusPath)
 for p,h in bindings.items():assert sha(p)==h,'changed census input: '+p
 header=A/'.codex-tmp/finite-native-dw-v4-20261005/dcCartFinitePointRepair.H'
 headerRaw=header.read_bytes();headerHash=hashlib.sha256(headerRaw).hexdigest()
 frozenHeader=A/'.codex-tmp/finite-native-dw-v4-20261005/snapshot-v4-first/dcCartFinitePointRepair.H'
 bindings[str(frozenHeader)]=sha(frozenHeader)
 # Observed WIP reference is copied only to this isolated read-only report directory.
 (O/'observed-v4-selector.H').write_bytes(headerRaw)
 bindingProductionHelper=T/'tools/audit_air_mesh_geometry.py';bindings[str(bindingProductionHelper)]=sha(bindingProductionHelper)
 totals=collections.Counter();ranks=[];allModes=[]
 for rank,rd in enumerate(census['ranks']):
  pdpath=A/'.codex-tmp/shared-point-components-7785-20261005'/f'rank{rank}-mobility-bound.json'
  pd=json.loads(pdpath.read_text());rows={r['point']:r for r in rd['pointRows']};oldRows={r['point']:r for r in pd['pointRows']}
  poly=M/f'processor{rank}/constant/polyMesh';g=Geometry(poly)
  coOwners=set()
  for f,n,nm,kind in g.patches:
   if kind in {'processor','processorCyclic','cyclic','cyclicAMI','cyclicACMI'}:coOwners.update(map(int,g.owner[f:f+n]))
  badD={int(r['cell'])for r in pd['badD']};badW=set(map(int,pd['badWeightFaces']));oldR=set(map(int,pd['badRatioFaces']))
  seeds=set(badD)
  for f in badW|oldR:
   seeds.add(int(g.owner[f]))
   if f<len(g.neighbour):seeds.add(int(g.neighbour[f]))
  seedPoints=set().union(*(set(map(int,g.ids(f)))for c in seeds for f in cfaces(g,c)))
  assert seedPoints==set(rows),'historical point pool does not equal all current seed vertices'
  pids=np.array(sorted(seedPoints),dtype=np.int64)
  hits=np.flatnonzero(np.isin(g.vertices,pids,kind='table'))
  faceID=np.searchsorted(g.offsets[1:],hits,side='right')
  pf=collections.defaultdict(set)
  for j,f in zip(hits,faceID):pf[int(g.vertices[j])].add(int(f))
  for p in rows:
   assert pf[p]==set(oldRows[p]['incidentFaces'])
  # Current v4 pregraph eligibility is all-boundary/actual-written-zone,
  # all-triangle incident point-star <=512, complete core <=128,
  # no coupled face owner in the core. All actual zone memberships are empty.
  free={p for p,r in rows.items()if not any(z in r['actualReasons']for z in
   ['boundaryPoint','nonTriangularIncidentFace','coreCoupledOwner'])
   and len(pf[p])<=512 and len(r['coreCells'])<=128 and all(math.isfinite(x)for x in r['actualCoordinate'])}
  assert free=={p for p,r in rows.items()if r['currentTopologyRoleEligibleTriPoint']}, 'full stencil census and exact pregraph mask disagree'
  assert len(free)==rd['summary']['actualTriPointRoleCapEligible']
  bycell=collections.defaultdict(set)
  for p in free:
   for c in rows[p]['coreCells']:
    if c in seeds:bycell[c].add(p)
  adj={p:set()for p in free}
  for ps in bycell.values():
   for p in ps:adj[p].update(ps-{p})
  visited=set();components=[]
  for p in sorted(free,key=lambda p:key(p,rows)):
   if p in visited:continue
   todo=[p];visited.add(p);comp=set()
   while todo:
    q=todo.pop();comp.add(q)
    for z in adj[q]-visited:visited.add(z);todo.append(z)
   components.append(comp)
  recovered=set(rd['recoveredPointIDs'])
  assert all(len(c)==1 for c in components if c&recovered)
  graphCaps=dict(seeds=len(seeds),examinedPoints=len(seedPoints),graphNodes=len(free))
  assert graphCaps['seeds']<=4096 and graphCaps['examinedPoints']<=8192 and graphCaps['graphNodes']<=512
  deltaPath=T/'docs/benchmarks/shinaide-product-2026-10-05/evidence/target-liquid-steady/finite-native-product-495546f2/written-point-and-topology-delta.json'
  delta=json.loads(deltaPath.read_text());bindings[str(deltaPath)]=sha(deltaPath)
  # Prefix identity is read from the actual binary-delta receipt, never a selector label rule.
  prefixRows=[x for x in delta['changedPoints']if x['rank']==rank]
  originalRP=sorted(x['point']for x in prefixRows)
  assert sha(poly/'points')==delta['ranks'][rank]['newPointsSHA256']
  for x in prefixRows:assert g.points[x['point']].tobytes()==np.array(x['new'],dtype=np.float64).tobytes()
  for point,r in rows.items():assert g.points[point].tobytes()==np.array(r['actualCoordinate'],dtype=np.float64).tobytes()
  # Prefix moving point stars are rebuilt from the actual current binary.
  need=set(originalRP)
  for comp in components:
   sel=select_three(comp,adj,rows,pf)
   if sel:need.update(sel)
  if need-set(pf):
   pp=np.array(sorted(need-set(pf)),dtype=np.int64)
   hit=np.flatnonzero(np.isin(g.vertices,pp,kind='table'))
   fid=np.searchsorted(g.offsets[1:],hit,side='right')
   for j,f in zip(hit,fid):pf[int(g.vertices[j])].add(int(f))
  modes=[]
  for comp in components:
   sel=select_three(comp,adj,rows,pf)
   if not sel:continue
   prop=stencil(g,sel,pf,coOwners)
   joint=stencil(g,sorted(set(sel)|set(originalRP)),pf,coOwners)
   scoreD=sorted(set(prop['coreCells'])&badD)
   scoreW=sorted(set(prop['fullFaceIDs'])&badW)
   coordKey=[x for p in sel for x in key(p,rows)]
   mode=dict(rank=rank,componentPoints=sorted(comp),adjacency={str(p):sorted(adj[p]&comp)for p in sorted(comp)},
    selectedPoints=sel,selectedCoordinates=[list(key(p,rows))for p in sel],
    completePointStarValences={str(p):len(pf[p])for p in sorted(comp)},dimension=9,
    proposal=prop,jointWithActualAcceptedRPrefix=joint,
    acceptedRPrefixMovingPoints=originalRP,
    earliestBadDCoreIDs=scoreD,earliestBadWCompleteStencilIDs=scoreW,
    nativePriorityScore=len(scoreD)+len(scoreW),nativeGeometryKey=coordKey,
    prefiltered=prop['completeStencilTopologyRoleCapEligible']and joint['completeStencilTopologyRoleCapEligible'],
    noQualityAcceptanceClaim=True)
   modes.append(mode)
  admissible=[m for m in modes if m['prefiltered']and m['nativePriorityScore']]
  ordered=sorted(admissible,key=lambda m:(-m['nativePriorityScore'],m['nativeGeometryKey']))
  ambiguous=bool(ordered and any(m['nativePriorityScore']==ordered[0]['nativePriorityScore']and m['nativeGeometryKey']==ordered[0]['nativeGeometryKey']for m in ordered[1:]))
  chosen=[]if ambiguous or not ordered else ordered[0]['selectedPoints']
  rankSummary=dict(rank=rank,graphCaps=graphCaps,componentSizeCounts=dict(collections.Counter(str(len(c))for c in components)),
   components=[sorted(c)for c in components],adjacency={str(p):sorted(adj[p])for p in sorted(adj)},
   completeSeedCellIDs=sorted(seeds),completeExaminedPointIDs=sorted(seedPoints),
   originalBadDCount=len(badD),originalBadWCount=len(badW),originalBadRCount=len(oldR),
   new33AllSingletonHere=True,maximumEligiblePointStarValence=max([len(pf[p])for p in free]or[0]),
   selected9Modes=modes,prefilteredPriorityOrderedMovingSets=[m['selectedPoints']for m in ordered],
   metadataChosenMovingSet=chosen,geometryTieAmbiguous=ambiguous,
   unavailableClockNotSimulated=True)
  ranks.append(rankSummary);allModes+=modes
  totals.update({str(len(c)):1 for c in []})
  totals['graphNodes']+=len(free);totals['examinedPoints']+=len(seedPoints);totals['seeds']+=len(seeds)
  for c in components:totals['componentSize'+str(len(c))]+=1
  del g
 return dict(format='actual495-native-DW-graph-role-cap-replay/v1',
  scope='Metadata-only replay against current R0 written topology and actual written zones. Initial D/W sets are unchanged; original R2 seeds are retained because native census runs before its R prefix. No metric recomputation, proposal evaluation, optimizer, native execution, or quality acceptance.',
  actualMesh=str(M),ranks=ranks,totals=dict(totals),inputSHA256=bindings,
  observedV4WIP=dict(path=str(header),sha256=headerHash,bytes=len(headerRaw),copiedObservedSnapshot=str(O/'observed-v4-selector.H'),
   notFinalProductionSource=True,sourceRanges=['CensusCaps235-250','selectInteriorNine258-319','Stencil532-628','selectDWMode1011-1193']),
  limits=dict(seedCells4096=4096,examinedPoints8192=8192,graphNodes512=512,pointStarFaces512=512,
   core128=128,outside256=256,fullFaces2048=2048,points8192=8192),
  explicitMissingChecks=['all DP compact-vs-installed formula binding','actual candidate positive tet/geometry/closed volume/moment',
   'passing-role retention and no-new quality','outside DP identity after movement','N ceiling','global gap','budget availability','final MPI refresh and writer certificate'],
  elapsedSeconds=time.monotonic()-started)
if __name__=='__main__':
 d=run();(O/'native-equivalent-graph-and-caps.json').write_text(json.dumps(d,indent=2)+'\n')
 print(json.dumps(dict(totals=d['totals'],modeSummaries=[dict(rank=r['rank'],chosen=r['metadataChosenMovingSet'],
  caps=r['graphCaps'],modes=[dict(moving=m['selectedPoints'],score=m['nativePriorityScore'],D=len(m['earliestBadDCoreIDs']),
   W=len(m['earliestBadWCompleteStencilIDs']),proposal=m['proposal']['counts'],
   joint=m['jointWithActualAcceptedRPrefix']['counts'],prefiltered=m['prefiltered'])for m in r['selected9Modes']])
  for r in d['ranks']],elapsedSeconds=d['elapsedSeconds'],observedWIP=d['observedV4WIP']['sha256']),indent=2))
