# Semantic role scope addendum

The accompanying actual-role census records **only the current installed/written polyMesh role arrays**. Empty actual cellZones, pointZones and faceZone memberships do not refute the meaning of TRACE sourceZone, nor do they certify that downstream topoSet, porous, baffle, material or planned physical-interface assignments are absent. Their semantic identity and subsequent application have not been independently audited by this metadata replay.

The 33 additions are points passing the stated current-written topology/role/cap screen after the old source-trace/outside-coupled screen is separated. This is a descriptive census, **not authorization to move them**. Before any future point repair uses such additions, it needs the relevant planned material/zone/BC-interface compatibility and the complete old roles preserved. All 33 are singleton components and none is selected by the present nine-parameter grammar.

The two K2,2 modes actually selected/prioritized in this audit were already present under the old strong P source-role screening. This metadata report adds no new native proposal acceptance for them. Their future installed guard, final writer certificate and full stock quality remain mandatory.

The same restriction applies to any future cross-source-parent two-/three-/four-cell cavity union: actual-empty zone arrays alone are insufficient. Same fluid/material/planned-zone semantics and physical/coupled shell roles must be established; source-parent equality may be a selector restriction but removing it does not remove semantic obligations.

This addendum is deliberately separate: the first nine payloads and first manifest (83b7d7b5752693d5280bf415a50a7766b7659afc2059668a91d20c11e1f92d4c) retain their original frozen bytes. manifest-v2.json binds those bytes, the first manifest itself and this clarification. No source/mesh/proposal/native/index operation was performed.
