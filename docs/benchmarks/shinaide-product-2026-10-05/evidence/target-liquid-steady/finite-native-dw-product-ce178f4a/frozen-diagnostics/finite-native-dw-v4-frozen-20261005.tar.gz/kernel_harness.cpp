
#define DCCART_FINITE_REPAIR_KERNEL_ONLY
#include "dcCartFinitePointRepair.H"
#include <iostream>
#include <iomanip>
#include <string>
using namespace dcCartFiniteRepairKernel;
int main()
{
    std::cout<<std::setprecision(17);
    std::string command;std::cin>>command;
    if (command=="project")
    {
        unsigned n,m,updates;std::cin>>n>>m>>updates;
        Row desired(n),b(m);Matrix a(m,Row(n));
        for(double& x:desired) std::cin>>x;
        for(unsigned i=0;i<m;++i) {for(double& x:a[i])std::cin>>x;std::cin>>b[i];}
        auto out=project(desired,a,b,updates);
        std::cout<<out.feasible<<' '<<out.updates;
        for(double x:out.step)std::cout<<' '<<x;
        std::cout<<'\n';return 0;
    }
    if (command=="select")
    {
        unsigned n,m;int target;std::cin>>n>>m>>target;
        std::vector<XYZ> p(n);std::vector<Face> f(m);
        std::vector<std::vector<int>> pf(n);
        for(auto& x:p)for(double& v:x)std::cin>>v;
        for(unsigned i=0;i<m;++i)
        {
            unsigned k;int protectedFace;std::cin>>k>>protectedFace;
            f[i].protectedFace=protectedFace;f[i].points.resize(k);
            for(int& v:f[i].points){std::cin>>v;pf[v].push_back(i);}
        }
        const auto mode=select(p,f,pf,target);
        std::cout<<mode.dimension<<' '<<mode.pivot<<' '<<mode.pairA<<' '<<mode.pairB<<' '<<mode.axis<<'\n';
        return 0;
    }
    if (command=="propose" || command=="proposecount")
    {
        unsigned n;std::cin>>n; const bool countKind=command=="proposecount";
        auto evaluation=[](const Row& q)
        {
            std::cout<<"eval";
            for(double x:q)std::cout<<' '<<x;
            std::cout<<std::endl;
            Evaluation e;unsigned count;int valid;
            std::cin>>valid>>e.objective>>count;
            e.valid=valid;e.constraints.resize(count);
            for(double& x:e.constraints)std::cin>>x;
            if (!std::cin) e.valid=false;
            return e;
        };
        auto out=propose(n,evaluation,[](){return true;},countKind ? ObjectiveKind::DWeightCount : ObjectiveKind::Ratio);
        std::cout<<"done "<<out.requests<<' '<<out.iterations<<' '<<out.improved;
        for(double x:out.parameters)std::cout<<' '<<x;
        std::cout<<std::endl;
        if (countKind) std::cout<<"stopflags "<<out.stoppedByRequestCap<<' '
            <<out.stoppedByTimeBudget<<' '<<out.stoppedByBudget<<std::endl;
        return 0;
    }

    if (command=="dwselect")
    {
        unsigned n;std::cin>>n;
        std::vector<DWPoint> nodes(n);std::vector<std::vector<unsigned>> graph(n);
        for (unsigned i=0;i<n;++i)
        {
            int allowed;std::cin>>nodes[i].id>>nodes[i].valence>>allowed;
            nodes[i].eligible=allowed;
            for(double& x:nodes[i].coordinates)std::cin>>x;
            unsigned count;std::cin>>count;graph[i].resize(count);
            for(unsigned& j:graph[i])std::cin>>j;
        }
        const auto selected=selectInteriorNine(nodes,graph);
        std::cout<<selected.size();
        for(Id id:selected)std::cout<<' '<<id;
        std::cout<<'\n';return 0;
    }


    if (command=="prefix")
    {
        PrefixRoles p;
        bool first=p.capture({1},{.0005},{9},{{{.04,.009,5.0}}});
        bool second=p.capture({1},{.0011},{9},{{{.06,.011,3.0}}});
        bool good=p.holds({1},{.001},{9},{{{.05,.01,4.0}}});
        bool badD=p.holds({1},{.000999999998},{9},{{{.05,.01,4.0}}});
        bool badW=p.holds({1},{.001},{9},{{{.04999999999,.01,4.0}}});
        bool badR=p.holds({1},{.001},{9},{{{.05,.00999999999,4.0}}});
        bool badS=p.holds({1},{.001},{9},{{{.05,.01,4.000000001}}});
        bool missing=p.holds({}, {}, {}, {});
        std::cout<<first<<second<<good<<badD<<badW<<badR<<badS<<missing<<'\n';
        return 0;
    }



    if (command=="censuscaps")
    {
        CensusCaps a,b,c,invalid;
        bool seeded=true,points=true,nodes=true;
        for (Id i=0;i<4096;++i) seeded=seeded && a.seed(i);
        for (Id i=0;i<8192;++i) points=points && b.point(i);
        for (Id i=0;i<512;++i) nodes=nodes && c.node(i);
        std::cout<<seeded<<a.seed(0)<<a.seed(4096)<<a.node(1)
            <<points<<b.point(0)<<b.point(8192)<<b.seed(1)
            <<nodes<<c.node(0)<<c.node(512)<<c.point(1)
            <<invalid.seed(-1)<<invalid.seed(1)<<'\n';
        return 0;
    }

    if (command=="dwnegative")
    {
        std::vector<DWPoint> nodes{{1,{{0,0,0}},2,true},{2,{{1,0,0}},2,true},{3,{{2,0,0}},2,true}};
        std::vector<std::vector<unsigned>> graph{{1},{0,2},{1}};
        auto bad=nodes;bad[0].coordinates[0]=std::numeric_limits<double>::quiet_NaN();
        std::cout<<selectInteriorNine(bad,graph).empty();
        bad=nodes;bad[0].eligible=false;
        std::cout<<selectInteriorNine(bad,graph).empty();
        bad=nodes;bad[0].valence=0;
        std::cout<<selectInteriorNine(bad,graph).empty();
        bad=nodes;bad[0].id=bad[1].id;
        std::cout<<selectInteriorNine(bad,graph).empty();
        bad=nodes;bad[0].coordinates=bad[1].coordinates;
        std::cout<<selectInteriorNine(bad,graph).empty();
        unsigned calls=0;
        auto stop=propose(9,[&](const Row&){++calls;return Evaluation{};},
            [](){return false;},ObjectiveKind::DWeightCount);
        std::cout<<' '<<calls<<' '<<stop.requests<<' '<<stop.stoppedByBudget<<'\n';
        return 0;
    }
    if (command=="prefixinvalid")
    {
        PrefixRoles roles;roles.capture({1},{.0011},{9},{{{.06,.02,3}}});
        auto nan=std::numeric_limits<double>::quiet_NaN();
        std::cout<<roles.capture({2},{nan},{8},{{{.06,.02,3}}})
                 <<roles.capture({2,2},{.01,.01},{8},{{{.06,.02,3}}})
                 <<roles.capture({-2},{.01},{8},{{{.06,.02,3}}})
                 <<roles.holds({1},{nan},{9},{{{.06,.02,3}}})
                 <<roles.holds({1},{.01},{9,9},{{{.06,.02,3}},{{.06,.02,3}}})
                 <<roles.holds({1},{.01},{9},{{{.06,.02,3}}})<<'\n';
        return 0;
    }

    if (command=="edge")
    {
        auto empty=project({}, {}, {});
        auto invalid=project({1}, {{std::numeric_limits<double>::quiet_NaN()}}, {1});
        auto unconstrained=project({1,2}, {}, {});
        auto cap=project({-1}, {{1}}, {0},0);
        auto zero=project({1},{{0}},{-1});
        auto budget=propose(3,[](const Row&){return Evaluation{};},[](){return false;});
        std::cout<<empty.feasible<<invalid.feasible<<unconstrained.feasible
                 <<cap.feasible<<zero.feasible<<' '<<budget.requests<<'\n';return 0;
    }

    if (command=="roles")
    {
        unsigned n;double limit;int upper;std::cin>>n>>limit>>upper;
        Row a(n),b(n);
        for(double& x:a)std::cin>>x;
        for(double& x:b)std::cin>>x;
        std::cout<<preservesHardRoles(a,b,limit,bool(upper),1e-300)<<'\n';return 0;
    }
    if (command=="zones")
    {
        std::set<int> cells{1,2,8};
        std::vector<std::vector<int>> noZones,core{{1}},outside{{8}},other{{3,4}};
        std::cout<<intersectsCellZones(cells,noZones)<<intersectsCellZones(cells,core)
                 <<intersectsCellZones(cells,outside)<<intersectsCellZones(cells,other)<<'\n';
        return 0;
    }
    return 2;
}
