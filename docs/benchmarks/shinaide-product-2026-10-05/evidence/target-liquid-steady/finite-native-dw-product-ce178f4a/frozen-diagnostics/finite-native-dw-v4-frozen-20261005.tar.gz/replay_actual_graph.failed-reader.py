
"""Native-equivalent graph/priority replay using CTX actual495 written roles."""
from pathlib import Path
import json,hashlib,subprocess,sys,collections
HERE=Path(__file__).resolve().parent;A=HERE.parents[1]
CTX=A.parent/"integration/.codex-tmp/actual-zone-and-coupled-screen-20261005"
SOURCE=CTX/"actual-role-census-with-graph.json"
P=A/".codex-tmp/shared-point-components-7785-20261005"
N=A/".codex-tmp/shared-point-quality-7785-20261005"
sys.path[:0]=[str(A/"src"),str(N),str(N/"readers")]
from backend.aircooling.runner.polymesh_io import read_label_list
from audit_air_mesh_geometry import read_faces_csr
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def invoke(nodes,graph):
    lines=["dwselect "+str(len(nodes))]
    for i,r in enumerate(nodes):
        lines.append(" ".join(map(str,[r["point"],r["valence"],1,*r["xyz"],len(graph[i]),*graph[i]])))
    raw=subprocess.check_output([str(HERE/"kernel_harness")],input="\n".join(lines)+"\n",text=True)
    values=list(map(int,raw.split()))
    assert values[0]==len(values)-1
    return values[1:]
def run():
    original=SOURCE.read_bytes();census=json.loads(original)
    assert all(sha(path)==value for path,value in census["inputSHA256"].items())
    ranks=[]
    for rank,rd in enumerate(census["ranks"]):
        old=json.loads((P/f"rank{rank}-mobility-bound.json").read_text())
        prior={r["point"]:r for r in old["pointRows"]}
        rows={r["point"]:r for r in rd["pointRows"]}
        free={p for p,r in rows.items() if r["currentTopologyRoleEligibleTriPoint"]}
        seeds=set(old["seedCells"])
        bycell=collections.defaultdict(set)
        for p in free:
            for c in rows[p]["coreCells"]:
                if c in seeds:bycell[c].add(p)
        graph={p:set() for p in free}
        for points in bycell.values():
            for p in points:graph[p].update(points-{p})
        visited=set();comps=[]
        for p in sorted(free,key=lambda q:rows[q]["actualCoordinate"]):
            if p in visited:continue
            comp=[];todo=[p];visited.add(p)
            while todo:
                z=todo.pop();comp.append(z)
                for q in graph[z]-visited:visited.add(q);todo.append(q)
            comps.append(comp)
        expected={frozenset(c) for c in rd["actualRoleCandidateGraph"]["components"]}
        assert {frozenset(c) for c in comps}==expected
        oldD={r["cell"] for r in old["badD"]};oldW=set(old["badWeightFaces"])
        rawPrefix=json.loads((HERE/"pure9-replay.json").read_text())["actualRPrefixDependency"]
        moved=[r["point"] for r in rawPrefix["actualPrefix"] if r["rank"]==rank]
        prefCore=set().union(*(set(rows[p]["coreCells"]) for p in moved)) if moved else set()
        candidates=[]
        ownerPath=Path(census["actualMesh"])/f"processor{rank}/constant/polyMesh/owner"
        own=read_label_list(ownerPath);nei=read_label_list(ownerPath.with_name("neighbour"))
        offsets,vertices=read_faces_csr(ownerPath.with_name("faces"))
        # Derive actual owner/neighbour cell-face incidence once to reproduce
        # complete candidate/joint caps, rather than only counting stored points.
        incid=collections.defaultdict(list)
        needed=set()
        for r in rows.values():needed.update(r["coreCells"]);needed.update(r["outsideCells"])
        for f,c in enumerate(own):
            if int(c) in needed:incid[int(c)].append(f)
        for f,c in enumerate(nei):
            if int(c) in needed:incid[int(c)].append(f)
        def counts(selected):
            core=set().union(*(set(rows[p]["coreCells"]) for p in selected))
            outside=set().union(*(set(rows[p]["outsideCells"]) for p in selected))-core
            faces=set().union(*(set(incid[c]) for c in core|outside))
            points=set()
            for f in faces:points.update(map(int,vertices[offsets[f]:offsets[f+1]]))
            return core,outside,faces,points
        for comp in comps:
            if len(comp) not in (3,4):continue
            labels=sorted(comp);indices={p:i for i,p in enumerate(labels)}
            nodes=[{"point":p,"valence":len(prior[p]["incidentFaces"]),"xyz":rows[p]["actualCoordinate"]} for p in labels]
            selected=invoke(nodes,[[indices[q] for q in sorted(graph[p])] for p in labels])
            if not selected:continue
            core,outside,faces,points=counts(selected)
            jointCore,jointOutside,jointFaces,jointPoints=counts(selected+moved)
            fit=len(core)<=128 and len(outside)<=256 and len(faces)<=2048 and len(points)<=8192
            fitJoint=len(jointCore)<=128 and len(jointOutside)<=256 and len(jointFaces)<=2048 and len(jointPoints)<=8192
            score=len(core&oldD)+len(faces&oldW)
            key=[v for p in selected for v in rows[p]["actualCoordinate"]]
            candidates.append({"selectedPoints":selected,"dimension":9,"component":labels,
              "core":len(core),"outside":len(outside),"faces":len(faces),"points":len(points),
              "jointWithActualRPrefix":{"core":len(jointCore),"outside":len(jointOutside),"faces":len(jointFaces),"points":len(jointPoints)},
              "fitsProposalCaps":fit,"fitsJointCaps":fitJoint,"score":score,"geometryPriorityKey":key})
        order=sorted([r for r in candidates if r["fitsProposalCaps"] and r["fitsJointCaps"] and r["score"]>0],key=lambda r:(-r["score"],r["geometryPriorityKey"]))
        ranks.append({"rank":rank,"actualEligiblePoints":len(free),"componentSizeCounts":dict(collections.Counter(map(len,comps))),
            "censusBounds":{"seedCount":len(seeds),"examinedPointPool":len(rows),"graphNodes":len(free),
              "within4096_8192_512":len(seeds)<=4096 and len(rows)<=8192 and len(free)<=512},
            "automaticModes":candidates,"selectedOneMode":order[0] if order else None})
    assert SOURCE.read_bytes()==original
    value={"format":"V4-native-role-graph-pure-selector/v1",
      "inputSHA256":{str(SOURCE):hashlib.sha256(original).hexdigest(),**census["inputSHA256"]},
      "actualRoleScope":census["scope"],"actualEligibleTotal":sum(r["actualEligiblePoints"] for r in ranks),
      "ranks":ranks,"noMetricEvaluationOrNativeAcceptance":True,
      "sourceZoneTraceIsNotWrittenZone":True,"noNativeRun":True}
    assert value["actualEligibleTotal"]==340
    assert sum(r["selectedOneMode"] is not None for r in ranks)==1
    assert ranks[3]["selectedOneMode"]["selectedPoints"]==[23237,42335,569586]
    assert ranks[3]["selectedOneMode"]["jointWithActualRPrefix"]["core"]==98
    (HERE/"actual-native-graph-replay.json").write_text(json.dumps(value,indent=2)+"\n")
    print(json.dumps({"actualEligibleTotal":value["actualEligibleTotal"],"ranks":[{k:r[k] for k in ["rank","componentSizeCounts","selectedOneMode"]} for r in ranks]},indent=2))
if __name__=="__main__":run()
