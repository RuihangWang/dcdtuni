
"""Pure C++ finite search driven by the frozen Q real-stencil callback."""
from pathlib import Path
import sys,json,subprocess,hashlib,time,copy
import numpy as np
HERE=Path(__file__).resolve().parent
A=HERE.parents[1]
Q=A/".codex-tmp/finite-shared-point-dw-20261005"
P=A/".codex-tmp/shared-point-components-7785-20261005"
N=A/".codex-tmp/shared-point-quality-7785-20261005"
DELTA=Path("/mnt/lv/home/litianyu/mycode/dcdtuni/docs/benchmarks/shinaide-product-2026-10-05/evidence/target-liquid-steady/finite-native-product-495546f2/written-point-and-topology-delta.json")
sys.path.insert(0,str(Q))
import compact_formula_evaluator as E
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def dependency():
    delta=json.loads(DELTA.read_text())
    assert sha(DELTA)=="c271bd49da2689a49f74655bf854f91a5cf80ddb9216cc7756c54b28d728634c"
    rows=json.loads((P/"rank3-mobility-bound.json").read_text())
    rank3=next(r for r in delta["changedPoints"] if r["rank"]==3)
    pointRow=next(r for r in rows["pointRows"] if r["point"]==rank3["point"])
    assert pointRow["coordinates"]==rank3["old"]
    prefixCore=set(pointRow["coreCells"])
    prefixOutside=set(pointRow["outsideCells"])
    result=[]
    for name in ["interior9","mirror9"]:
        frozen=json.loads((Q/(name+"-result.json")).read_text())
        d=frozen["oldDocument"]
        cells=set(map(int,d["cells"]))
        core=set(d["children"]);outside=set(d["outsideCells"])
        endpoints={int(r[k]) for r in d["faces"].values() for k in ["owner","neighbour"] if r[k] is not None and int(r[k])>=0}
        halo=endpoints-cells
        intersections={"pointStored":rank3["point"] in set(map(int,d["points"])),
            "core":sorted(prefixCore&core),"outside":sorted(prefixCore&outside),
            "fixedSecondHalo":sorted(prefixCore&halo),
            "prefixOutsideVsAllStoredCells":sorted(prefixOutside&cells)}
        assert not intersections["pointStored"]
        assert not any(intersections[k] for k in ["core","outside","fixedSecondHalo"])
        result.append({"name":name,"coreCount":len(core),"outsideCount":len(outside),
            "secondHaloCellCount":len(halo),"prefixCoreCount":len(prefixCore),
            "intersections":intersections,
            "currentBeforeEqualsHistoricalQBecauseActualRank3PrefixHasNoIncidentCellInCoreOutsideOrHalo":True})
    return {"inputSHA256":{str(DELTA):sha(DELTA),str(P/"rank3-mobility-bound.json"):sha(P/"rank3-mobility-bound.json")},
       "actualPrefix":delta["changedPoints"],"rank1PrefixIsOnOtherPartition":True,
       "rank3CompleteMovingPointStar":pointRow,"DWDependency":result,
       "scope":"Topology byte-identical real495 prefix vs original778. No inference from stored point non-overlap alone."}
def run():
    inputs={str(Q/"manifest.json"):sha(Q/"manifest.json")}
    for row in json.loads((Q/"manifest.json").read_text())["files"]:
        path=Q/row["path"]
        assert sha(path)==row["sha256"] and path.stat().st_size==row["bytes"]
        inputs[str(path)]=row["sha256"]
    inputs[str(HERE/"dcCartFinitePointRepair.H")]=sha(HERE/"dcCartFinitePointRepair.H")
    inputs[str(HERE/"kernel_harness.cpp")]=sha(HERE/"kernel_harness.cpp")
    replay=[]
    for name in ["interior9","mirror9"]:
        frozen=json.loads((Q/(name+"-result.json")).read_text())
        ev=E.evaluator(frozen["oldDocument"],frozen["movingPoints"],motion_basis=np.eye(9))
        child=subprocess.Popen([str(HERE/"kernel_harness")],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,bufsize=1)
        child.stdin.write("proposecount 9\n");child.stdin.flush()
        history=[];started=time.monotonic();summary=None
        try:
            while True:
                line=child.stdout.readline()
                if not line:raise RuntimeError("harness ended before done: "+child.stderr.read())
                fields=line.split()
                if fields[0]=="done":
                    summary={"requests":int(fields[1]),"iterations":int(fields[2]),
                        "improved":bool(int(fields[3])),"parameters":list(map(float,fields[4:]))}
                    break
                assert fields[0]=="eval" and len(fields)==10
                q=np.append(np.array(list(map(float,fields[1:]))),0.)
                values=ev["fast"](q);constraints=ev["constraints"](q)
                objective=float(np.exp(-values[0][ev["core"]]/.001).sum()
                    +.25*np.exp(-values[1]/.05).sum()+.1*np.exp(-values[2]/.01).sum())
                assert np.isfinite(objective) and np.isfinite(constraints).all()
                child.stdin.write("1 "+format(objective,".17g")+" "+str(len(constraints))+" "+
                    " ".join(format(float(x),".17g") for x in constraints)+"\n")
                child.stdin.flush()
                history.append({"q":q[:-1].tolist(),"objective":objective,
                    "constraintMin":float(constraints.min())})
            child.stdin.close()
            flags=child.stdout.readline().split()
            assert flags[0]=="stopflags"
            summary["stoppedByRequestCap"]=bool(int(flags[1]))
            summary["stoppedByTimeBudget"]=bool(int(flags[2]))
            summary["stoppedByBudgetLegacyUnion"]=bool(int(flags[3]))
            summary["stopReason"]="request cap" if summary["stoppedByRequestCap"] else "stage wall budget" if summary["stoppedByTimeBudget"] else "finite search termination"
            assert child.wait(timeout=5)==0
        finally:
            if child.poll() is None:child.kill();child.wait()
        summary["history"]=history
        summary["elapsedSeconds"]=time.monotonic()-started
        summary["expectedFrozenEvaluations"]=frozen["proposal"]["evaluations"]
        summary["expectedFrozenParameters"]=frozen["proposal"]["parameters"][:-1]
        summary["maxAbsoluteParameterDifference"]=float(np.max(np.abs(np.array(summary["parameters"])-np.array(summary["expectedFrozenParameters"]))))
        assert summary["requests"]==len(history)==frozen["proposal"]["evaluations"]<=256
        assert summary["stoppedByRequestCap"] and not summary["stoppedByTimeBudget"]
        assert summary["iterations"]<=32 and summary["improved"]
        assert summary["maxAbsoluteParameterDifference"]<2e-8
        # Full guards below are the existing real-stencil Python oracle, not a
        # claim that the later installed C++ oracle will choose the same fraction.
        guarded=[]
        for fraction in [1,.95,.9,.5]:
            q=np.append(np.array(summary["parameters"])*fraction,0.)
            candidate,quality,lineage=ev["actual"](q)
            guarded.append({"fraction":fraction,"lineage":lineage,
                "cellDeterminants":{str(z["cell"]):z["D"] for z in quality["cells"]},
                "scope":"historical math actual-formula oracle; native installed acceptance remains authoritative"})
        summary["fractionRoleReplay"]=guarded
        replay.append({"name":name,"movingPoints":frozen["movingPoints"],**summary})
    value={"format":"isolated-V4-pure9-replay/v1","inputSHA256":inputs,
        "searchReplay":replay,"actualRPrefixDependency":dependency(),
        "noProductionMutation":True,"noBusinessMesherCompileOrRun":True}
    (HERE/"pure9-replay.json").write_text(json.dumps(value,indent=2)+"\n")
    print(json.dumps({"search":[{k:r[k] for k in ["name","requests","iterations","stopReason","maxAbsoluteParameterDifference","elapsedSeconds"]} for r in replay],
        "prefix":value["actualRPrefixDependency"]["DWDependency"]},indent=2))
if __name__=="__main__":run()
