
"""Only new V4 kernel/selector/prefix contracts; no business mesher invocation."""
from pathlib import Path
import subprocess,json,copy,random,sys,hashlib
import numpy as np
import pytest
HERE=Path(__file__).resolve().parent
A=HERE.parents[1]
P=A/".codex-tmp/shared-point-components-7785-20261005"
Q=A/".codex-tmp/finite-shared-point-dw-20261005"
S=A/".codex-tmp/finite-dw-selector-design-20261005"
def call(text):
    return subprocess.check_output([str(HERE/"kernel_harness")],input=text,text=True).strip()
def select(nodes,graph):
    lines=["dwselect "+str(len(nodes))]
    for i,node in enumerate(nodes):
        lines.append(" ".join(map(str,[node["id"],node["valence"],node.get("eligible",1),*node["xyz"],len(graph[i]),*graph[i]])))
    result=list(map(int,call("\n".join(lines)+"\n").split()))
    assert result[0]==len(result)-1
    return result[1:]
def fixture(name):
    sys.path.insert(0,str(S))
    import selector_replay as M
    d=json.loads((P/"rank3-mobility-bound.json").read_text())
    from backend.aircooling.runner.polymesh_io import read_label_list
    owner=read_label_list(M.M/"processor3/constant/polyMesh/owner")
    nei=read_label_list(M.M/"processor3/constant/polyMesh/neighbour")
    rows,adj,components,_=M.graph(d,owner,nei)
    expected=json.loads((Q/(name+"-result.json")).read_text())["movingPoints"]
    comp=next(c for c in components if set(expected)<=c)
    labels=sorted(comp);indices={p:i for i,p in enumerate(labels)}
    nodes=[{"id":p,"valence":len(rows[p]["incidentFaces"]),"xyz":rows[p]["coordinates"]} for p in labels]
    graph=[[indices[q] for q in sorted(adj[p])] for p in labels]
    return nodes,graph,expected
@pytest.mark.parametrize("name",["interior9","mirror9"])
def test_real_automatic_graph(name):
    nodes,graph,expected=fixture(name)
    assert select(nodes,graph)==expected
@pytest.mark.parametrize("name",["interior9","mirror9"])
def test_real_graph_permutation_and_relabel(name):
    nodes,graph,expected=fixture(name)
    baseline={r["id"]:r["xyz"] for r in nodes}
    order=list(range(4));random.Random(761).shuffle(order)
    inverse={j:i for i,j in enumerate(order)}
    renumber={nodes[i]["id"]:100000+31*i for i in order}
    new=[{**nodes[j],"id":renumber[nodes[j]["id"]]} for j in order]
    newGraph=[[inverse[k] for k in reversed(graph[j])] for j in order]
    chosen=select(new,newGraph);coords={n["id"]:n["xyz"] for n in new}
    assert [coords[p] for p in chosen]==[baseline[p] for p in expected]
def test_three_node_valence_geometry_order():
    nodes=[{"id":90,"valence":4,"xyz":[2,0,0]},{"id":10,"valence":4,"xyz":[1,0,0]},{"id":30,"valence":7,"xyz":[3,0,0]}]
    assert select(nodes,[[1],[0,2],[1]])==[30,10,90]
def test_k22_equal_valence_has_geometry_tie_rule():
    nodes=[{"id":90,"valence":4,"xyz":[2,0,0]},{"id":10,"valence":4,"xyz":[1,0,0]},{"id":30,"valence":4,"xyz":[3,0,0]},{"id":50,"valence":4,"xyz":[4,0,0]}]
    assert select(nodes,[[1,3],[0,2],[1,3],[0,2]])==[10,50,90]
@pytest.mark.parametrize("graph",[
    [[1],[2],[1]], # nonreciprocal
    [[],[2],[1]], # disconnected
    [[1,1],[0,2],[1]], # duplicate edge
    [[0,1],[0,2],[1]], # self-edge
    [[1,4],[0,2],[1]], # unknown vertex
])
def test_malformed_three_node_graph(graph):
    nodes=[{"id":i,"valence":3,"xyz":[i,0,0]} for i in range(3)]
    assert select(nodes,graph)==[]
def test_unsupported_complete_four_node_graph():
    nodes=[{"id":i,"valence":3,"xyz":[i,0,0]} for i in range(4)]
    assert select(nodes,[[j for j in range(4) if j!=i] for i in range(4)])==[]
def test_nonfinite_zone_duplicate_and_budget():
    assert call("dwnegative\n")=="11111 0 0 1"
def test_accepted_prefix_protects_newly_green_roles_without_epsilon():
    assert call("prefix\n")=="11100000"
def test_bad_capture_atomic_and_missing_nonfinite_rejected():
    assert call("prefixinvalid\n")=="000001"
@pytest.mark.parametrize("n",[0,3,4,11])
def test_count_objective_refuses_wrong_dimension(n):
    assert call(f"proposecount {n}\n").startswith("done 0 0 0")
@pytest.mark.parametrize("n",[0,9,11])
def test_ratio_objective_refuses_wrong_dimension(n):
    assert call(f"propose {n}\n").startswith("done 0 0 0")

def test_real_census_caps_are_monotonic_and_refuse_partial_graph():
    assert call("censuscaps\n")=="11001100110000"

def test_actual_current_written_graph_and_cap_priority():
    d=json.loads((HERE/"actual-native-graph-replay.json").read_text())
    assert d["actualEligibleTotal"]==340
    modes=d["ranks"][3]["automaticModes"]
    unsupported=next(m for m in modes if m["core"]==131)
    assert unsupported["score"]==29 and not unsupported["fitsProposalCaps"]
    chosen=d["ranks"][3]["selectedOneMode"]
    assert chosen["core"]==71 and chosen["score"]==7
    assert chosen["jointWithActualRPrefix"]["core"]==98
    assert sum(r["selectedOneMode"] is not None for r in d["ranks"])==1
def test_actual_prefix_complete_cell_dependency_is_disjoint():
    d=json.loads((HERE/"pure9-replay.json").read_text())["actualRPrefixDependency"]
    assert len(d["actualPrefix"])==4
    for row in d["DWDependency"]:
        assert row["prefixCoreCount"]==27
        assert not row["intersections"]["pointStored"]
        assert not row["intersections"]["core"]
        assert not row["intersections"]["outside"]
        assert not row["intersections"]["fixedSecondHalo"]
@pytest.mark.parametrize("name",["interior9","mirror9"])
def test_pure9_stop_reason_is_request_cap_not_native_acceptance(name):
    row=next(z for z in json.loads((HERE/"pure9-replay.json").read_text())["searchReplay"] if z["name"]==name)
    assert row["requests"]==256 and row["stoppedByRequestCap"]
    assert not row["stoppedByTimeBudget"]
    assert row["maxAbsoluteParameterDifference"]<2e-8
@pytest.mark.parametrize("name",["interior9","mirror9"])
def test_endpoint_refusal_backtrack_and_no_progress_case_are_retained(name):
    row=next(z for z in json.loads((HERE/"pure9-replay.json").read_text())["searchReplay"] if z["name"]==name)
    fractions={r["fraction"]:r for r in row["fractionRoleReplay"]}
    hard=["D","weight","ratio","skew"]
    assert not all(r["pass"] for r in fractions[1]["lineage"].values())
    assert all(fractions[.95]["lineage"][k]["pass"] for k in hard)
    assert len(fractions[.95]["lineage"]["D"]["candidateBadLabels"]) < len(fractions[.95]["lineage"]["D"]["oldBadLabels"])
    # Half-size has no hard-count improvement and cannot satisfy the DW commit
    # condition even though all original hard passing roles remain protected.
    assert len(fractions[.5]["lineage"]["D"]["candidateBadLabels"])==len(fractions[.5]["lineage"]["D"]["oldBadLabels"])
    assert len(fractions[.5]["lineage"]["weight"]["candidateBadLabels"])==len(fractions[.5]["lineage"]["weight"]["oldBadLabels"])
