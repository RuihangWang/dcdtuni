"""Bounded single-point finite diagnostic on immutable actual495 arrays."""
from pathlib import Path
import sys,json,hashlib,time,copy,subprocess,collections
import numpy as np
HERE=Path(__file__).resolve().parent
A=HERE.parents[1]; B=A.parents[2]; I=B/".codex-tmp/goal-20261005/integration"
N=A/".codex-tmp/shared-point-quality-7785-20261005"
Q=A/".codex-tmp/finite-shared-point-dw-20261005"
P=A/".codex-tmp/shared-point-components-7785-20261005"
C=I/".codex-tmp/actual-zone-and-coupled-screen-20261005"
sys.path[:0]=[str(Q),str(N),str(N/"readers"),str(A/"src")]
import compact_formula_evaluator as E
import audit_shared_point_candidate as V
G,T,U=V.G,V.T,V.U
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(name,x):(HERE/name).write_text(json.dumps(x,indent=2)+"\n")
def metadata():
    graph=json.loads((C/"native-equivalent-graph-and-caps.json").read_text())
    census=json.loads((C/"actual-role-census-with-graph.json").read_text())
    mf=json.loads((C/"manifest-v2.json").read_text())
    for row in mf["files"]:
        p=C/row["path"];assert sha(p)==row["sha256"] and p.stat().st_size==row["bytes"]
    classification=json.loads((A/".codex-tmp/installed-writer-cua-7785c33f/classification.json").read_text())
    delta=Path("/mnt/lv/home/litianyu/mycode/dcdtuni/docs/benchmarks/shinaide-product-2026-10-05/evidence/target-liquid-steady/finite-native-product-495546f2/written-point-and-topology-delta.json")
    assert sha(delta)=="c271bd49da2689a49f74655bf854f91a5cf80ddb9216cc7756c54b28d728634c"
    changes=json.loads(delta.read_text())["changedPoints"]
    rows=[];ranks=[];coverageD=set();coverageW=set();strongD=set();strongW=set();select=[]
    for rank in range(8):
        byid={x["point"]:x for x in census["ranks"][rank]["pointRows"]}
        mobility=json.loads((P/f"rank{rank}-mobility-bound.json").read_text())
        badD={x["cell"] for x in mobility["badD"]}
        badW={x["face"]:{x["owner"]["cell"],x["neighbour"]["cell"]} for x in classification["ranks"][rank]["failedFaces"] if "W" in x["failedFlags"]}
        prefix=set()
        for change in changes:
            if change["rank"]==rank:prefix.update(byid[change["point"]]["coreCells"])
        rs=[]
        for group in graph["ranks"][rank]["components"]:
            if len(group)!=1:continue
            p=group[0];row=byid[p];core=set(row["coreCells"])
            d=sorted(core&badD);w=sorted(f for f,cs in badW.items() if cs&core)
            coverageD.update((rank,c) for c in d);coverageW.update((rank,f) for f in w)
            if row["oldStrongFreeEligible"]:
                strongD.update((rank,c) for c in d);strongW.update((rank,f) for f in w)
            r={"rank":rank,"point":p,"nativePoint":row["nativePoint"],"coordinates":row["actualCoordinate"],
               "oldStrong":row["oldStrongFreeEligible"],"oldReasons":row["oldReasons"],
               "badDCore":d,"badWActive":w,"necessaryDCount":len(d),"necessaryWCount":len(w),
               "proposalCounts":row["counts"],"actualRPrefixCoreCount":len(prefix),
               "jointRPrefixCoreCount":len(prefix|core),"jointCoreCap128":len(prefix|core)<=128,
               "prefixCoreOverlap":sorted(prefix&core)}
            rows.append(r);rs.append(r)
        eligible=[r for r in rs if r["oldStrong"] and r["jointCoreCap128"] and r["necessaryDCount"]+r["necessaryWCount"]>0]
        eligible.sort(key=lambda r:(-r["necessaryDCount"],-r["necessaryWCount"],r["coordinates"]))
        if eligible:select.append(eligible[0])
        ranks.append({"rank":rank,"singletons":len(rs),"olderStrongSingle":sum(r["oldStrong"] for r in rs),
                      "jointCapRefusedStrong":[r["point"] for r in rs if r["oldStrong"] and not r["jointCoreCap128"]],
                      "priorityFirst":eligible[0] if eligible else None})
    select.sort(key=lambda r:(-r["necessaryDCount"],-r["necessaryWCount"],r["coordinates"]))
    assert len(rows)==327 and sum(r["oldStrong"] for r in rows)==294
    out={"format":"actual495-singleton-bounded-selection/v1","actualMesh":graph["actualMesh"],
         "inputSHA256":{str(C/"manifest-v2.json"):sha(C/"manifest-v2.json"),str(delta):sha(delta),
                       str(P):"individual rank metadata are bound by actual-role manifest"},
         "singletons":rows,"rankSummary":ranks,"selectedAtMostTwo":select[:2],
         "necessaryCoverage":{"all327D":len(coverageD),"all327W":len(coverageW),"olderStrong294D":len(strongD),"olderStrong294W":len(strongW)},
         "constraints":{"proposalCore":128,"jointCore":128,"outside":256,"faces":2048,"points":8192},
         "scope":"Necessary complete-star coverage only. Recovered33 need planned-semantic validation; this replay excludes all33. One singleton per rank, top2 by D/W counts then coordinate tuple.",
         "noCandidateCoordinatesOrLabelsUsedAsTrigger":True}
    write("selection.json",out)
    return out
def extract(selection):
    mesh=Path(selection["actualMesh"]);bindings={};documents=[]
    for choice in selection["selectedAtMostTwo"]:
        rank,p=choice["rank"],choice["point"];poly=mesh/f"processor{rank}/constant/polyMesh";start=time.monotonic()
        g=G.Geometry(poly);t=T.read_trace(mesh,rank)
        incident=np.unique(np.searchsorted(g.offsets[1:],np.flatnonzero(g.vertices==p),side="right"))
        core={int(g.owner[f]) for f in incident}|{int(g.neighbour[f]) for f in incident if f<len(g.neighbour)}
        af={int(f) for c in core for f in g.cell(c)[0]}
        outside={int(g.owner[f]) for f in af}|{int(g.neighbour[f]) for f in af if f<len(g.neighbour)}
        outside-=core
        fullfaces={int(f) for c in core|outside for f in g.cell(c)[0]}
        pids={int(q) for f in fullfaces for q in g.ids(f)}
        doc={"points":{str(q):g.points[q].tolist() for q in sorted(pids)},
             "faces":{str(f):{"owner":int(g.owner[f]),"neighbour":int(g.neighbour[f]) if f<len(g.neighbour) else None,
                 "pointIDs":g.ids(f).tolist(),"patch":g.patch(f),"sourceBase":int(t["faceBase"][f]),
                 "sourceZone":int(t["zone"][int(t["faceBase"][f])]) if t["faceBase"][f]>=0 else -1,
                 "nativeFace":int(t["faceNative"][f])} for f in sorted(fullfaces)},
             "cells":{str(c):{"faces":list(map(int,g.cell(c)[0])),"sourceParent":int(t["cellParent"][c]),
                  "nativeCell":int(t["cellNative"][c]),"writtenCentre":g.cell(c)[3].tolist(),"writtenVolume":g.cell(c)[4]} for c in sorted(core|outside)},
             "children":sorted(core),"outsideCells":sorted(outside),"apexWrittenPoint":p,"originalApex":g.points[p].tolist()}
        V.validate_structure(doc,doc,[p])
        assert len(core)==choice["proposalCounts"]["core"] and len(outside)==choice["proposalCounts"]["outside"]
        boundfiles=[poly/n for n in ("points","faces","owner","neighbour","boundary","cellZones","faceZones","pointZones","sets/underdeterminedCells","sets/lowWeightFaces")]
        boundfiles+=list(mesh.glob(f"conforming-*-rank{rank}-*"))
        binding={str(f):sha(f) for f in boundfiles if f.is_file()}
        secondhalo={int(r[k]) for r in doc["faces"].values() for k in ("owner","neighbour") if r[k] is not None}-core-outside
        halo={str(c):{"CC":g.cell(c)[3].tolist(),"V":g.cell(c)[4]} for c in sorted(secondhalo)}
        name=f"rank{rank}-point{p}";write(name+"-input.json",{"selection":choice,"oldDocument":doc,"fixedSecondHalo":halo,"inputSHA256":binding,"extractionSeconds":time.monotonic()-start})
        documents.append((name,choice,doc,g,halo))
    return documents
def finite(ev):
    proc=subprocess.Popen([str(HERE/"kernel_harness")],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,bufsize=1)
    proc.stdin.write("proposecount 3\n");proc.stdin.flush();hist=[];start=time.monotonic()
    try:
        while True:
            line=proc.stdout.readline()
            if not line:raise RuntimeError("harness early end "+proc.stderr.read())
            z=line.split()
            if z[0]=="done":
                out={"requests":int(z[1]),"iterations":int(z[2]),"improved":bool(int(z[3])),"parameters":list(map(float,z[4:]))};break
            assert z[0]=="eval" and len(z)==4
            q=np.append(np.array(list(map(float,z[1:]))),0.)
            values=ev["fast"](q);cons=ev["constraints"](q)
            objective=float(np.exp(-values[0][ev["core"]]/.001).sum()+.25*np.exp(-values[1]/.05).sum()+.1*np.exp(-values[2]/.01).sum())
            valid=np.isfinite(objective) and np.isfinite(cons).all()
            proc.stdin.write(f"{int(valid)} {objective:.17g} {len(cons)} "+" ".join(format(float(v),".17g") for v in cons)+"\n");proc.stdin.flush()
            hist.append({"parameters":q[:-1].tolist(),"objective":objective,"constraintMinimum":float(cons.min())})
        proc.stdin.close();flags=proc.stdout.readline().split();assert flags[0]=="stopflags"
        out.update({"stoppedByRequestCap":bool(int(flags[1])),"stoppedByWallBudget":bool(int(flags[2])),"stoppedByBudgetLegacy":bool(int(flags[3]))})
        assert proc.wait(timeout=5)==0
    finally:
        if proc.poll() is None:proc.kill();proc.wait()
    out["elapsedSeconds"]=time.monotonic()-start;out["history"]=hist
    assert out["requests"]==len(hist)<=256 and out["iterations"]<=32
    return out
def main():
    selection=metadata();documents=extract(selection);results=[]
    for name,choice,doc,g,halo in documents:
        start=time.monotonic();ev=E.evaluator(doc,[choice["point"]],motion_basis=np.eye(3));setup=time.monotonic()-start
        proposal=finite(ev);trials=[]
        for fraction in [1.,.95,.9,.5]:
            q=np.append(np.array(proposal["parameters"])*fraction,0.)
            cand,quality,lineage=ev["actual"](q)
            audit=V.authorize(doc,cand,[choice["point"]])
            hardprogress=audit["newCounts"]["D"]+audit["newCounts"]["weight"]<audit["oldCounts"]["D"]+audit["oldCounts"]["weight"]
            warningcount=audit["newCounts"]["nonOrthogonalityDegrees"]<=audit["oldCounts"]["nonOrthogonalityDegrees"]
            accepted=bool(audit["mathematicalLocalCandidateAccepted"] and hardprogress and warningcount)
            trial={"fraction":fraction,"candidateDocument":cand,"audit":audit,"DWeightCountActuallyReduced":hardprogress,
                   "localWarningCountNotIncreased":warningcount,"eligibleForNativeContractMathOnly":accepted}
            if accepted:
                gap=V.global_gap(g,cand,[choice["point"]]);trial["rankPointClearance"]=gap
                accepted=accepted and all(x["exceedsWriter1MicrometreAnd3MicrometreSafety"] for x in gap)
                payload=np.asarray(list(cand["points"].values()),dtype="<f8").tobytes()
                re=copy.deepcopy(cand)
                for k,v in zip(re["points"],np.frombuffer(payload,dtype="<f8").reshape(-1,3)):re["points"][k]=v.tolist()
                re["originalApex"]=re["points"][str(re["apexWrittenPoint"])]
                rr=V.authorize(doc,re,[choice["point"]]);assert rr==audit
                trial["binary64PayloadRoundtripExact"]=True
                trial["eligibleForNativeContractMathOnly"]=bool(accepted)
            trials.append(trial)
        result={"format":"actual495-singleton-finite-replay/v1","name":name,"rank":choice["rank"],"movingPoint":choice["point"],
                "selection":choice,"oldDocument":doc,"fixedSecondHalo":halo,"proposal":proposal,"trials":trials,
                "setupSeconds":setup,"totalReplaySeconds":time.monotonic()-start,"nativeAcceptance":False,
                "scope":"Pure C++ 3D finite kernel with original-formula Python callback. Production header unchanged. True installed oracle remains authoritative; finite elapsed excludes whole rank graph construction."}
        write(name+"-result.json",result);results.append(result)
        print(json.dumps({"name":name,"requests":proposal["requests"],"iterations":proposal["iterations"],"pureSeconds":proposal["elapsedSeconds"],
          "trials":[{"f":r["fraction"],"before":r["audit"]["oldCounts"],"after":r["audit"]["newCounts"],"mathAccept":r["eligibleForNativeContractMathOnly"],
                     "hard":r["audit"]["hardOriginalPassingRoleGuard"],"geometry":r["audit"]["cellGeometryGuard"] and r["audit"]["faceGeometryGuard"]} for r in trials]}),flush=True)
    write("summary.json",{"selection":selection,"results":[{"name":r["name"],"requests":r["proposal"]["requests"],"pureSeconds":r["proposal"]["elapsedSeconds"],
       "mathAcceptedFractions":[t["fraction"] for t in r["trials"] if t["eligibleForNativeContractMathOnly"]],
       "counts":[{"fraction":t["fraction"],"old":t["audit"]["oldCounts"],"new":t["audit"]["newCounts"]} for t in r["trials"]]} for r in results],
       "noNativeCaseOrProductionMutation":True})
if __name__=="__main__":main()
