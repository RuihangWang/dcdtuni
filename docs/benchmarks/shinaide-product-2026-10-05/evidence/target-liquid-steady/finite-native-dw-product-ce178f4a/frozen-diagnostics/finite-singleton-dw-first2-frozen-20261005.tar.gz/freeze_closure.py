from pathlib import Path
import json,sys,hashlib,time
from fractions import Fraction as F
import numpy as np
import diagnose_singletons as D
HERE=Path(__file__).resolve().parent
def signed_measure(doc):
    core=set(doc["children"]);v=F(0);m=[F(0)]*3
    for row in doc["faces"].values():
        sign=int(row["owner"] in core)-int(row["neighbour"] in core)
        if not sign:continue
        points=[[F(float(x)) for x in doc["points"][str(p)]] for p in row["pointIDs"]]
        a=points[0]
        for j in range(1,len(points)-1):
            b,c=points[j:j+2]
            det=(a[0]*(b[1]*c[2]-b[2]*c[1])-a[1]*(b[0]*c[2]-b[2]*c[0])+a[2]*(b[0]*c[1]-b[1]*c[0]))
            dv=sign*det/6;v+=dv
            for k in range(3):m[k]+=dv*(a[k]+b[k]+c[k])/4
    return {"V":str(v),"M1":[str(z)for z in m]}
def main():
    census=json.loads((D.C/"actual-role-census-with-graph.json").read_text())
    delta=json.loads(Path("/mnt/lv/home/litianyu/mycode/dcdtuni/docs/benchmarks/shinaide-product-2026-10-05/evidence/target-liquid-steady/finite-native-product-495546f2/written-point-and-topology-delta.json").read_text())
    proof=[]
    for path in sorted(HERE.glob("rank*-result.json")):
        r=json.loads(path.read_text());rank=r["rank"];doc=r["oldDocument"];p=r["movingPoint"]
        baseline=json.loads((HERE/(r["name"]+"-input.json")).read_text())
        finalSourceHashes={z:D.sha(z) for z in baseline["inputSHA256"]}
        assert finalSourceHashes==baseline["inputSHA256"],"selected rank source changed"
        indexed={x["point"]:x for x in census["ranks"][rank]["pointRows"]}
        prefixCore=set()
        for x in delta["changedPoints"]:
            if x["rank"]==rank:prefixCore.update(indexed[x["point"]]["coreCells"])
        core=set(doc["children"]);outside=set(doc["outsideCells"]);halo=set(map(int,r["fixedSecondHalo"]))
        overlap={"core":sorted(prefixCore&core),"outside":sorted(prefixCore&outside),"secondHalo":sorted(prefixCore&halo)}
        om,_=D.V.actual_metrics(doc)
        initialDP={str(c):{"CCExact":D.V.same_dp(om.cell(c)[2],row["writtenCentre"]),"VExact":D.V.same_dp(om.cell(c)[3],row["writtenVolume"])} for c,row in ((int(k),v)for k,v in doc["cells"].items())}
        original=signed_measure(doc);trialProof=[]
        for trial in r["trials"]:
            cand=trial["candidateDocument"];new=signed_measure(cand);assert new==original
            trialProof.append({"fraction":trial["fraction"],"signedFractionShellVolumeAndMomentExact":new==original,
               "outsideCellMomentsAllDPExact":all(x["CC_DP_exact"] and x["V_DP_exact"] for x in trial["audit"]["outsideByteMoments"]),
               "coreMomentErrors":{"volumeRelative":trial["audit"]["sumVolumeRelativeDifference"],"M1M4":trial["audit"]["sumFirstMomentDifferenceM4"]},
               "localWarningMaximumDegrees":trial["audit"]["maximumWarningDegrees"],
               "warningPassingLabelFailuresAllowed":trial["audit"]["lineage"]["nonOrthogonalityDegrees"]["originalPassingRoleFailures"]})
        proof.append({"name":r["name"],"sourceReadAfterSearchSHA256":finalSourceHashes,
            "currentCe178SelectedRankFilesSameAsCapturedBefore":True,
            "relevantRank1RPrefixDependency":overlap,"jointRCoreCount":len(core|prefixCore),
            "initialFormulaVsBinaryReaderDPBinding":initialDP,
            "originalFractionSignedShellMeasure":original,"trialProof":trialProof})
    D.write("closure-and-baseline-proof.json",{"format":"single3-complete-star-closure/v1","fixtures":proof,
       "scope":"Selected rank1/rank6 actual files remain exact through ce178, whose3extraDW points are only rank3. This first selector snapshot uses frozen495 fourR prefix, not ce178 sevenPoint joint authorization.",
       "pointTopologyAndProvenanceInputBinding":True,"noNativeAcceptance":True})
    print(json.dumps([{"name":x["name"],"prefixOverlap":x["relevantRank1RPrefixDependency"],"initialBindingFailures":sum(not z["CCExact"] or not z["VExact"] for z in x["initialFormulaVsBinaryReaderDPBinding"].values())}for x in proof]))
if __name__=="__main__":main()
