from pathlib import Path
import json,copy,subprocess
import numpy as np
import pytest
import diagnose_singletons as D
HERE=Path(__file__).resolve().parent
def result(name):return json.loads((HERE/(name+"-result.json")).read_text())
def test_baseline_count_kernel_rejects_three_dimension():
    v4=D.A/".codex-tmp/finite-native-dw-v4-20261005/kernel_harness"
    r=subprocess.run([str(v4)],input="proposecount 3\n",text=True,capture_output=True,check=True)
    assert r.stdout.splitlines()[0].startswith("done 0 0 0")
def test_new_pure_dimension_three_changes_actual_search():
    a=result("rank1-point27133")
    assert a["proposal"]["requests"]==256 and a["proposal"]["improved"]
    assert len(a["proposal"]["parameters"])==3
    assert a["proposal"]["history"][0]["parameters"]==[0,0,0]
def test_recomputed_true_formula_positive_keeps_hard_lineage():
    a=result("rank1-point27133");trial=a["trials"][0]
    actual=D.V.authorize(a["oldDocument"],trial["candidateDocument"],[a["movingPoint"]])
    assert actual==trial["audit"]
    assert actual["oldCounts"]["D"]==11 and actual["newCounts"]["D"]==7
    assert all(actual["lineage"][k]["pass"] for k in ["D","weight","ratio","skew"])
    assert trial["localWarningCountNotIncreased"] and trial["binary64PayloadRoundtripExact"]
def test_warning_label_exchange_is_not_hard_quality_failure():
    a=result("rank1-point27133")["trials"][0]["audit"]
    assert not a["lineage"]["nonOrthogonalityDegrees"]["pass"]
    assert a["lineage"]["nonOrthogonalityDegrees"]["originalPassingRoleFailures"]
    assert a["oldCounts"]["nonOrthogonalityDegrees"]==a["newCounts"]["nonOrthogonalityDegrees"]==4
    assert a["hardOriginalPassingRoleGuard"] and a["warningGlobalCeilingGuard"]
def test_no_count_reduction_is_not_committable():
    a=result("rank6-point27989")
    for t in a["trials"]:
        assert not t["DWeightCountActuallyReduced"] and not t["eligibleForNativeContractMathOnly"]
    assert a["trials"][0]["audit"]["lineage"]["D"]["pass"] is False
    assert a["trials"][2]["audit"]["lineage"]["D"]["pass"] is True
def test_nonmoving_coordinate_tamper_rejected():
    a=result("rank1-point27133");b=copy.deepcopy(a["trials"][0]["candidateDocument"])
    p=next(k for k in b["points"] if int(k)!=a["movingPoint"])
    b["points"][p][0]=np.nextafter(b["points"][p][0],np.inf)
    with pytest.raises(ValueError,match="nonmoving"):D.V.authorize(a["oldDocument"],b,[a["movingPoint"]])
def test_protected_source_zone_even_outside_rejected():
    a=result("rank1-point27133");b=copy.deepcopy(a["oldDocument"])
    f=b["cells"][str(b["outsideCells"][0])]["faces"][0];b["faces"][str(f)]["sourceZone"]=1
    with pytest.raises(ValueError,match="source zone"):D.V.validate_structure(b,b,[a["movingPoint"]])
def test_coupled_star_not_guessed_from_remote():
    a=result("rank1-point27133");b=copy.deepcopy(a["oldDocument"])
    f=b["cells"][str(b["outsideCells"][0])]["faces"][0];b["faces"][str(f)]["patch"]={"type":"processor","name":"protected"}
    with pytest.raises(ValueError,match="coupled|physical"):D.V.validate_structure(b,b,[a["movingPoint"]])
def test_fraction_fixed_shell_and_prefix_dependency_proof():
    p=json.loads((HERE/"closure-and-baseline-proof.json").read_text())
    assert all(t["signedFractionShellVolumeAndMomentExact"] and t["outsideCellMomentsAllDPExact"] for x in p["fixtures"] for t in x["trialProof"])
    assert all(not any(x["relevantRank1RPrefixDependency"].values()) for x in p["fixtures"])
