# Actual 7785 shared internal edge rotation and fourteen-point joint proof

All work here is isolated read-only mathematics on the unchanged current GUI job 7785c33f. Its stock result remains Failed 3: D909 / W100 / R2, N755 warnings. Frozen C/H/app and actual original arrays are unchanged. No C++ edit, build, native/checker/solver job, API, service, browser or Git-index action was performed.

The useful new mechanism moves a shared interior edge coherently, allowing its adjacent quadrilateral planes to rotate while preserving their exact geometric planarity. Locking a single node to every original support plane had artificially hidden this freedom.

## Exact finite plane-mode analysis

For one coordinate at a time, polygon tetrahedral signed-volume determinants are affine functions of node displacements. Fraction arithmetic derives and row-reduces their homogeneous constraints. The original quad is not held on its old plane; a coherent shared-node mode can rotate it.

On rank 1 point 19982, one-node X/Y/Z motion has zero degrees of freedom. Expanding only its first interior polygon edge star gives 13 safe nodes. Y has five and Z three nullspace dimensions. The smallest target Y mode uses only points 19982 and 576148 with the same displacement. Their complete incident stars have no physical/coupled/zone movement. The 47-node bounded extension still supports motion; expansion to 128 was not attempted under the 64-node cap. This exact analysis took 3.86 seconds and does not evaluate stock quality or prove all possible motion domains.

## Original-formula positive and negative candidates

The two-node edge mode plus the original free pivot 19983 is a three-point, four-parameter local proposal. Drivers use current actual source arrays and complete stars, not source-parent formula substitutes. The generic count-proxy attempt reduced local D/W but left the ratio failure and slightly worsened its severity; all variants were refused and retained.

A bounded targeted-ratio objective yielded a valid run 1 / fraction 0.95 candidate over 69 core and 62 outside cells. D8→8 / W17→17 / R1→0 / S0, N5→4 with maximum 82.362879 degrees. All original passing hard roles hold, all conservative planar/vertex-halfspace and stock face-centre/tet guards hold, every original non-triangular determinant is Fraction-exact unchanged, and cavity V/M1 is exact. The new R value is 0.011164470016583493. Minimum passing D is 0.0010128117161653347 and W 0.05022537215400167. The unsuccessful run 0, including its incompatible-constraint optimizer status and new passing-role failures, is preserved. Optimizer warnings are kept in original stderr.

The rank 1 candidate moves internal points only. Its actual physical and coupled points, rings and roles stay fixed. The raw case is not edited.

## Full fourteen-point compound, not independent count addition

The selected new rank 1 candidate is combined with the frozen eleven-point rank 3 candidate. Both actual original inputs are freshly hash-bound, and both whole-rank points copies are round-tripped through the current LSB label32/scalar64 format. A collision-free rank tag preserves each original face/cell order and provenance while allowing a single full combined numerical guard. Tagged labels are diagnostic bookkeeping, not a rewritten case.

The recomputed compound covers 373 core and 271 complete outside cells. D47→22 / W32→18 / R2→0 / S0; N54→54 with maximum 83.12715637727378 degrees. Net mathematical removal is 25D / 14W / 2R. All original passing hard roles remain passing; 271 outside CC/V values are DP-byte identical; total cavity V/M1 is Fraction exact. Each component's original smaller geometry tolerance is also independently enforced, so the compound's larger world span cannot weaken an individual geometric guard.

Minimum combined passing margins are D8.60e-7, W2.25e-4 and R1.16e-3. This is still a partial D/W result and a mathematical local proof. It does not claim native zero failed checks, installed C++ DP arithmetic, final coupled-certificate acceptance, or solver acceptance.

Rank 3 retains its separately authorized physical-flat interior node. Thus the joint all-physical-face-coordinate flag is false by design: fixed literal outer footprint, exact normal coordinate and area/moment are the correct contract. The existing 1.6203125 mm raw-STL normal deviation is retained rather than corrected or called acceptable. Every coupled coordinate is fixed.

## Tests and next native design

Fifteen meaningful tests passed: exact rotating-plane modes, one-node/in-plane boundaries, original-formula positive replay, unequal-edge warp refusal, fixed-shell and missing-outside refusal, failed optimizer rejection, full compound metric reconstruction, binary64 scope, physical-normal refusal, and separate N-warning/hard-threshold roles. Raw invocation clocks, source hashes, stderr and before/after complete documents are included.

native-proposal-design.md describes a generic topology-derived pivot/edge mode, bounded proposal and full installed metric/cache/coupled/physical guards. It contains no case-coordinate constants and is not implemented or authorized for native execution.

manifest.json declares this directory's payload. Two whole-rank points-format copies are large ignored artifacts; preserve them in a repository-contained ignored archive rather than Git blobs. The prior N/P/F 116-file and R 27-file manifests are dependencies and stay unchanged. This does not preserve or authorize deletion of an entire worktree.
