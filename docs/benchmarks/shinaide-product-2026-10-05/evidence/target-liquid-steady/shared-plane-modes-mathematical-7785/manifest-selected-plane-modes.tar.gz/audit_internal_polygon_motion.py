from pathlib import Path
import sys,inspect
import numpy as np
H=Path(__file__).resolve().parent;A=H.parents[1];N=H.parent/'shared-point-quality-7785-20261005'
sys.path[:0]=[str(N),str(N/'readers'),str(A/'src')]
import audit_shared_point_candidate as V
# Keep every prior numerical, structural and hard-role gate; support internal
# polygons only when their entire genuine point star is supplied.
env=dict(vars(V))
source=inspect.getsource(V.validate_structure)
line='        if len(r["pointIDs"])!=3:raise ValueError("only triangular incident faces supported")\n'
if source.count(line)!=1:raise RuntimeError('exact structural source identity changed')
exec(source.replace(line,''),env)
validate_internal_polygon=env['validate_structure']
exec(inspect.getsource(V.authorize),env)
authorize_internal_polygon=env['authorize']
