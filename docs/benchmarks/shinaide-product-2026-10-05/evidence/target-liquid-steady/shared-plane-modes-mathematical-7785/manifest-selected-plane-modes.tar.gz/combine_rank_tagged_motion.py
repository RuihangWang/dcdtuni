from pathlib import Path
import sys,inspect,copy
import numpy as np
H=Path(__file__).resolve().parent;A=H.parents[1];N=H.parent/'shared-point-quality-7785-20261005';F=H.parent/'flat-point-quality-7785-20261005'
sys.path[:0]=[str(F),str(N),str(N/'readers'),str(A/'src')]
import flat_support as Flat
V=Flat.V
STRIDE=1<<24
def relabel(doc,rank):
    shift=rank*STRIDE
    p=lambda x:x+shift
    out=copy.deepcopy(doc)
    out['points']={str(p(int(k))):v for k,v in doc['points'].items()}
    out['faces']={}
    for k,r in doc['faces'].items():
        q=copy.deepcopy(r);q['owner']=p(q['owner']);q['neighbour']=None if q['neighbour'] is None else p(q['neighbour'])
        q['pointIDs']=[p(x) for x in q['pointIDs']];out['faces'][str(p(int(k)))]=q
    out['cells']={}
    for k,r in doc['cells'].items():
        q=copy.deepcopy(r);q['faces']=[p(x) for x in q['faces']];out['cells'][str(p(int(k)))]=q
    for k in ('children','outsideCells'):out[k]=[p(x) for x in doc[k]]
    out['apexWrittenPoint']=p(doc['apexWrittenPoint'])
    return out
def combine(a,b):
    out=copy.deepcopy(b)
    for key in ('points','faces','cells'):
        if set(a[key])&set(b[key]):raise ValueError('rank tag collisions')
        out[key].update(copy.deepcopy(a[key]))
    for key in ('children','outsideCells'):out[key]=a[key]+b[key]
    return out
def authorize(old,new,moving,physical_points=(),polygon_points=()):
    env=dict(vars(Flat));env['polygon_points']=set(polygon_points)
    structural=inspect.getsource(Flat.validate)
    oldline='(r["patch"] is not None or len(r["pointIDs"])!=3)'
    newline='(r["patch"] is not None or (len(r["pointIDs"])!=3 and p not in polygon_points))'
    if structural.count(oldline)!=1:raise RuntimeError('exact structural template changed')
    exec(structural.replace(oldline,newline),env)
    numerical=inspect.getsource(V.authorize).replace('def authorize(','def joint_authorize(')
    numerical=numerical.replace('scope=validate_structure(old,new,moving)','scope=validate(old,new,moving,physical_points)')
    numerical=numerical.replace('warning_ceiling=88.2022):','warning_ceiling=88.2022,physical_points=()):')
    exec(numerical,env)
    return env['joint_authorize'](old,new,moving,physical_points=physical_points)
def all_passing_margin(quality):
    rows={}
    for k,(threshold,upper) in V.U.LIMITS.items():
        if k=='nonOrthogonalityDegrees':continue
        collect=quality['cells' if k=='D' else 'faces'];field='cell' if k=='D' else 'face'
        passing=[r for r in collect if k in r and np.isfinite(r[k]) and (r[k]<=threshold if upper else r[k]>=threshold)]
        target=min(passing,key=lambda r:(threshold-r[k]) if upper else (r[k]-threshold))
        rows[k]={'threshold':threshold,'element':target[field],'value':target[k],
                 'absoluteMargin':float(threshold-target[k] if upper else target[k]-threshold)}
    return rows
