"""Exact coordinate-only internal-polygon plane modes; proposal domain only.

Preserve each original polygon's tetrahedral signed-volume determinants while
moving one coordinate of selected nodes. This permits planes to rotate, unlike
locking each node to every original support plane. No quality authorization.
"""
from fractions import Fraction as F
from itertools import combinations

def ff(x): return F.from_float(float(x))

def det3(m):
    return (m[0][0]*(m[1][1]*m[2][2]-m[1][2]*m[2][1])
            -m[0][1]*(m[1][0]*m[2][2]-m[1][2]*m[2][0])
            +m[0][2]*(m[1][0]*m[2][1]-m[1][1]*m[2][0]))

def coefficients(points, ids, axis):
    other=[k for k in range(3) if k!=axis]
    q=[[ff(points[str(p)][k]) for k in other]+[F(1)] for p in ids]
    # det([x,y,z,1]) is affine in each entry of the moving column.
    return [(-1 if (i+axis)%2 else 1)*det3([q[j] for j in range(4) if i!=j]) for i in range(4)]

def equations(doc, moving, axis):
    moving=list(map(int,moving));pos={p:i for i,p in enumerate(moving)}
    rows=[];witness=[]
    for face,r in sorted(doc['faces'].items(),key=lambda x:int(x[0])):
        ids=r['pointIDs']
        if len(ids)<4 or not set(ids).intersection(moving): continue
        other=[k for k in range(3) if k!=axis]
        projected=[[ff(doc['points'][str(p)][k]) for k in other]+[F(1)] for p in ids]
        candidates=[(abs(det3([projected[i] for i in t])),t) for t in combinations(range(len(ids)),3)]
        amount,trip=max(candidates)
        if amount==0: continue # motion is in the original supporting plane
        for j in range(len(ids)):
            if j in trip: continue
            four=[ids[i] for i in (*trip,j)]
            c=coefficients(doc['points'],four,axis)
            row=[F(0) for _ in moving]
            for p,v in zip(four,c):
                if p in pos: row[pos[p]]+=v
            if any(row):
                base=sum(v*ff(doc['points'][str(p)][axis]) for p,v in zip(four,c))
                rows.append(row)
                witness.append({'face':int(face),'pointIDs':four,'axis':axis,'coefficients':[str(v) for v in c],
                                'originalSignedDeterminant':str(base)})
    return rows,witness

def rref(rows, n):
    a=[list(r) for r in rows if any(r)];pivots=[];h=0
    for col in range(n):
        k=next((j for j in range(h,len(a)) if a[j][col]),None)
        if k is None: continue
        a[h],a[k]=a[k],a[h];v=a[h][col];a[h]=[x/v for x in a[h]]
        for j in range(len(a)):
            if j==h or not a[j][col]: continue
            v=a[j][col];a[j]=[x-v*y for x,y in zip(a[j],a[h])]
        pivots.append(col);h+=1
        if h==len(a): break
    return a[:h],pivots

def modes(doc,moving,axis,target):
    rows,witness=equations(doc,moving,axis)
    rr,pivot=rref(rows,len(moving));free=[j for j in range(len(moving)) if j not in pivot]
    basis=[]
    for f in free:
        v=[F(0) for _ in moving];v[f]=F(1)
        for row,p in zip(rr,pivot): v[p]=-row[f]
        assert all(sum(a*b for a,b in zip(r,v))==0 for r in rows)
        basis.append(v)
    target_index=moving.index(target)
    usable=[i for i,v in enumerate(basis) if v[target_index]]
    return {'axis':axis,'movingPoints':moving,'targetPoint':target,'equations':len(rows),'rank':len(pivot),
            'nullity':len(free),'targetCanMove':bool(usable),'usableBasisIndices':usable,
            'basis':[[str(x) for x in v] for v in basis],'witness':witness,
            'qualityEvaluated':False,'nativeAcceptance':False}
