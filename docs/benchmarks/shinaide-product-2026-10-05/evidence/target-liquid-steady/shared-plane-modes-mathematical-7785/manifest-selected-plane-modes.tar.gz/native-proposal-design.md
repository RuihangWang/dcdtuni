# Bounded shared-point native proposal design — not implemented

This design follows the fresh actual 7785 fourteen-point mathematical candidate. C++ remains frozen at C ead4a057 / H 4a5ef961 / app babd07c8. No build, native run, API or service change is authorized by this document. The final allTopology/allGeometry checks and 300-second whole-product budget remain binding.

## General selection from current topology

Build installed mesh.cells() and mesh.pointFaces() once. Cache owned copies of actual Sf/Cf/CC/V before any geometry invalidation, retaining owner-face then neighbour-face accumulation order. Find D/W/R failures using actual selected-Sf masks, including coupled and excluding physical boundary faces for D. Select stable world-geometry keys, not case names, parent IDs, trace arrays or benchmark labels. R components have a useful early priority because the current two R failures have genuine local remedies; this does not make D/W optional.

Classify each seed cell/face's vertices by their complete incident face stars. A freely movable pivot is an interior point whose full star has no physical/coupled face or protected zone. In a cone fan, it can be identified from genuine common topology and triangular incident faces; source-parent identity is unnecessary. If a single pivot is insufficient, inspect only adjacent non-triangular interior edges and at most one neighbouring free pivot. The first implementation should bound each component to at most four moving points and a small complete star, then refuse unsupported components.

The new two-node mode is geometric, not an AP-coordinate constant. For an adjacent interior edge a,b and translation coordinate k, each incident non-triangular face must preserve planarity for that shared displacement. A narrow exact-coordinate predicate covers the actual positive case without a Fraction library:

* A face on an exact constant-coordinate plane j != k remains planar because the displacement is tangent to it.
* If a face is on the k-normal plane and contains both edge nodes, the two moved nodes must have the same exact secondary coordinate l and every fixed node must lie on one other exact l level. The displaced face lies on the affine plane k = originalK + delta*(l-fixedL)/(edgeL-fixedL), so it may rotate while staying planar.
* A k-normal face containing just one moving node fails this mode. A warped, non-axis or unclassified polygon remains unsupported in the first native version, rather than being projected or snapped.
* Both nodes must have identical original k DP representations so the shared addition produces identical new coordinate bits. Their other coordinates stay fixed. All complete stars must be free of physical/coupled/zone movement.

These predicates can be applied to any eligible edge/axis from current topology. The actual example is a Y translation of a tiny X-parallel edge, but neither its axis nor its node IDs should be baked into production. The mathematical exact determinant analysis also supports broader finite modes, which are outside this first narrow implementation.

Create a compact basis B: three coordinates for the freely movable pivot plus one scalar for the qualified two-node edge translation. Other ordinary two/three free-point components and exact flat same-BC tangent modes use similarly small bases. The physical-flat mode has its separate complete-star literal-plane and fixed-outer-ring area/moment contract; it is not covered by an assertion that all physical face coordinates remain unchanged.

## Bounded proposal and actual guard

Use normalized local lengths and the current accepted state. A small constrained trust-region/SQP proposal can optimize the component's actual failing quantity: minimum target R, minimum target W, or a smooth count proxy for its bad D cells. The successful new R case required the targeted R objective; its count-proxy result preserved geometry and lowered D/W but left R and was rejected. A generic implementation therefore needs metric priorities, not arbitrary coordinate grids.

For a four-parameter pivot-plus-edge mode, finite differences require five compact metric evaluations per iteration. A dense regularized local active-set solve and backtracking need no large external optimizer. Cap iterations/evaluations and component trials explicitly; for example, at most 32 iterations, 256 evaluations and a few backtracks per component. These are algorithmic limits, not performance claims. Component rejection must leave the current points and caches untouched.

The small scratch evaluator should use installed triPointRef::centre/areaNormal and the official polygon formulas. The triangle multiplication by 1/3 must not be replaced by division or claimed DP equivalent. Preserve genuine cell-face traversal order and actual outside centres/volumes; do not substitute inherited source references, a common-apex formula, or a stale cache. Every trial is followed by the complete affected star and one-ring outside guard: positive volumes, directed-edge closure, stock face-centre concavity, centre and shared-anchor tetrahedral fans, original passing D/W/R/S roles, literal physical footprint, coupled/zone protections, and total cavity V/M1. A remaining D/W failure is allowed only as an honest improvement checkpoint, never native acceptance. N warnings are recorded separately and may exchange labels, with maximum no worse than the original measured 88.2022 degrees; checker options and thresholds are never changed.

Use positive quality margins and a conservative backtrack before commitment. The chosen new R fraction 0.95 has minimum passing D 0.0010128117, W 0.0502253722 and repaired R 0.0111644700. The earlier fourteen-point compound retains a smaller D margin 8.60e-7, so native installed recomputation and rollback remain necessary. An optimizer's success bit, a clipped constraint, or the binary-format-only round-trip cannot authorize a point update.

## Installed-object placement and fail-closed commitment

Place the optional stage inside toPolyMesh after addZones and before the earliest-baseline final coupled certificate. Do not place it in the app after toPolyMesh returns. The current certificate resets its baseline at return and would otherwise miss subsequent movement.

Trials remain compact and do not repeatedly rebuild the full polyMesh. Revalidate overlapping point stars against current accepted points and caches, or combine their candidate modes before choosing a batch. Commit the selected batch only once, all ranks unconditionally and in the same order, through installed polyMesh::updateGeomPoints with an unregistered NO_WRITE pointIOField. Explicitly clear/recompute the tetrahedral base cache. Drop all references to geometry caches before clearing; keep owned original values for rollback.

Force real installed Sf/Cf/CC/V after the update. Recheck the full combined affected stencil and outside roles against the earliest source state, then perform the existing exact installed coupled DP/ring/alias/patch-zone/transform certificate. Any unknown, nonfinite, geometry, hard-role or coupled-invariance failure restores the original batch points, refreshes the installed geometry again, and refuses the batch before writing. A failed exact coupled certificate must remain Fatal/fail-closed, not be replaced by ordinary checkMesh. Preserve the original inputs and refusal evidence.

## Coverage and cost limits

The previous current-topology census found 307 eligible triangular-star internal points: 565 of 909 D cells had one, 19 had two or more, and 325 had none. It separately found 256 D cells with a necessary same-BC flat candidate, without proving feasibility or disjointness. The two-node polygon mode adds a different movable class that the prior single-point support lock missed. Its all-case coverage is not yet measured. A full production improvement cannot be inferred from the fourteen-point net 25D/14W/2R result.

Demand-driven graphs and final installed geometry refresh are O(P+F+C) operations. Local modes use only small cached stars; no full-mesh rebuild per trial and no global parameter sweep is proposed. Set a stage wall-time/evaluation allowance and stop adding proposals when the actual remaining job budget must be reserved for final geometry, certificates, mandatory checkMesh and cleanup. Once allocated, the final all-rank refresh/certificate cannot be skipped. The existing 300-second runner watchdog remains the hard whole-job authority. Real stage wall time/RSS and full API timing must be measured; a candidate cap does not guarantee budget compliance.

Before full CUA execution, native positive/negative fixtures must actually trigger the new mode and preserve original physical/coupled outputs. Then the original case needs true stock zero failed checks and stable solver acceptance. This document is an implementable proposal, not that validation.
