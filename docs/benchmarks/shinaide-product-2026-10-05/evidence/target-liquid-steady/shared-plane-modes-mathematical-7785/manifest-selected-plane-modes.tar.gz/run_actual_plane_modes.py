from pathlib import Path
import sys,json,ast,time,hashlib
import numpy as np
H=Path(__file__).resolve().parent;A=H.parents[1];N=H.parent/'shared-point-quality-7785-20261005';P=H.parent/'shared-point-components-7785-20261005'
sys.path[:0]=[str(H),str(N),str(N/'readers'),str(A/'src')]
import audit_shared_point_candidate as V
import internal_quad_plane_modes as L
G,T=V.G,V.T
M=A.parent/'integration/.codex-tmp/cases/Shinaide_MeshAbort_CUA/Mesh';E=A/'.codex-tmp/installed-writer-cua-7785c33f'
tree=ast.parse((P/'run_bounded_joint.py').read_text());defs=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ('cf','document')]
exec(compile(ast.Module(body=defs,type_ignores=[]),str(P/'run_bounded_joint.py'),'exec'),globals())
def main():
    start=time.monotonic();g=G.Geometry(M/'processor1/constant/polyMesh');t=T.read_trace(M,1)
    faceOf=np.repeat(np.arange(g.n_faces,dtype=np.int32),np.diff(g.offsets));order=np.argsort(g.vertices,kind='stable');verts=g.vertices[order]
    def pf(p):return faceOf[order[np.searchsorted(verts,p,'left'):np.searchsorted(verts,p,'right')]]
    allowed={}
    def safe(p):
        if p not in allowed:
            allowed[p]=all(g.patch(int(f)) is None and (int(t['faceBase'][f])<0 or int(t['zone'][int(t['faceBase'][f])])==-1) for f in pf(p))
        return allowed[p]
    group={19982};records=[]
    for depth in range(3):
        moving=sorted(group);doc=document(g,t,moving)
        _,_,binding=V.raw_binding(doc,moving,M,1,E/'case-file-manifest.json')
        face_ids={int(f) for p in group for f in pf(p) if len(g.ids(int(f)))>=4}
        add={int(p) for f in face_ids for p in g.ids(f)}-group;permit={p for p in add if safe(p)}
        rows=[L.modes(doc,moving,axis,19982) for axis in range(3)]
        out={'depth':depth,'oldDocument':doc,'actualSourceBinding':binding,'pointStarAllFacesProtectedFree':all(safe(p) for p in moving),
             'modes':rows,'expansion':{'nextPoints':len(group|permit),'protectedFixedPoints':sorted(add-permit),'unexpandedSafePoints':sorted(permit)},
             'noMeshMutation':True,'nativeAcceptance':False}
        (H/f'depth{depth}-actual-plane-modes.json').write_text(json.dumps(out,indent=2)+'\n')
        records.append({'depth':depth,'points':len(group),'core':len(doc['children']),'outside':len(doc['outsideCells']),
                        'modes':[{k:r[k] for k in ('axis','equations','rank','nullity','targetCanMove')} for r in rows],
                        'nextPoints':len(group|permit)})
        print(json.dumps(records[-1]),flush=True)
        if len(group|permit)>64:break
        group|=permit
    (H/'summary.json').write_text(json.dumps({'records':records,'elapsedSeconds':time.monotonic()-start,
       'stoppedAt64PointCap':records[-1]['nextPoints']>64,'sourceSHA256':{'driver':V.sha(__file__),'modes':V.sha(H/'internal_quad_plane_modes.py'),'reader':V.sha(N/'audit_shared_point_candidate.py'),'builder':V.sha(P/'run_bounded_joint.py')},
       'scope':'Exact coordinate-only determinant preservation, permits internal plane rotation; finite groups only, no stock quality evaluation or impossibility claim outside this domain.'},indent=2)+'\n')
if __name__=='__main__':main()
