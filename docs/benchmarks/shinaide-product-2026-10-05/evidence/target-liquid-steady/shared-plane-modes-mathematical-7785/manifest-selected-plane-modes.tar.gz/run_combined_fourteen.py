from pathlib import Path
import sys,json,copy,time
H=Path(__file__).resolve().parent;A=H.parents[1];F=H.parent/'flat-point-quality-7785-20261005';R=H.parent/'shared-point-ratio-7785-20261005'
sys.path[:0]=[str(H),str(F)]
import combine_rank_tagged_motion as C
import audit_internal_polygon_motion as P
import audit_writer_point_format as W
V=C.V
def main():
    start=time.monotonic();left=json.loads((H/'targeted-ratio-internal-edge-audit.json').read_text())
    old1=left['oldDocument'];r=next(q for q in left['results'] if q['run']==1 and q['fraction']==.95);new1=copy.deepcopy(r['candidateDocument'])
    right=json.loads((R/'combined-eleven-point-audit.json').read_text());old3=right['oldDocument'];new3=copy.deepcopy(right['candidateDocument'])
    bind=[];formats=[];component=[]
    for rank,old,new,moving in [(1,old1,new1,left['movingPoints']),(3,old3,new3,right['movingPoints'])]:
        mesh=Path((left if rank==1 else right)['actualSourceBinding']['mesh'])
        case_manifest=A/'.codex-tmp/installed-writer-cua-7785c33f/case-file-manifest.json'
        g,t,b=V.raw_binding(old,moving,mesh,rank,case_manifest);bind.append(b)
        pts,form=W.write_binary_points_copy(mesh/f'processor{rank}/constant/polyMesh/points',H/f'combined-rank{rank}-points.binary-format-copy',{p:new['points'][str(p)] for p in moving})
        for p in new['points']:new['points'][p]=pts[int(p)].tolist()
        new['originalApex']=new['points'][str(new['apexWrittenPoint'])];formats.append({'rank':rank,**form})
        a=P.authorize_internal_polygon(old,new,moving) if rank==1 else C.Flat.authorize_flat(old,new,moving,physical_points=right['physicalPoints'])
        a['globalRankPointClearance']=V.global_gap(g,new,moving)
        component.append({'rank':rank,'audit':a,'originalPassingMargin':W.margin_summary(a['oldActualMetrics'],a['newActualMetrics']),
                          'allPassingMargin':C.all_passing_margin(a['newActualMetrics'])})
    old=C.combine(C.relabel(old1,1),C.relabel(old3,3));new=C.combine(C.relabel(new1,1),C.relabel(new3,3))
    moving=[p+C.STRIDE for p in left['movingPoints']]+[p+3*C.STRIDE for p in right['movingPoints']]
    physical=[p+3*C.STRIDE for p in right['physicalPoints']]
    poly=[int(p)+C.STRIDE for p in left['mode']['values']]
    audit=C.authorize(old,new,moving,physical,poly)
    exactold=W.exact_core_moments(old);exactnew=W.exact_core_moments(new)
    jointpass=audit['mathematicalLocalCandidateAccepted'] and all(c['audit']['mathematicalLocalCandidateAccepted'] for c in component)
    jointpass=jointpass and all(q['exceedsWriter1MicrometreAnd3MicrometreSafety'] for c in component for q in c['audit']['globalRankPointClearance']) and exactold==exactnew
    out={'format':'actual7785-fourteen-point-two-rank-full-joint-math/v1','selectedLeftBacktrack':{'run':1,'fraction':.95},
         'originalRankedMovingPoints':{'1':left['movingPoints'],'3':right['movingPoints']},'rankTagStride':C.STRIDE,
         'oldDocument':old,'candidateDocument':new,'movingPoints':moving,'physicalPoints':physical,'internalPolygonPoints':poly,
         'componentOriginalGuards':component,'jointAudit':audit,'jointMathematicalCandidateAccepted':jointpass,
         'passingMargin':C.all_passing_margin(audit['newActualMetrics']),'binaryFormats':formats,'actualSourceBindings':bind,
         'exactCoreFractionVolumeMoment':exactold==exactnew,'coreFractionVolumeMomentBefore':exactold,'coreFractionVolumeMomentAfter':exactnew,
         'sourceSHA256':{'driver':V.sha(__file__),'jointAuditor':V.sha(H/'combine_rank_tagged_motion.py'),'leftAuditor':V.sha(H/'audit_internal_polygon_motion.py'),'frozenRightAuditor':V.sha(F/'flat_support.py')},
         'inputSHA256':{'left':V.sha(H/'targeted-ratio-internal-edge-audit.json'),'right':V.sha(R/'combined-eleven-point-audit.json')},
         'elapsedSeconds':time.monotonic()-start,'noMeshMutation':True,'nativeAcceptance':False}
    (H/'combined-fourteen-point-two-rank-audit.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({'accepted':jointpass,'countsBefore':audit['oldCounts'],'countsAfter':audit['newCounts'],
        'core':len(old['children']),'outside':len(old['outsideCells']),'Nmax':audit['maximumWarningDegrees'],'VM':exactold==exactnew,'elapsed':out['elapsedSeconds']}),flush=True)
if __name__=='__main__':main()
