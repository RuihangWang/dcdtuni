from pathlib import Path
from fractions import Fraction as Rat
import sys,json,copy,ast,time
import numpy as np
H=Path(__file__).resolve().parent;A=H.parents[1];N=H.parent/'shared-point-quality-7785-20261005';P=H.parent/'shared-point-components-7785-20261005';F=H.parent/'flat-point-quality-7785-20261005';R=H.parent/'shared-point-ratio-7785-20261005'
sys.path[:0]=[str(H),str(F),str(N),str(N/'readers'),str(A/'src')]
import audit_internal_polygon_motion as C
import parameterized_internal_solver as S
import internal_quad_plane_modes as L
import audit_writer_point_format as W
V=C.V;G,T=V.G,V.T
M=A.parent/'integration/.codex-tmp/cases/Shinaide_MeshAbort_CUA/Mesh';E=A/'.codex-tmp/installed-writer-cua-7785c33f'
tree=ast.parse((P/'run_bounded_joint.py').read_text());defs=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ('cf','document')]
exec(compile(ast.Module(body=defs,type_ignores=[]),str(P/'run_bounded_joint.py'),'exec'),globals())
def main():
 start=time.monotonic();modeDoc=json.loads((H/'depth1-actual-plane-modes.json').read_text())
 modes=[]
 for row in modeDoc['modes']:
  for idx in row['usableBasisIndices']:
   v=[Rat(x) for x in row['basis'][idx]];factor=v[row['movingPoints'].index(row['targetPoint'])]
   values={p:float(x/factor) for p,x in zip(row['movingPoints'],v) if x}
   modes.append((len(values),row['axis'],idx,values))
 _,axis,index,values=min(modes,key=lambda x:(x[0],x[1],x[2]))
 rank1=json.loads((R/'rank1-bounded-ap-only.json').read_text());apex=rank1['movingPoints'][0];moving=[apex]+sorted(values)
 B=np.zeros((3*len(moving),4));B[:3,:3]=np.eye(3)
 for j,p in enumerate(moving):
  if p in values:B[3*j+axis,3]=values[p]
 g=G.Geometry(M/'processor1/constant/polyMesh');t=T.read_trace(M,1);doc=document(g,t,moving)
 _,_,binding=V.raw_binding(doc,moving,M,1,E/'case-file-manifest.json')
 seed=copy.deepcopy(doc);oldAP=next(r for r in rank1['results'] if r['run']==0 and r['fraction']==.95)['candidateDocument']['points'][str(apex)]
 seed['points'][str(apex)]=oldAP;seed['originalApex']=seed['points'][str(seed['apexWrittenPoint'])]
 proposal=S.solve(doc,moving,maxiter=60,structural_validator=C.validate_internal_polygon,initial_docs=(doc,seed),motion_basis=B)
 rows=[];coef,witness=L.equations(doc,sorted(values),axis)
 for run_id,run in enumerate(proposal['runs']):
  for fraction in [.999,.95,.5,.25]:
   new=copy.deepcopy(doc)
   for p in moving:
    a=np.asarray(doc['points'][str(p)]);b=np.asarray(run['candidateDocument']['points'][str(p)])
    new['points'][str(p)]=(a+fraction*(b-a)).tolist()
   new['originalApex']=new['points'][str(new['apexWrittenPoint'])]
   audit=C.authorize_internal_polygon(doc,new,moving)
   audit['globalRankPointClearance']=V.global_gap(g,new,moving)
   if not all(q['exceedsWriter1MicrometreAnd3MicrometreSafety'] for q in audit['globalRankPointClearance']):audit['mathematicalLocalCandidateAccepted']=False
   exact=[]
   for w in witness:
    cs=[Rat(x) for x in w['coefficients']]
    det=sum(c*Rat.from_float(float(new['points'][str(p)][axis])) for p,c in zip(w['pointIDs'],cs))
    exact.append({'face':w['face'],'signedDeterminantExactUnchanged':str(det)==w['originalSignedDeterminant']})
   volume=W.exact_core_moments(doc)==W.exact_core_moments(new)
   rows.append({'run':run_id,'fraction':fraction,'candidateDocument':new,'audit':audit,
                'coordinateOnlyNonTriDeterminants':exact,'allSignedDeterminantsExactUnchanged':all(x['signedDeterminantExactUnchanged'] for x in exact),
                'coreFractionVolumeMomentExact':volume})
   print(json.dumps({'run':run_id,'fraction':fraction,'accepted':audit['mathematicalLocalCandidateAccepted'],'old':audit['oldCounts'],'new':audit['newCounts'],
      'Nmax':audit['maximumWarningDegrees'],'planarityExact':rows[-1]['allSignedDeterminantsExactUnchanged'],'fractionVM':volume}),flush=True)
 out={'format':'actual7785-two-node-internal-edge-plane-rotation-plus-apex/v1','rank':1,'movingPoints':moving,'mode':{'axis':axis,'basisIndex':index,'values':values},
      'oldDocument':doc,'actualSourceBinding':binding,'proposal':proposal,'results':rows,'sourceSHA256':{'driver':V.sha(__file__),'parameterizedSolver':V.sha(H/'parameterized_internal_solver.py'),'auditor':V.sha(H/'audit_internal_polygon_motion.py'),'originalSolver':V.sha(F/'joint_flat_count_proxy_solver.py'),'originalAuditor':V.sha(N/'audit_shared_point_candidate.py')},
      'elapsedSeconds':time.monotonic()-start,'noMeshMutation':True,'nativeAcceptance':False}
 (H/'paired-internal-edge-joint-apex-audit.json').write_text(json.dumps(out,indent=2)+'\n')
if __name__=='__main__':main()
