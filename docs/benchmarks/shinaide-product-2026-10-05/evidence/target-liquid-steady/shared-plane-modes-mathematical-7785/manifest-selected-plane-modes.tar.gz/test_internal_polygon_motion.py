from pathlib import Path
from fractions import Fraction as F
import copy,json,sys
import numpy as np
import pytest
H=Path(__file__).resolve().parent
sys.path.insert(0,str(H))
import internal_quad_plane_modes as L
import audit_internal_polygon_motion as P
import combine_rank_tagged_motion as C
V=P.V

def square():
    return {'points':{'0':[0.,0.,0.],'1':[0.,1.,0.],'2':[0.,1.,1.],'3':[0.,0.,1.]},
            'faces':{'10':{'pointIDs':[0,1,2,3]}}}
def test_exact_pair_mode_rotates_plane():
    doc=square();r=L.modes(doc,[2,3],0,2)
    assert r['nullity']==1 and r['targetCanMove']
    v=[F(x) for x in r['basis'][0]]
    assert v[0]==v[1]!=0
    coeff=L.coefficients(doc['points'],[0,1,2,3],0)
    assert sum(c*x for c,x in zip(coeff,[F(0),F(0),F(1,8),F(1,8)]))==0
def test_single_node_quad_motion_rejected_by_exact_equations():
    assert not L.modes(square(),[2],0,2)['targetCanMove']
def test_in_plane_coordinate_is_not_artificially_locked():
    r=L.modes(square(),[2],1,2)
    assert r['equations']==0 and r['targetCanMove']
def test_actual_mode_support_is_complete_and_finite():
    d=json.loads((H/'depth1-actual-plane-modes.json').read_text())
    assert d['pointStarAllFacesProtectedFree'] and d['actualSourceBinding']['coordinateAndCompleteIncidenceDPExact']
    r=d['modes'][1];v=[F(x) for x in r['basis'][4]]
    nonzero={p:x for p,x in zip(r['movingPoints'],v) if x}
    assert set(nonzero)=={19982,576148} and len(set(nonzero.values()))==1

@pytest.fixture(scope='module')
def left():return json.loads((H/'targeted-ratio-internal-edge-audit.json').read_text())
@pytest.fixture(scope='module')
def pos(left):return next(r for r in left['results'] if r['run']==1 and r['fraction']==.95)
@pytest.fixture(scope='module')
def joint():return json.loads((H/'combined-fourteen-point-two-rank-audit.json').read_text())

def test_original_complete_formula_reproduces_left_positive(left,pos):
    a=P.authorize_internal_polygon(left['oldDocument'],pos['candidateDocument'],left['movingPoints'])
    assert a['mathematicalLocalCandidateAccepted']
    assert a['oldCounts']['ratio']==1 and a['newCounts']['ratio']==0
    assert a['oldCounts']['D']==a['newCounts']['D']==8
    assert a['oldCounts']['weight']==a['newCounts']['weight']==17
    assert all(q['CC_DP_exact'] and q['V_DP_exact'] for q in a['outsideByteMoments'])
def test_plane_rotation_and_volume_moment_exact(pos):
    assert pos['allSignedDeterminantsExactUnchanged']
    assert all(w['signedDeterminantExactUnchanged'] for w in pos['coordinateOnlyNonTriDeterminants'])
    assert pos['coreFractionVolumeMomentExact']
def test_unequal_internal_edge_motion_is_rejected(left,pos):
    new=copy.deepcopy(pos['candidateDocument']);new['points']['576148'][1]+=1e-4
    a=P.authorize_internal_polygon(left['oldDocument'],new,left['movingPoints'])
    assert not a['mathematicalLocalCandidateAccepted'] and not a['faceGeometryGuard']
def test_fixed_cavity_point_change_is_rejected(left,pos):
    new=copy.deepcopy(pos['candidateDocument'])
    fixed=next(p for p in new['points'] if int(p) not in left['movingPoints'])
    new['points'][fixed][0]+=1e-3
    with pytest.raises(ValueError,match='nonmoving'):
        P.authorize_internal_polygon(left['oldDocument'],new,left['movingPoints'])
def test_missing_outside_cannot_authorize(left,pos):
    old=copy.deepcopy(left['oldDocument']);new=copy.deepcopy(pos['candidateDocument'])
    old['outsideCells'].pop();new['outsideCells']=old['outsideCells']
    with pytest.raises(ValueError,match='outside'):
        P.authorize_internal_polygon(old,new,left['movingPoints'])
def test_target_proposal_infeasible_run_does_not_authorize(left):
    r=next(r for r in left['results'] if r['run']==0 and r['fraction']==.999)
    assert r['audit']['newCounts']['ratio']==0
    assert not r['audit']['mathematicalLocalCandidateAccepted']
    assert r['audit']['lineage']['D']['originalPassingRoleFailures']
def test_full_joint_guard_is_recomputed_not_summed(joint):
    a=C.authorize(joint['oldDocument'],joint['candidateDocument'],joint['movingPoints'],joint['physicalPoints'],joint['internalPolygonPoints'])
    assert a['mathematicalLocalCandidateAccepted'] and a['hardOriginalPassingRoleGuard']
    assert a['oldCounts']==joint['jointAudit']['oldCounts']
    assert a['newCounts']==joint['jointAudit']['newCounts']
    assert a['newCounts']['D']==22 and a['newCounts']['weight']==18 and a['newCounts']['ratio']==0
    assert len(joint['oldDocument']['children'])==373 and len(joint['oldDocument']['outsideCells'])==271
    assert all(q['CC_DP_exact'] and q['V_DP_exact'] for q in a['outsideByteMoments'])
def test_real_binary64_roundtrip_and_scope(joint):
    assert joint['jointMathematicalCandidateAccepted'] and joint['exactCoreFractionVolumeMoment']
    assert all(f['header']['label_bytes']==4 and f['header']['scalar_bytes']==8 and f['doublePointsByteExactAfterRoundtrip'] for f in joint['binaryFormats'])
    assert not joint['nativeAcceptance'] and joint['noMeshMutation']
    assert all(r['absoluteMargin']>0 for r in joint['passingMargin'].values())
def test_physical_scope_is_fixed_footprint_not_all_face_bits(joint):
    assert not joint['jointAudit']['unchangedShellOrderedWorldCoordinatesAndRoles']
    p=joint['jointAudit']['scope']['flatPhysicalProofs'][0]
    assert p['literalWrittenFootprintPreserved'] and p['outerRingOrderedWorldCoordinatesDPExact']
    assert p['rawSTLNormalOffsetNotCorrected']
def test_flat_normal_coordinate_tamper_rejected(joint):
    new=copy.deepcopy(joint['candidateDocument']);p=str(joint['physicalPoints'][0]);new['points'][p][2]+=1e-4
    with pytest.raises(ValueError):
        C.authorize(joint['oldDocument'],new,joint['movingPoints'],joint['physicalPoints'],joint['internalPolygonPoints'])
def test_warning_exchange_does_not_weaken_hard_thresholds(joint):
    a=joint['jointAudit']
    assert a['warningLabelExchangeAllowed'] and a['maximumWarningDegrees']<88.2022
    assert a['hardOriginalPassingRoleGuard'] and a['newCounts']['ratio']==0
    assert joint['passingMargin']['D']['threshold']==.001
    assert joint['passingMargin']['weight']['threshold']==.05
    assert joint['passingMargin']['ratio']['threshold']==.01
