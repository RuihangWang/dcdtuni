# Actual 7785 flat physical and internal shared-point candidate

Current product status remains strict Failed3 D909/W100/R2. This directory contains mathematical in-memory proposals only; no actual points, CFD project, source C++, solver, service or git index was changed. All original readers/arrays/roles are bound to the frozen7785 case manifest.

## Literal boundary preservation

The additional rank3 point569596 is interior to the ACU_03_Front_patch physical point-star. Four physical faces share the exact current written support plane Z=2.8185203125; patch-name/type identity and source zone−1 are retained. The ordered outer ring [568472,569595,41510,568846,568844] excludes this point and its coordinates remain DP-exact. Only XY may move. Opposed interior physical edges cancel; all pieces remain positive convex; exact Fraction signed area/first moments equal the original footprint. The unchanged boundary dictionary hash binds the original patch metadata; boundary conditions themselves are not edited.

Raw merged_acu.stl instead has Z=2.8169 for this solid. The existing written-to-raw STL normal deviation is1.6203125mm. `existing-raw-stl-normal-offset.json` retains that fact and source STL hash. The candidate keeps the same written normal coordinate, neither increases nor corrects this deviation, and does not claim raw-STL exact geometry.

## Actual local results

The initial maximin objective yields a valid but less useful candidate. The second bounded count-proxy proposal uses the same physical/geometry/hard-quality constraints and complete original-formula acceptance. `flat-count-proxy-audit.json` run0/fraction.999 moves three interior points plus the one physical tangent point, reducing D19 to8 and W12 to1, R/S0. It still contains8 D/1 W failures. Folded physical pieces and a backtrack with a newly failed ratio are rejected and preserved.

The full simultaneous result replaces the interior-only first component with this4-point candidate and combines two previously verified3-point components. `combined-flat-and-internal-components-audit.json`:10 moving points,277 core plus188 outside cells,696 affected faces (1179 stored faces). Original-formula D33 to10/W14 to1/R0/S0; N warnings39 to43, maximum81.60635726 degrees below the original global88.2022 maximum. All original passing hard roles retain passage and their failed-count/severity guards pass. All188 outside CC/V DP representations are exact. Exact Fraction core signed volume and first moment are preserved. A global rank point-distance check includes other simultaneously proposed points and exceeds writer1 micrometre and3 micrometre safety guards.

## Actual-format roundtrip

The real rank3 points header is binary LSB;label=32;scalar=64. The real Mesh/controlDict selects writeFormat binary/writePrecision6. Installed UListIO.C:92-101 writes contiguous binary data bytes; decimal precision6 does not truncate the binary scalar payload. `audit_writer_point_format.py` changes only the raw binary64 coordinate payload in an isolated scratch copy and re-reads through the current production polymesh_io.py reader. Every proposed coordinate bit and every other actual rank3 point bit is retained; the complete mathematical audit has the same result.

The minimum passing D after the candidate is.0010008597687517957, giving8.5976875e-7 absolute margin above.001, rather than machine-roundoff-sized passage. Minimum passing W=.0539967643 and R=.0141236853. These are mathematical-format margins. This test does not invoke the actual C++ writer, does not validate a new C++ cache update or alias/sort/installed-moment path, and cannot replace future actual stock fullcheck.

## Regressions and failures

Flat semantic tests:12 passed. Actual-format/scope tests:8 passed. Original interior tests:17 passed in the sibling directory. First proposal import indentation failure is kept in attempt1-import-failure. The first two format-test attempts are retained: synthetic headers lacked the separator required by the production reader; the first attempt also found a string/int set mismatch in a report-only physical-face equality flag. The serialization/candidate guards and proposed coordinates did not change during these fixes. Final tests cover binary signed-zero preservation, scalar32/ASCII/nonfinite refusal, exact physical domain, whole local hard-role margins and honest native scope.

No new native run, compile or production acceptance has occurred. Current C/H/app identities remain ead4a057/4a5ef961/babd07c8 and defaults remain unchanged. The entire300 second product deadline is still mandatory.
