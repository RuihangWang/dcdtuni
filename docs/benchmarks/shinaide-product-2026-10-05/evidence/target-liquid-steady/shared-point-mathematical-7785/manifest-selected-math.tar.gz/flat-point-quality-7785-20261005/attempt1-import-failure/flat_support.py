"""Exact literal-written-plane footprint guard; no STL projection or mesh writes."""
from pathlib import Path
from collections import Counter
from fractions import Fraction as Q
import sys,json,copy
import numpy as np
HERE=Path(__file__).resolve().parent;N=HERE.parent/"shared-point-quality-7785-20261005";AIR=HERE.parents[1]
sys.path[:0]=[str(N),str(N/"readers"),str(AIR/"src")]
import audit_shared_point_candidate as V
U=V.U
F=lambda x:Q.from_float(float(x))
def signed(doc,ids,axis):
 axes=[a for a in range(3) if a!=axis]
 xy=[[F(doc["points"][str(p)][a]) for a in axes] for p in ids]
 a=m0=m1=Q(0)
 for (x,y),(u,v) in zip(xy,xy[1:]+xy[:1]):
  cross=x*v-u*y;a+=cross;m0+=(x+u)*cross;m1+=(y+v)*cross
 return (a,m0,m1)
def convex(doc,ids,axis,sense):
 axes=[a for a in range(3) if a!=axis]
 xy=[[F(doc["points"][str(p)][a]) for a in axes] for p in ids]
 if signed(doc,ids,axis)[0]*sense<=0:return False
 for a,b in zip(xy,xy[1:]+xy[:1]):
  for c in xy:
   if ((b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0]))*sense<0:return False
 return True
def footprint(old,new,point):
 fs=[int(f) for f,r in old["faces"].items() if point in r["pointIDs"] and r["patch"] is not None]
 if not fs:raise ValueError("one actual physical point star required")
 rows=[old["faces"][str(f)] for f in fs]
 if any(V.coupled(r["patch"]) or r["sourceZone"]!=-1 for r in rows):raise ValueError("physical coupled/zone touch refused")
 if any(r["patch"]!=rows[0]["patch"] for r in rows):raise ValueError("same physical BC identity required")
 ps={p for r in rows for p in r["pointIDs"]}
 axes=[a for a in range(3) if all(V.same_dp(old["points"][str(p)][a],old["points"][str(point)][a]) for p in ps)]
 if len(axes)!=1:raise ValueError("exact common written axis support required")
 axis=axes[0];plane=old["points"][str(point)][axis]
 if not all(V.same_dp(new["points"][str(p)][axis],plane) for p in ps):raise ValueError("normal physical plane displacement refused")
 edge=Counter()
 for r in rows:
  ids=r["pointIDs"]
  for a,b in zip(ids,ids[1:]+ids[:1]):edge[(a,b)]+=1
 for a,b in list(edge):
  if a<b and edge[(a,b)] and edge[(b,a)]:
   if edge[(a,b)]!=1 or edge[(b,a)]!=1:raise ValueError("nonmanifold physical ring")
   del edge[(a,b)];del edge[(b,a)]
 if any(v!=1 for v in edge.values()) or any(point in e for e in edge):raise ValueError("physical patch outer-boundary point refused")
 nxt={}
 for a,b in edge:
  if a in nxt:raise ValueError("branching physical outline")
  nxt[a]=b
 start=min(nxt,key=lambda p:tuple(old["points"][str(p)]));loop=[start]
 while nxt[loop[-1]]!=start:
  q=nxt[loop[-1]]
  if q in loop:raise ValueError("multiple physical outline components")
  loop.append(q)
 if len(loop)!=len(nxt):raise ValueError("incomplete physical outline")
 if not all(V.same_dp(old["points"][str(p)],new["points"][str(p)]) for p in loop):raise ValueError("physical outer ring changed")
 sense=1 if signed(old,rows[0]["pointIDs"],axis)[0]>0 else -1
 before=tuple(sum((signed(old,r["pointIDs"],axis)[i] for r in rows),Q(0)) for i in range(3))
 after=tuple(sum((signed(new,r["pointIDs"],axis)[i] for r in rows),Q(0)) for i in range(3))
 if before!=after:raise ValueError("exact physical signed area or first moment changed")
 if not all(convex(new,r["pointIDs"],axis,sense) for r in rows):raise ValueError("physical tessellation overlap/degeneracy possible")
 return {"point":point,"axis":axis,"writtenPlaneCoordinate":plane,"physicalRole":rows[0]["patch"],"physicalFaces":fs,"outerRing":loop,
  "outerRingOrderedWorldCoordinatesDPExact":True,"exactNormalCoordinateDPUnchanged":True,"signedTwiceAreaAndSixFirstMomentsBefore":[str(x) for x in before],
  "signedTwiceAreaAndSixFirstMomentsAfter":[str(x) for x in after],"signedAreaFirstMomentsFractionExact":True,
  "allPhysicalPiecesConvexPositive":True,"literalWrittenFootprintPreserved":True,"rawSTLNormalOffsetNotCorrected":True}
def validate(old,new,moving,physical_points):
 physical_points=set(physical_points);moving=set(moving)
 if any(old.get(k)!=new.get(k) for k in ("faces","cells","children","outsideCells","apexWrittenPoint")):raise ValueError("all roles/topology must remain")
 if set(old["points"])!=set(new["points"]):raise ValueError("point cardinality changed")
 if not all(np.isfinite(v).all() for v in map(np.asarray,new["points"].values())):raise ValueError("nonfinite")
 if not all(V.same_dp(v,new["points"][p]) for p,v in old["points"].items() if int(p) not in moving):raise ValueError("nonmoving point changed")
 if not V.same_dp(new["originalApex"],new["points"][str(new["apexWrittenPoint"])]):raise ValueError("stale apex override")
 incident={int(f) for f,r in old["faces"].items() if moving.intersection(r["pointIDs"])}
 core={old["faces"][str(f)]["owner"] for f in incident}|{old["faces"][str(f)]["neighbour"] for f in incident if old["faces"][str(f)]["neighbour"] is not None}
 if core!=set(old["children"]):raise ValueError("full point star required")
 af={f for c in core for f in old["cells"][str(c)]["faces"]}
 outside={old["faces"][str(f)]["owner"] for f in af}|{old["faces"][str(f)]["neighbour"] for f in af}
 outside.discard(None);outside-=core
 if outside!=set(old["outsideCells"]) or set(map(int,old["cells"]))!=core|outside:raise ValueError("complete outside required")
 for c in core|outside:
  for f in old["cells"][str(c)]["faces"]:
   row=old["faces"][str(f)]
   if V.coupled(row["patch"]) or row["sourceZone"]!=-1:raise ValueError("coupled/zone full-star protection")
 for p in moving-physical_points:
  for f in incident:
   r=old["faces"][str(f)]
   if p in r["pointIDs"] and (r["patch"] is not None or len(r["pointIDs"])!=3):raise ValueError("internal free point unsupported")
 proofs=[footprint(old,new,p) for p in sorted(physical_points)]
 shell={f for f in af if (old["faces"][str(f)]["owner"] in core)!=(old["faces"][str(f)]["neighbour"] in core)}
 changed_physical={f for z in proofs for f in z["physicalFaces"]}
 if any(moving.intersection(old["faces"][str(f)]["pointIDs"]) for f in shell-changed_physical):raise ValueError("nonphysical cavity shell moved")
 return {"incidentFaces":sorted(incident),"coreCells":sorted(core),"outsideCells":sorted(outside),"shellFaces":sorted(shell),"flatPhysicalProofs":proofs}
# Reuse the full original-formula numerical evaluator, replacing only the
# structural domain: exact planar physical-interior point freedom above.
import inspect
text=inspect.getsource(V.authorize).replace("def authorize(","def authorize_flat(")
text=text.replace("scope=validate_structure(old,new,moving)","scope=validate(old,new,moving,physical_points)")
text=text.replace("warning_ceiling=88.2022):","warning_ceiling=88.2022,physical_points=()):")
exec(text,globals())
def actual_metrics(doc):return V.actual_metrics(doc)
def same_dp(a,b):return V.same_dp(a,b)
HARD=V.HARD
