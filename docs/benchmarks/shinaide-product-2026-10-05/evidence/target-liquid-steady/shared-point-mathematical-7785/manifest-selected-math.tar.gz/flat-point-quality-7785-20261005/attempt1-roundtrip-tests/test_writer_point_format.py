from pathlib import Path
import sys,json,copy
import numpy as np
import pytest
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
import audit_writer_point_format as W
F,V=W.F,W.V
@pytest.fixture(scope="module")
def record():return json.loads((HERE/"writer-format-roundtrip-audit.json").read_text())
def test_actual_binary_roundtrip_has_full_green_guard(record):
 assert record["serialization"]["doublePointsByteExactAfterRoundtrip"]
 assert record["serialization"]["allOtherActualRankPointBytesUnchanged"]
 assert record["audit"]["mathematicalLocalCandidateAccepted"]
 assert record["audit"]["oldCounts"]["D"]==33 and record["audit"]["newCounts"]["D"]==10
 assert record["audit"]["oldCounts"]["weight"]==14 and record["audit"]["newCounts"]["weight"]==1
def test_true_binary_roundtrip_reproduces_current_scalar_signed_zero(tmp_path):
 actual=tmp_path/"old";out=tmp_path/"new"
 xyz=np.array([[1.1,-0.,1.e-20],[.2,.3,.4]],dtype="<f8")
 actual.write_bytes(b'FoamFile { version 2.0; format binary; arch "LSB;label=32;scalar=64"; class vectorField; object points; }\n2\n('+xyz.tobytes()+b')\n')
 new,q=W.write_binary_points_copy(actual,out,{0:[1.2,-0.,1.e-20]})
 assert q["doublePointsByteExactAfterRoundtrip"] and np.signbit(new[0,1])
 assert new[0,0]==1.2 and V.same_dp(new[1],xyz[1])
def test_ascii_precision_six_is_not_treated_as_actual_binary(tmp_path):
 p=tmp_path/"ascii";p.write_text('FoamFile { format ascii; class vectorField; object points; }\n1\n((1 2 3))\n')
 with pytest.raises(ValueError,match="witnessed LSB binary64"):W.write_binary_points_copy(p,tmp_path/"out",{0:[1,2,3]})
def test_scalar32_is_refused(tmp_path):
 p=tmp_path/"float";p.write_bytes(b'FoamFile { format binary; arch "LSB;label=32;scalar=32"; class vectorField; object points; }\n1\n('+np.array([1,2,3],dtype="<f4").tobytes()+b')')
 with pytest.raises(ValueError,match="witnessed LSB binary64"):W.write_binary_points_copy(p,tmp_path/"out",{0:[1,2,3]})
def test_nonfinite_and_wrong_point_shape_are_refused(tmp_path):
 p=tmp_path/"good";p.write_bytes(b'FoamFile { format binary; arch "LSB;label=32;scalar=64"; class vectorField; object points; }\n1\n('+np.array([1,2,3],dtype="<f8").tobytes()+b')')
 for xyz in ([1,np.nan,3],[1,2]):
  with pytest.raises(ValueError,match="invalid proposal"):W.write_binary_points_copy(p,tmp_path/"out",{0:xyz})
def test_fraction_moments_and_exact_physical_domain_preserved(record):
 assert record["exactFractionCoreSignedVolumeAndFirstMomentPreserved"]
 assert record["changedPhysicalFacesExactlyCertifiedPointStar"]
 assert record["exactFractionCoreSignedVolumeAndFirstMomentBefore"]==record["exactFractionCoreSignedVolumeAndFirstMomentAfter"]
def test_original_passing_margin_not_machine_roundoff(record):
 assert record["originalPassingHardRoleMargin"]["D"]["minimumAbsolutePassingMargin"]>8e-7
 assert record["originalPassingHardRoleMargin"]["weight"]["minimumAbsolutePassingMargin"]>.0039
 assert all(z["minimumAbsolutePassingMargin"]>0 for z in record["originalPassingHardRoleMargin"].values())
def test_roundtrip_scope_not_native_writer_or_whole_mesh_acceptance(record):
 assert not record["nativeAcceptance"]
 assert not record["installedCppWriterAliasSortMomentRoundtripTested"]
 assert not record["serialization"]["nativeWriterInvoked"]
 assert record["noActualMeshMutation"]
