"""Controlled actual-format serialization; no installed/native writer invocation."""
from pathlib import Path
from fractions import Fraction as Q
import sys,json,copy,time,hashlib
import numpy as np
HERE=Path(__file__).resolve().parent;AIR=HERE.parents[1]
N=HERE.parent/"shared-point-quality-7785-20261005"
sys.path[:0]=[str(HERE),str(N),str(N/"readers"),str(AIR/"src")]
import flat_support as F
from backend.aircooling.runner import polymesh_io as IO
V=F.V
M=AIR.parent/"integration/.codex-tmp/cases/Shinaide_MeshAbort_CUA/Mesh"

def write_binary_points_copy(actual_path,scratch_path,proposals):
 raw=Path(actual_path).read_bytes();info=IO.foam_header_info(raw)
 if info["format"]!="binary" or info["scalar_bytes"]!=8 or b"LSB;label=32;scalar=64" not in raw[:2048]:
  raise ValueError("only witnessed LSB binary64 actual format supported")
 count,offset=IO._binary_list_at(raw,IO._payload_start(raw));points=IO.read_points(actual_path).copy()
 for p,xyz in proposals.items():
  if not 0<=int(p)<count or np.asarray(xyz).shape!=(3,) or not np.isfinite(xyz).all():raise ValueError("invalid proposal coordinate")
  points[int(p)]=xyz
 payload=points.astype("<f8").tobytes(order="C")
 before=raw[:offset];after=raw[offset+count*24:]
 Path(scratch_path).write_bytes(before+payload+after)
 reread=IO.read_points(scratch_path)
 if not V.same_dp(points,reread):raise ValueError("binary-format re-read differs")
 return reread,{"actualSourcePointsSHA256":V.sha(actual_path),"scratchPointsSHA256":V.sha(scratch_path),"header":info,"count":count,"payloadOffset":offset,"payloadBytes":len(payload),"headerAndSuffixByteExact":True,"doublePointsByteExactAfterRoundtrip":True,"decimalWritePrecisionDoesNotApplyToRawBinaryScalarPayload":True,"nativeWriterInvoked":False}

def margin_summary(oldmetrics,newmetrics):
 out={}
 for k in V.HARD:
  lim,upper=V.U.LIMITS[k];domain="cells" if k=="D" else "faces";idkey="cell" if k=="D" else "face"
  old={r[idkey]:r[k] for r in oldmetrics[domain] if k in r};records=[]
  for r in newmetrics[domain]:
   if k not in r:continue
   value=r[k];old_pass=np.isfinite(old[r[idkey]]) and (old[r[idkey]]<=lim if upper else old[r[idkey]]>=lim)
   if old_pass:records.append((lim-value if upper else value-lim,r[idkey],value))
  z=min(records)
  out[k]={"threshold":lim,"minimumAbsolutePassingMargin":z[0],"minimumRelativePassingMargin":z[0]/lim,"element":z[1],"candidateValue":z[2],"originalPassingRolesCompared":len(records)}
 return out

def exact_core_moments(doc):
 core=set(doc["children"]);total=Q(0);moment=[Q(0)]*3
 coords={int(p):[Q.from_float(float(x)) for x in xyz] for p,xyz in doc["points"].items()}
 for c in core:
  for f in doc["cells"][str(c)]["faces"]:
   row=doc["faces"][str(f)];ids=row["pointIDs"];sense=1 if row["owner"]==c else -1
   a=coords[ids[0]]
   for i in range(1,len(ids)-1):
    b=coords[ids[i]];d=coords[ids[i+1]]
    determinant=a[0]*(b[1]*d[2]-b[2]*d[1])-a[1]*(b[0]*d[2]-b[2]*d[0])+a[2]*(b[0]*d[1]-b[1]*d[0])
    vol=sense*determinant/6;total+=vol
    for k in range(3):moment[k]+=vol*(a[k]+b[k]+d[k])/4
 return (str(total),*[str(q) for q in moment])

def main():
 started=time.monotonic();input_path=HERE/"combined-flat-and-internal-components-audit.json";x=json.loads(input_path.read_text());old=x["oldDocument"];candidate=x["candidateDocument"];moving=x["movingPoints"]
 reread,fmt=write_binary_points_copy(M/"processor3/constant/polyMesh/points",HERE/"combined-candidate-points.binary-format-copy",{p:candidate["points"][str(p)] for p in moving})
 new=copy.deepcopy(candidate)
 for p in new["points"]:new["points"][p]=reread[int(p)].tolist()
 new["originalApex"]=new["points"][str(new["apexWrittenPoint"])]
 audit=F.authorize_flat(old,new,moving,physical_points=x["physicalPoints"])
 g=V.G.Geometry(M/"processor3/constant/polyMesh");audit["globalRankPointClearance"]=V.global_gap(g,new,moving)
 if not all(r["exceedsWriter1MicrometreAnd3MicrometreSafety"] for r in audit["globalRankPointClearance"]):audit["mathematicalLocalCandidateAccepted"]=False
 fixed=np.ones(len(g.points),dtype=bool);fixed[moving]=False
 fmt["allOtherActualRankPointBytesUnchanged"]=V.same_dp(reread[fixed],g.points[fixed]);fmt["completeLocalDocumentPointsDPExact"]=all(V.same_dp(candidate["points"][p],new["points"][p]) for p in new["points"])
 a=exact_core_moments(old);b=exact_core_moments(new)
 physical=x["physicalPoints"];boundaryFaces={int(f) for f,r in old["faces"].items() if r["patch"] is not None}
 allCoreFaces={f for c in old["children"] for f in old["cells"][str(c)]["faces"]}
 affect={f for f in allCoreFaces if set(moving)&set(old["faces"][str(f)]["pointIDs"])}
 boundaryChange={f for f in affect if f in boundaryFaces};allowed={int(f) for p in physical for f,r in old["faces"].items() if int(f) in boundaryFaces and p in r["pointIDs"]}
 out={"format":"actual7785-binary-points-format-and-full-candidate-re-read/v1","inputSHA256":V.sha(input_path),"toolSHA256":V.sha(__file__),"serialization":fmt,"movingPoints":moving,"physicalPoints":physical,"audit":audit,"originalPassingHardRoleMargin":margin_summary(audit["oldActualMetrics"],audit["newActualMetrics"]),"exactFractionCoreSignedVolumeAndFirstMomentBefore":a,"exactFractionCoreSignedVolumeAndFirstMomentAfter":b,"exactFractionCoreSignedVolumeAndFirstMomentPreserved":a==b,"changedPhysicalFacesExactlyCertifiedPointStar":boundaryChange==allowed,"changedPhysicalFaces":sorted(boundaryChange),"candidateDocument":new,"elapsedSeconds":time.monotonic()-started,"noActualMeshMutation":True,"nativeAcceptance":False,"installedCppWriterAliasSortMomentRoundtripTested":False}
 (HERE/"writer-format-roundtrip-audit.json").write_text(json.dumps(out,indent=2)+"\n")
 print(json.dumps({"accepted":audit["mathematicalLocalCandidateAccepted"],"oldCounts":audit["oldCounts"],"newCounts":audit["newCounts"],"binaryDPExact":fmt["doublePointsByteExactAfterRoundtrip"],"exactFractionMoments":a==b,"margins":out["originalPassingHardRoleMargin"],"elapsedSeconds":out["elapsedSeconds"]}),flush=True)
if __name__=="__main__":main()
