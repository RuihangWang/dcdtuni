from pathlib import Path
import sys,json,copy,time,ast
import numpy as np
HERE=Path(__file__).resolve().parent;AIR=HERE.parents[1]
N=HERE.parent/"shared-point-quality-7785-20261005";P=HERE.parent/"shared-point-components-7785-20261005"
sys.path[:0]=[str(HERE),str(N),str(N/"readers"),str(AIR/"src")]
import flat_support as F
V=F.V;G,T=V.G,V.T
# Pure helper AST only: the older driver is not executed.
tree=ast.parse((P/"run_bounded_joint.py").read_text());defs=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ("cf","document")]
exec(compile(ast.Module(body=defs,type_ignores=[]),str(P/"run_bounded_joint.py"),"exec"),globals())
M=AIR.parent/"integration/.codex-tmp/cases/Shinaide_MeshAbort_CUA/Mesh";E=AIR/".codex-tmp/installed-writer-cua-7785c33f"
def main():
 started=time.monotonic();sources=[HERE/"flat-count-proxy-audit.json",P/"cluster1-joint-audit.json",P/"cluster2-joint-audit.json"]
 parts=[];moving=[];coords={}
 for path in sources:
  r=json.loads(path.read_text());records=r.get("results",r.get("backtracks"))
  chosen=next(x for x in records if x["run"]==0 and x["fraction"]==.999)
  if not chosen["audit"]["mathematicalLocalCandidateAccepted"]:raise ValueError("unaccepted component")
  for p in r["movingPoints"]:
   if p in coords:raise ValueError("overlapping proposal points")
   moving.append(p);coords[p]=chosen["candidateDocument"]["points"][str(p)]
  parts.append({"path":str(path),"SHA256":V.sha(path),"run":0,"fraction":.999,"movingPoints":r["movingPoints"]})
 g=G.Geometry(M/"processor3/constant/polyMesh");t=T.read_trace(M,3)
 old=document(g,t,moving);new=copy.deepcopy(old)
 for p,q in coords.items():new["points"][str(p)]=q
 new["originalApex"]=new["points"][str(new["apexWrittenPoint"])]
 _,_,binding=V.raw_binding(old,moving,M,3,E/"case-file-manifest.json")
 audit=F.authorize_flat(old,new,moving,physical_points=[569596]);audit["globalRankPointClearance"]=V.global_gap(g,new,moving)
 if not all(x["exceedsWriter1MicrometreAnd3MicrometreSafety"] for x in audit["globalRankPointClearance"]):audit["mathematicalLocalCandidateAccepted"]=False
 trace=[{"writtenPoint":p,"nativePoint":int(t["pointNative"][p]),"oldCoordinates":old["points"][str(p)],"candidateCoordinates":new["points"][str(p)],"deltaM":(np.asarray(new["points"][str(p)])-old["points"][str(p)]).tolist()} for p in moving]
 result={"format":"actual7785-combined-flat-and-two-internal-components/v1","movingPoints":moving,"physicalPoints":[569596],"oldDocument":old,"candidateDocument":new,"components":parts,"actualSourceBinding":binding,"pointTrace":trace,"audit":audit,"elapsedSeconds":time.monotonic()-started,"toolSHA256":V.sha(__file__),"nativeAcceptance":False,"noMeshMutation":True}
 (HERE/"combined-flat-and-internal-components-audit.json").write_text(json.dumps(result,indent=2)+"\n")
 print(json.dumps({"accepted":audit["mathematicalLocalCandidateAccepted"],"oldCounts":audit["oldCounts"],"newCounts":audit["newCounts"],"Nmax":audit["maximumWarningDegrees"],"core":len(old["children"]),"outside":len(old["outsideCells"]),"elapsedSeconds":result["elapsedSeconds"]}),flush=True)
if __name__=="__main__":main()
