from pathlib import Path
import sys,json,copy,time,ast
import numpy as np
HERE=Path(__file__).resolve().parent;AIR=HERE.parents[1]
N=HERE.parent/"shared-point-quality-7785-20261005";P=HERE.parent/"shared-point-components-7785-20261005"
sys.path[:0]=[str(HERE),str(N),str(N/"readers"),str(AIR/"src")]
import flat_support as F
import joint_flat_count_proxy_solver as S
V=F.V;G,T=V.G,V.T
# Copy only two pure helper definitions; never execute the old driver.
tree=ast.parse((P/"run_bounded_joint.py").read_text());defs=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ("cf","document")]
exec(compile(ast.Module(body=defs,type_ignores=[]),str(P/"run_bounded_joint.py"),"exec"),globals())
M=AIR.parent/"integration/.codex-tmp/cases/Shinaide_MeshAbort_CUA/Mesh"
E=AIR/".codex-tmp/installed-writer-cua-7785c33f"
started=time.monotonic();g=G.Geometry(M/"processor3/constant/polyMesh");t=T.read_trace(M,3)
moving=[23651,569594,569592,569596];physical=[569596]
doc=document(g,t,moving);scope=F.validate(doc,doc,moving,physical)
_,_,binding=V.raw_binding(doc,moving,M,3,E/"case-file-manifest.json")
fixed={q["point"]:[q["axis"]] for q in scope["flatPhysicalProofs"]}
print("baseline footprint "+json.dumps(scope["flatPhysicalProofs"]),flush=True)
internal=json.loads((N/"joint-interior-backtracked.json").read_text())
internal_best=next(r for r in internal["results"] if r["run"]==1 and r["backtrackFraction"]==.999)["candidateDocument"]
seed1=copy.deepcopy(doc)
for p in internal["movingPoints"]:seed1["points"][str(p)]=internal_best["points"][str(p)]
seed1["originalApex"]=seed1["points"][str(seed1["apexWrittenPoint"])]
prior=json.loads((HERE/"flat-joint-audit.json").read_text())
seed2=next(r for r in prior["results"] if r["run"]==1 and r["fraction"]==.999)["candidateDocument"]
proposal=S.solve(doc,moving,fixed_axes=fixed,structural_validator=lambda a,b,c:F.validate(a,b,c,physical),maxiter=100,initial_docs=[seed1,seed2])
results=[]
for i,run in enumerate(proposal["runs"]):
 for fraction in [.999,.99,.95,.5,.25]:
  cand=copy.deepcopy(doc)
  for p in moving:
   a=np.asarray(doc["points"][str(p)]);b=np.asarray(run["candidateDocument"]["points"][str(p)])
   cand["points"][str(p)]=(a+fraction*(b-a)).tolist()
  cand["originalApex"]=cand["points"][str(cand["apexWrittenPoint"])]
  try:
   audit=F.authorize_flat(doc,cand,moving,physical_points=physical)
   audit["globalRankPointClearance"]=V.global_gap(g,cand,moving)
   if not all(x["exceedsWriter1MicrometreAnd3MicrometreSafety"] for x in audit["globalRankPointClearance"]):audit["mathematicalLocalCandidateAccepted"]=False
  except ValueError as error:audit={"mathematicalLocalCandidateAccepted":False,"structuralError":str(error)}
  results.append({"run":i,"fraction":fraction,"candidateDocument":cand,"audit":audit})
  print(json.dumps({"run":i,"fraction":fraction,"accepted":audit["mathematicalLocalCandidateAccepted"],"oldCounts":audit.get("oldCounts"),"newCounts":audit.get("newCounts"),"Nmax":audit.get("maximumWarningDegrees"),"structuralError":audit.get("structuralError")}),flush=True)
out={"format":"actual7785-flat-written-physical-interior-point-joint/v1","actualSourceBinding":binding,"movingPoints":moving,"physicalPoints":physical,
     "fixedWrittenAxes":fixed,"oldDocument":doc,"proposal":proposal,"results":results,"elapsedSeconds":time.monotonic()-started,
     "sourceSHA256":{p.name:V.sha(p) for p in [Path(__file__),HERE/"flat_support.py",HERE/"joint_flat_count_proxy_solver.py"]},
     "normalOffsetPolicy":"Literal current written support plane is fixed DP-exact; existing raw-STL normal offset is preserved, not corrected or represented as zero.",
     "nativeAcceptance":False,"noMeshMutation":True}
(HERE/"flat-count-proxy-audit.json").write_text(json.dumps(out,indent=2)+"\n")
print(json.dumps({"elapsedSeconds":out["elapsedSeconds"],"core":len(doc["children"]),"outside":len(doc["outsideCells"])}),flush=True)
