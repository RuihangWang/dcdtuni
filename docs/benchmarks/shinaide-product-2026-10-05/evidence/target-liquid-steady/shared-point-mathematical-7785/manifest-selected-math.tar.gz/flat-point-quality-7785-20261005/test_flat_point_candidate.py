"""Semantic geometry regressions for the exact flat written-plane domain."""
from pathlib import Path
import sys,copy,json
import numpy as np
import pytest
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE));import flat_support as F
@pytest.fixture(scope="module")
def fixture():
 x=json.loads((HERE/"flat-count-proxy-audit.json").read_text())
 r=next(r for r in x["results"] if r["run"]==0 and r["fraction"]==.999)
 return x,r
@pytest.fixture(scope="module")
def audit(fixture):
 x,r=fixture
 return F.authorize_flat(x["oldDocument"],r["candidateDocument"],x["movingPoints"],physical_points=x["physicalPoints"])
def test_actual_hard_defects_improve_without_new_passing_failure(audit):
 assert audit["oldCounts"]["D"]==19 and audit["oldCounts"]["weight"]==12
 assert audit["newCounts"]["D"]==8 and audit["newCounts"]["weight"]==1
 assert audit["mathematicalLocalCandidateAccepted"] and not audit["nativeAcceptance"]
 assert all(not audit["lineage"][k]["originalPassingRoleFailures"] for k in F.HARD)
def test_original_formula_geometry_and_full_outside_are_protected(audit):
 assert audit["cellGeometryGuard"] and audit["faceGeometryGuard"]
 assert len(audit["outsideByteMoments"])==101
 assert all(r["CC_DP_exact"] and r["V_DP_exact"] for r in audit["outsideByteMoments"])
 assert audit["sumVolumeRelativeDifference"]<1e-10 and audit["sumFirstMomentDifferenceM4"]<1e-10
def test_exact_physical_footprint_and_normal_coordinate(audit):
 p=audit["scope"]["flatPhysicalProofs"][0]
 assert p["literalWrittenFootprintPreserved"] and p["signedAreaFirstMomentsFractionExact"]
 assert p["signedTwiceAreaAndSixFirstMomentsBefore"]==p["signedTwiceAreaAndSixFirstMomentsAfter"]
 assert p["exactNormalCoordinateDPUnchanged"] and p["outerRingOrderedWorldCoordinatesDPExact"]
 assert p["rawSTLNormalOffsetNotCorrected"]
def test_physical_point_is_not_on_the_patch_outer_ring(audit):
 p=audit["scope"]["flatPhysicalProofs"][0]
 assert p["point"] not in p["outerRing"] and len(p["outerRing"])==5
def test_nonflat_cavity_shell_world_coordinates_remain_dp_exact(fixture,audit):
 x,r=fixture;old=x["oldDocument"];new=r["candidateDocument"]
 phys={f for p in audit["scope"]["flatPhysicalProofs"] for f in p["physicalFaces"]}
 for f in set(audit["scope"]["shellFaces"])-phys:
  assert old["faces"][str(f)]==new["faces"][str(f)]
  assert all(F.V.same_dp(old["points"][str(p)],new["points"][str(p)]) for p in old["faces"][str(f)]["pointIDs"])
 # Surface tessellation's internal point really changed; do not claim every
 # old physical coordinate was retained merely because its footprint was.
 assert not F.V.same_dp(old["points"]["569596"],new["points"]["569596"])
def test_one_ulp_normal_displacement_is_refused(fixture):
 x,r=fixture;new=copy.deepcopy(r["candidateDocument"]);new["points"]["569596"][2]=float(np.nextafter(new["points"]["569596"][2],np.inf))
 with pytest.raises(ValueError,match="normal physical plane"):F.footprint(x["oldDocument"],new,569596)
def test_physical_outer_ring_coordinate_change_is_refused(fixture):
 x,r=fixture;new=copy.deepcopy(r["candidateDocument"]);p=F.footprint(x["oldDocument"],new,569596)["outerRing"][0]
 new["points"][str(p)][0]+=1e-4
 with pytest.raises(ValueError,match="outer ring"):F.footprint(x["oldDocument"],new,569596)
def test_different_physical_bc_identity_is_refused(fixture):
 x,r=fixture;old=copy.deepcopy(x["oldDocument"]);new=copy.deepcopy(r["candidateDocument"])
 f=F.footprint(old,new,569596)["physicalFaces"][0];old["faces"][str(f)]["patch"]["name"]="other_bc";new["faces"][str(f)]["patch"]["name"]="other_bc"
 with pytest.raises(ValueError,match="same physical BC"):F.footprint(old,new,569596)
def test_protected_zone_is_refused(fixture):
 x,r=fixture;old=copy.deepcopy(x["oldDocument"]);new=copy.deepcopy(r["candidateDocument"])
 f=F.footprint(old,new,569596)["physicalFaces"][0];old["faces"][str(f)]["sourceZone"]=4;new["faces"][str(f)]["sourceZone"]=4
 with pytest.raises(ValueError,match="zone"):F.footprint(old,new,569596)
def test_folded_physical_tessellation_proposal_is_rejected(fixture):
 x,_=fixture;prior=json.loads((HERE/"flat-joint-audit.json").read_text())
 bad=next(r for r in prior["results"] if r["run"]==0 and r["fraction"]==.25)["candidateDocument"]
 with pytest.raises(ValueError,match="overlap/degeneracy"):F.footprint(x["oldDocument"],bad,569596)
def test_raw_stl_normal_offset_is_retained_not_hidden(fixture):
 x,r=fixture;offset=json.loads((HERE/"existing-raw-stl-normal-offset.json").read_text())
 assert offset["rawSTLNormalCoordinate"]==2.8169 and offset["writtenSupportNormalCoordinate"]==2.8185203125
 assert offset["existingWrittenMinusRawSTLNormalOffsetM"]>1e-3 and not offset["rawSTLOffsetCorrected"]
 assert F.V.same_dp(x["oldDocument"]["points"]["569596"][2],r["candidateDocument"]["points"]["569596"][2])
def test_rejected_mid_backtrack_cannot_bypass_ratio_role(fixture):
 x,r=fixture;bad=next(r for r in x["results"] if r["run"]==0 and r["fraction"]==.5)
 a=F.authorize_flat(x["oldDocument"],bad["candidateDocument"],x["movingPoints"],physical_points=x["physicalPoints"])
 assert not a["mathematicalLocalCandidateAccepted"] and a["lineage"]["ratio"]["originalPassingRoleFailures"]
