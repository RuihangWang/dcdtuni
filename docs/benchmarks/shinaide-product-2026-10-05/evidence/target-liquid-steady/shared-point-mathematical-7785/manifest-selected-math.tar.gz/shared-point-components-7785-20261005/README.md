# Actual 7785 mobility and finite additional joint components

The current actual failed sets are D909/W100/R2. All eight ranks are bound to immutable original polyMesh and trace hashes in rankN-mobility-bound.json. The screen finds307 interior points whose complete incidents are triangular and whose complete local point-star/outside stencil has no coupled/zone face. Among909 D cells,325 have zero,565 one,17 two and2 at least three such points.256 D cells have a necessary exact-flat same-patch tangential support candidate. These are narrow screen counts, not feasibility or impossibility proofs; points and cells overlap. No physical node is permanently declared immovable.

Eleven finite2-3-point clusters come from actual failed-cell adjacency. The additional driver evaluates only three distinct components. Cluster0 improves severity but not counts. Cluster1 and mirror cluster2 each reduce all6 core D failures and1 W failure; each complete evaluated stencil retains1 unchanged outside D failure. Their original passing hard roles, full local geometry, complete outside moments and global point clearance pass. N warnings are recorded separately under the original global88.2022 maximum.

`combined-three-components-audit.json` reassembles the first interior3-point result with the two additional components:9 simultaneous points/275 core/188 outside, D32 to13, W14 to2, R/S0, N38 to41. This is an in-memory local mathematical result. The current 7785 mesh and all C++/native artifacts remain unchanged.

`remaining-ratio-mobility.json` maps the actual last ratio faces and all their vertex mobility reasons from current arrays; no old native IDs are borrowed from another topology.

The driver contains top-level execution. Other tools extract only the two pure helper AST definitions to avoid unintentionally launching it. Original scripts, optimizer outputs, backtrack rejections, measured elapsed times and source hashes are frozen in manifest.json. Python proposal timings are not a guarantee for a future native operator or the whole300 second product deadline.
