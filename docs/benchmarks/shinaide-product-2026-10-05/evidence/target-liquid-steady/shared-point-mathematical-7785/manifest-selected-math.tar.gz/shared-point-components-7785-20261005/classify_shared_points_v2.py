"""Bounded, read-only mobility census on actual 7785 D/W/R failures."""
from pathlib import Path
import sys,json,hashlib,time
from collections import defaultdict,Counter
from concurrent.futures import ProcessPoolExecutor
import numpy as np
HERE=Path(__file__).resolve().parent;AIR=HERE.parents[1]
N=AIR/".codex-tmp/shared-point-quality-7785-20261005"
sys.path[:0]=[str(N),str(N/"readers"),str(AIR/"src")]
import audit_shared_point_candidate as V
import audit_air_mesh_geometry as G
import air_cone_trace_probe as T
M=AIR.parent/"integration/.codex-tmp/cases/Shinaide_MeshAbort_CUA/Mesh"
E=AIR/".codex-tmp/installed-writer-cua-7785c33f"
MANIFEST=json.loads((E/"case-file-manifest.json").read_text())
MAX_CORE=256;MAX_OUTSIDE=256
def cfaces(g,c):return g.cell_faces[g.cell_offsets[c]:g.cell_offsets[c+1]]
def sha(p):return V.sha(p)
def scan(rank):
    started=time.monotonic();poly=M/f"processor{rank}/constant/polyMesh";g=G.Geometry(poly);t=T.read_trace(M,rank)
    bound={}
    for name in ["points","faces","owner","neighbour","boundary","faceZones","cellZones","pointZones"]:
        path=poly/name;rel="Mesh/"+str(path.relative_to(M));value=sha(path)
        assert value==MANIFEST[rel]["sha256"];bound[rel]=value
    for suffix in ["face-base.i32","cell-parent.i32","cell-native.i32","point-native.i32","manifest.json"]:
        path=M/f"conforming-written-rank{rank}-{suffix}";rel="Mesh/"+str(path.relative_to(M))
        value=sha(path);assert value==MANIFEST[rel]["sha256"];bound[rel]=value
    for suffix in ["zone.i32","manifest.json"]:
        path=M/f"conforming-source-rank{rank}-{suffix}";rel="Mesh/"+str(path.relative_to(M))
        value=sha(path);assert value==MANIFEST[rel]["sha256"];bound[rel]=value
    d=G.cell_set(poly/"sets/underdeterminedCells").tolist()
    w=G.cell_set(poly/"sets/lowWeightFaces").tolist();r=G.cell_set(poly/"sets/lowVolRatioFaces").tolist()
    for name in ["underdeterminedCells","lowWeightFaces","lowVolRatioFaces"]:
        path=poly/"sets"/name
        if path.exists():
            rel="Mesh/"+str(path.relative_to(M));bound[rel]=sha(path);assert bound[rel]==MANIFEST[rel]["sha256"]
    seeds=set(d)
    for f in w+r:
        seeds.add(int(g.owner[f]))
        if f<len(g.neighbour):seeds.add(int(g.neighbour[f]))
    pointids=sorted({int(p) for c in seeds for f in cfaces(g,c) for p in g.ids(int(f))})
    hits=np.flatnonzero(np.isin(g.vertices,np.asarray(pointids,dtype=np.int64)))
    fi=np.searchsorted(g.offsets[1:],hits,side="right");pointfaces=defaultdict(set)
    for p,f in zip(g.vertices[hits],fi):pointfaces[int(p)].add(int(f))
    sourceZone=np.full(g.n_faces,-1,dtype=np.int32);use=t["faceBase"]>=0;sourceZone[use]=t["zone"][t["faceBase"][use]]
    coupledmask=np.zeros(g.n_faces,dtype=bool);physicalmask=np.zeros(g.n_faces,dtype=bool)
    for first,count,name,kind in g.patches:
        if V.coupled({"type":kind}):coupledmask[first:first+count]=True
        else:physicalmask[first:first+count]=True
    arity=np.diff(g.offsets);rows=[];free={}
    for p in pointids:
        pf=np.asarray(sorted(pointfaces[p]),dtype=np.int64)
        core=set(map(int,g.owner[pf]))|set(int(g.neighbour[f]) for f in pf if f<len(g.neighbour))
        allcf=np.unique(np.concatenate([cfaces(g,c) for c in core]))
        outside=set(map(int,g.owner[allcf]))|set(int(g.neighbour[f]) for f in allcf if f<len(g.neighbour))
        outside-=core
        fullcf=np.unique(np.concatenate([cfaces(g,c) for c in core|outside]))
        reasons=[]
        if physicalmask[pf].any():reasons.append("physicalPoint")
        if coupledmask[pf].any():reasons.append("coupledPoint")
        if np.any(arity[pf]!=3):reasons.append("nonTriangularIncidentFace")
        if coupledmask[fullcf].any():reasons.append("touchedCoupledOwner")
        if np.any(sourceZone[fullcf]!=-1):reasons.append("touchedSourceZone")
        if len(core)>MAX_CORE or len(outside)>MAX_OUTSIDE:reasons.append("finiteStencilBudget")
        fixedaxes=set();flatphysical=True;patchnames=set()
        for f in pf[physicalmask[pf]]:
            xyz=g.points[g.ids(int(f))];exact=[a for a in range(3) if np.all(xyz[:,a]==xyz[0,a])]
            patchnames.add(g.patch(int(f))["name"])
            if len(exact)!=1:flatphysical=False
            else:fixedaxes.add(exact[0])
        # Tangential is a future route only; do not authorize it from this count.
        tangentialNecessary=bool(physicalmask[pf].any() and flatphysical and len(patchnames)==1 and len(fixedaxes)==1 and not coupledmask[fullcf].any() and np.all(sourceZone[fullcf]==-1))
        row={"point":p,"nativePoint":int(t["pointNative"][p]),"coordinates":g.points[p].tolist(),
             "incidentFaces":pf.tolist(),"coreCells":sorted(core),"outsideCells":sorted(outside),
             "reasons":reasons,"freeInternalTrianglePointEligible":not reasons,
             "flatSamePatchTangentialNecessaryOnly":tangentialNecessary,
             "physicalPatchNames":sorted(patchnames),"fixedPhysicalAxes":sorted(fixedaxes)}
        rows.append(row);free[p]=not reasons
    pointrows={r["point"]:r for r in rows}
    def seedrow(c):
        ps=sorted({int(p) for f in cfaces(g,c) for p in g.ids(int(f))})
        elig=[p for p in ps if free[p]]
        return {"cell":c,"sourceParent":int(t["cellParent"][c]),"points":ps,"eligiblePoints":elig,
                "arity":len(cfaces(g,c)),"vertices":len(ps),"nativeCell":int(t["cellNative"][c]),
                "pointRestrictionUnion":sorted({reason for p in ps for reason in pointrows[p]["reasons"]}),
                "hasTangentialNecessaryPoint":any(pointrows[p]["flatSamePatchTangentialNecessaryOnly"] for p in ps)}
    drows=[seedrow(c) for c in d]
    # Eligible points are connected if they occur in a hard-failure seed cell.
    adjacency={p:set() for p in pointids if free[p]}
    for c in seeds:
        ep=[p for p in seedrow(c)["eligiblePoints"]]
        for p in ep:adjacency[p].update(q for q in ep if p!=q)
    components=[];seen=set()
    for p in sorted(adjacency,key=lambda p:tuple(g.points[p])):
        if p in seen:continue
        queue=[p];seen.add(p);comp=[]
        while queue:
            a=queue.pop();comp.append(a)
            for b in adjacency[a]-seen:seen.add(b);queue.append(b)
        affectedD=[q["cell"] for q in drows if set(q["eligiblePoints"])&set(comp)]
        components.append({"points":sorted(comp),"pointCount":len(comp),"directOriginalDCells":affectedD,"directOriginalDCount":len(affectedD)})
    # A bounded 2/3-point stencil comes from a real poor cell; no global cluster enumeration.
    cluster={}
    for row in drows:
        ep=row["eligiblePoints"]
        if len(ep)<2:continue
        ordered=sorted(ep,key=lambda p:(-sum(p in z["eligiblePoints"] for z in drows),tuple(g.points[p])))
        pts=tuple(sorted(ordered[:3]));key=",".join(map(str,pts))
        core=set(c for p in pts for c in pointrows[p]["coreCells"])
        allcf=np.unique(np.concatenate([cfaces(g,c) for c in core]))
        outside=set(map(int,g.owner[allcf]))|set(int(g.neighbour[f]) for f in allcf if f<len(g.neighbour));outside-=core
        if len(core)>384 or len(outside)>384:continue
        direct=[z["cell"] for z in drows if set(z["eligiblePoints"])&set(pts)]
        cluster[key]={"points":list(pts),"coreCount":len(core),"outsideCount":len(outside),"directOriginalDCells":direct,"directOriginalDCount":len(direct),
                      "triggerCell":row["cell"]}
    result={"rank":rank,"mesh":str(M),"sourceBinarySHA256":bound,"badD":drows,"badWeightFaces":w,"badRatioFaces":r,
            "pointRows":rows,"eligibleComponents":components,"boundedJointClusters":sorted(cluster.values(),key=lambda c:(-c["directOriginalDCount"],c["coreCount"],c["points"])),
            "countD":len(d),"countW":len(w),"countR":len(r),"seedCells":len(seeds),"seedPoints":len(pointids),
            "freeEligiblePoints":sum(free.values()),"pointReasons":dict(Counter(a for row in rows for a in row["reasons"])),
            "DCellsByEligiblePointCount":dict(Counter(str(min(len(row["eligiblePoints"]),3)) for row in drows)),
            "DCellsWithTangentialNecessaryPoint":sum(row["hasTangentialNecessaryPoint"] for row in drows),
            "elapsedSeconds":time.monotonic()-started,"nativeAcceptance":False}
    (HERE/f"rank{rank}-mobility-bound.json").write_text(json.dumps(result,indent=2)+"\n")
    print(json.dumps({k:result[k] for k in ["rank","countD","countW","countR","seedPoints","freeEligiblePoints","pointReasons","DCellsByEligiblePointCount","DCellsWithTangentialNecessaryPoint","elapsedSeconds"]}),flush=True)
    return result
def main():
    start=time.monotonic()
    with ProcessPoolExecutor(max_workers=2) as ex:results=list(ex.map(scan,range(8)))
    total={"format":"actual7785-bounded-free-internal-point-mobility/v1","totalD":sum(r["countD"] for r in results),"totalW":sum(r["countW"] for r in results),"totalR":sum(r["countR"] for r in results),
           "freeEligiblePoints":sum(r["freeEligiblePoints"] for r in results),"DCellsByEligiblePointCount":dict(sum((Counter(r["DCellsByEligiblePointCount"]) for r in results),Counter())),
           "DCellsWithTangentialNecessaryPoint":sum(r["DCellsWithTangentialNecessaryPoint"] for r in results),
           "boundedClusterCount":sum(len(r["boundedJointClusters"]) for r in results),"rankSummary":[{k:r[k] for k in ["rank","countD","countW","countR","seedPoints","freeEligiblePoints","DCellsByEligiblePointCount","elapsedSeconds"]} for r in results],
           "earliestCaseManifestSHA256":sha(E/"case-file-manifest.json"),"toolSHA256":sha(__file__),"elapsedSeconds":time.monotonic()-start,
           "scope":"Eligibility/coverage only; no feasible-candidate claim. Points can cover overlapping bad cells. Tangential count is only a necessary support-plane screen; footprint/edge-interface/metric proof remains required.",
           "noMeshMutation":True,"nativeAcceptance":False}
    (HERE/"mobility-summary-bound.json").write_text(json.dumps(total,indent=2)+"\n");print(json.dumps(total,indent=2),flush=True)
if __name__=="__main__":main()
