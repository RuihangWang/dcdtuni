from pathlib import Path
import sys,json,copy,time,hashlib
import numpy as np
HERE=Path(__file__).resolve().parent;AIR=HERE.parents[1]
N=HERE.parent/"shared-point-quality-7785-20261005"
sys.path[:0]=[str(HERE),str(N),str(N/"readers"),str(AIR/"src")]
import joint_star_solver as S
import audit_shared_point_candidate as V
G,T=V.G,V.T
M=AIR.parent/"integration/.codex-tmp/cases/Shinaide_MeshAbort_CUA/Mesh"
E=AIR/".codex-tmp/installed-writer-cua-7785c33f"
def cf(g,c):return g.cell_faces[g.cell_offsets[c]:g.cell_offsets[c+1]]
def document(g,t,moving):
 hits=np.flatnonzero(np.isin(g.vertices,np.asarray(moving)))
 fs=np.unique(np.searchsorted(g.offsets[1:],hits,side="right"))
 core=set(map(int,g.owner[fs]))|set(int(g.neighbour[f]) for f in fs if f<len(g.neighbour))
 af=np.unique(np.concatenate([cf(g,c) for c in core]))
 outside=(set(map(int,g.owner[af]))|set(int(g.neighbour[f]) for f in af if f<len(g.neighbour)))-core
 allfaces=np.unique(np.concatenate([cf(g,c) for c in core|outside]))
 points={int(p) for f in allfaces for p in g.ids(int(f))}
 doc={"points":{str(p):g.points[p].tolist() for p in sorted(points)},"faces":{},"cells":{},
      "children":sorted(core),"outsideCells":sorted(outside),"apexWrittenPoint":moving[0],"originalApex":g.points[moving[0]].tolist()}
 for f0 in allfaces:
  f=int(f0);b=int(t["faceBase"][f]);doc["faces"][str(f)]={"owner":int(g.owner[f]),"neighbour":int(g.neighbour[f]) if f<len(g.neighbour) else None,
   "pointIDs":g.ids(f).tolist(),"patch":g.patch(f),"sourceBase":b,"sourceZone":int(t["zone"][b]) if b>=0 else -1,"nativeFace":int(t["faceNative"][f])}
 for c in sorted(core|outside):
  z=g.cell(c);doc["cells"][str(c)]={"faces":list(map(int,z[0])),"sourceParent":int(t["cellParent"][c]),"nativeCell":int(t["cellNative"][c]),
   "writtenCentre":z[3].tolist(),"writtenVolume":z[4]}
 return doc
start=time.monotonic();g=G.Geometry(M/"processor3/constant/polyMesh");t=T.read_trace(M,3)
selected=[[7800,569210],[23237,42335,569586],[23239,42338,569589]]
records=[]
for seq,moving in enumerate(selected):
 if time.monotonic()-start>60:break
 doc=document(g,t,moving);record={"rank":3,"movingPoints":moving,"oldDocument":doc}
 # Positive binding is checked before any solver work.
 _,_,binding=V.raw_binding(doc,moving,M,3,E/"case-file-manifest.json");record["actualSourceBinding"]=binding
 proposal=S.solve(doc,moving);record["proposal"]=proposal;backtracks=[]
 for runid,run in enumerate(proposal["runs"]):
  for fraction in [.999,.99,.95,.5,.25]:
   new=copy.deepcopy(doc)
   for p in moving:
    oldp=np.asarray(doc["points"][str(p)]);nextp=np.asarray(run["candidateDocument"]["points"][str(p)])
    new["points"][str(p)]=(oldp+fraction*(nextp-oldp)).tolist()
   new["originalApex"]=new["points"][str(new["apexWrittenPoint"])]
   q=V.authorize(doc,new,moving);q["globalRankPointClearance"]=V.global_gap(g,new,moving)
   if not all(x["exceedsWriter1MicrometreAnd3MicrometreSafety"] for x in q["globalRankPointClearance"]):q["mathematicalLocalCandidateAccepted"]=False
   backtracks.append({"run":runid,"fraction":fraction,"candidateDocument":new,"audit":q})
 record["backtracks"]=backtracks
 (HERE/f"cluster{seq}-joint-audit.json").write_text(json.dumps(record,indent=2)+"\n")
 summary=[{"run":r["run"],"fraction":r["fraction"],"accepted":r["audit"]["mathematicalLocalCandidateAccepted"],
           "oldCounts":r["audit"]["oldCounts"],"newCounts":r["audit"]["newCounts"],"Nmax":r["audit"]["maximumWarningDegrees"]} for r in backtracks]
 records.append({"sequence":seq,"movingPoints":moving,"coreCount":len(doc["children"]),"outsideCount":len(doc["outsideCells"]),"proposalSeconds":proposal["proposalElapsedSeconds"],"results":summary})
 print(json.dumps(records[-1]),flush=True)
out={"format":"bounded-three-different-component-joint-proposals/v1","records":records,"elapsedSeconds":time.monotonic()-start,
     "toolSHA256":V.sha(__file__),"solverSHA256":V.sha(HERE/"joint_star_solver.py"),"noMeshMutation":True,"nativeAcceptance":False}
(HERE/"bounded-joint-summary.json").write_text(json.dumps(out,indent=2)+"\n")
print(json.dumps({"elapsedSeconds":out["elapsedSeconds"],"components":len(records)}),flush=True)
