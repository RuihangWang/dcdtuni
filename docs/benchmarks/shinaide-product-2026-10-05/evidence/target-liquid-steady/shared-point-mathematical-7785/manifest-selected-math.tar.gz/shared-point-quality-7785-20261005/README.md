# Actual 7785 shared interior-point local mathematical audit

The frozen product mesh remains Failed3 (D909/W100/R2). No mesh, source, service, native process, solver, or git index was changed by this mathematical work. The original immutable case manifest is fd372838caccb455b42ed67fd7b2c17dca88b1711955cb4973738bd5feea5fb7.

Three rank3 internal written points 23651/569594/569592 are moved jointly in an in-memory complete stencil: 131 core cells, 101 complete outside cells, 340 affected faces, 608 stored faces. `joint-interior-backtracked.json` run1/fraction.999 reduces D18 to11 and W12 to2, while R/S stay zero. Original passing hard D/W/R/S roles do not fail; N warning label exchange is allowed, with affected maximum80.38193165 degrees below original global88.2022. The independent review distinguishes the608 stored-face maximum81.91739279 from the340 affected-face maximum.

All fixed points, cavity exterior ordered coordinates/roles, and101 outside CC/V DP representations remain exact. Global rank point clearance exceeds the original writer1 micrometre and3 micrometre safety distance. The local result still contains11 D and2 W failures; it is not native or whole-mesh acceptance.

`test_shared_point_candidate.py`:17 passing semantic regressions, including meaningful rejected proposals and complete actual-source binding. The original unexecuted warning-policy prototype is preserved, as are rejected optimizer endpoints. All test/log/source-reader hashes are in manifest.json. Independent Fraction/full-star proof lives in integration/.codex-tmp/shared-point-independent-7785-20261005 and is not modified here.
