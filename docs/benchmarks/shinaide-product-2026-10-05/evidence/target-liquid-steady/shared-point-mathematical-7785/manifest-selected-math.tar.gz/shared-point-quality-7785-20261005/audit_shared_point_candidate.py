"""Validate an internal shared-point proposal on a complete frozen mesh stencil.

The proposer is untrusted. This tool evaluates original polygon/cell formulas,
preserves every original passing hard role, and records N warnings separately.
It never changes a mesh, launches native code, or authorizes product acceptance.
"""
from pathlib import Path
import argparse, copy, hashlib, json, sys, time
import numpy as np
HERE=Path(__file__).resolve().parent
AIR=HERE.parents[1]
sys.path[:0]=[str(HERE/"readers"),str(AIR/"src")]
import audit_air_cone_small_union_independent as U
import audit_air_mesh_geometry as G
import air_cone_trace_probe as T
HARD=("D","weight","ratio","skew")

def sha(path):
    h=hashlib.sha256()
    with Path(path).open("rb") as f:
        for b in iter(lambda:f.read(8*1024*1024),b""):h.update(b)
    return h.hexdigest()

def same_dp(a,b):
    a=np.asarray(a,dtype="<f8");b=np.asarray(b,dtype="<f8")
    return bool(a.shape==b.shape and np.array_equal(a.view("<u8"),b.view("<u8")))

def coupled(patch):
    return bool(patch and any(x in patch["type"].lower() for x in ("processor","cyclic","ami","mapped")))

def validate_structure(old,new,moving):
    moving=set(map(int,moving))
    if not moving or len(moving)>12:raise ValueError("bounded nonempty moving-point set required")
    if any(old.get(k)!=new.get(k) for k in ("faces","cells","children","outsideCells","apexWrittenPoint")):
        raise ValueError("topology and all original cell/face roles must be unchanged")
    if set(old["points"])!=set(new["points"]):raise ValueError("point cardinality changed")
    if not all(np.isfinite(v).all() for v in map(np.asarray,new["points"].values())):
        raise ValueError("nonfinite coordinates")
    if not all(same_dp(v,new["points"][p]) for p,v in old["points"].items() if int(p) not in moving):
        raise ValueError("a nonmoving original coordinate changed")
    if not same_dp(new["originalApex"],new["points"][str(new["apexWrittenPoint"])]):
        raise ValueError("reader apex override does not match proposed point")
    incident={int(f) for f,row in old["faces"].items() if moving.intersection(row["pointIDs"])}
    core={old["faces"][str(f)]["owner"] for f in incident}
    core|={old["faces"][str(f)]["neighbour"] for f in incident if old["faces"][str(f)]["neighbour"] is not None}
    if core!=set(old["children"]):raise ValueError("incomplete entire moving-point cell star")
    af={f for c in core for f in old["cells"][str(c)]["faces"]}
    outside={old["faces"][str(f)]["owner"] for f in af}|{old["faces"][str(f)]["neighbour"] for f in af}
    outside.discard(None);outside-=core
    if outside!=set(old["outsideCells"]) or set(map(int,old["cells"]))!=core|outside:
        raise ValueError("incomplete outside neighbour stencil")
    for f in incident:
        r=old["faces"][str(f)]
        if r["patch"] is not None:raise ValueError("moving physical or coupled point is unsupported")
        if len(r["pointIDs"])!=3:raise ValueError("only triangular incident faces supported")
    for c in core|outside:
        for f in old["cells"][str(c)]["faces"]:
            row=old["faces"][str(f)]
            if row["sourceZone"]!=-1:raise ValueError("protected source zone in touched stencil")
            if coupled(row["patch"]):raise ValueError("unknown coupled state in touched stencil")
            if c not in (row["owner"],row["neighbour"]):raise ValueError("bad cell-face incidence")
    shell={f for f in af if (old["faces"][str(f)]["owner"] in core)!=(old["faces"][str(f)]["neighbour"] in core)}
    if any(moving.intersection(old["faces"][str(f)]["pointIDs"]) for f in shell):
        raise ValueError("moving point lies on cavity exterior")
    return {"incidentFaces":sorted(incident),"coreCells":sorted(core),"outsideCells":sorted(outside),"shellFaces":sorted(shell)}

def raw_binding(old,moving,mesh,rank,case_manifest):
    """Bind every stored coordinate, role and complete cell to actual arrays."""
    poly=Path(mesh)/f"processor{rank}/constant/polyMesh"
    manifest=json.loads(Path(case_manifest).read_text())
    g=G.Geometry(poly);t=T.read_trace(Path(mesh),rank)
    paths=[poly/name for name in ("points","faces","owner","neighbour","boundary","faceZones","cellZones","pointZones")]
    paths += list(Path(mesh).glob(f"conforming-*-rank{rank}-*"))
    hashes={}
    for path in paths:
        rel="Mesh/"+str(path.relative_to(mesh))
        if rel not in manifest:raise ValueError("actual source file absent from immutable original manifest")
        value=sha(path)
        if value!=manifest[rel]["sha256"]:raise ValueError("actual source hash mismatch")
        hashes[rel]=value
    hits=np.flatnonzero(np.isin(g.vertices,np.asarray(moving,dtype=np.int64)))
    fids=np.unique(np.searchsorted(g.offsets[1:],hits,side="right"))
    core={int(g.owner[f]) for f in fids}|{int(g.neighbour[f]) for f in fids if f<len(g.neighbour)}
    if core!=set(old["children"]):raise ValueError("actual binary full point star disagrees")
    for key,coord in old["points"].items():
        if not same_dp(g.points[int(key)],coord):raise ValueError("actual binary coordinate mismatch")
    for key,row in old["faces"].items():
        f=int(key);nei=int(g.neighbour[f]) if f<len(g.neighbour) else None
        if g.ids(f).tolist()!=row["pointIDs"] or int(g.owner[f])!=row["owner"] or nei!=row["neighbour"] or g.patch(f)!=row["patch"]:
            raise ValueError("actual binary face ring/role mismatch")
        base=int(t["faceBase"][f]);zone=int(t["zone"][base]) if base>=0 else -1
        if base!=row["sourceBase"] or zone!=row["sourceZone"] or int(t["faceNative"][f])!=row["nativeFace"]:
            raise ValueError("actual source face provenance mismatch")
    for key,row in old["cells"].items():
        c=int(key);data=g.cell(c)
        if list(map(int,data[0]))!=row["faces"] or int(t["cellParent"][c])!=row["sourceParent"] or int(t["cellNative"][c])!=row["nativeCell"]:
            raise ValueError("actual complete cell/parent mismatch")
        if not same_dp(data[3],row["writtenCentre"]) or not same_dp(data[4],row["writtenVolume"]):
            raise ValueError("actual original installed-formula cell moments mismatch")
    return g,t,{"rank":rank,"mesh":str(mesh),"caseManifestSHA256":sha(case_manifest),"boundFileSHA256":hashes,
                "binaryFullStarCount":len(core),"completeCellCount":len(old["cells"]),"pointCount":len(old["points"]),"faceCount":len(old["faces"]),
                "coordinateAndCompleteIncidenceDPExact":True}

def actual_metrics(doc):
    m,q=U.family_metrics(doc)
    q["cells"] += [m.cell_detail(c) for c in doc["outsideCells"]]
    return m,q

def authorize(old,new,moving,warning_ceiling=88.2022):
    scope=validate_structure(old,new,moving)
    om,oq=actual_metrics(old);nm,nq=actual_metrics(new)
    lin=U.lineage_pareto(oq,nq,[],None)
    hard=all(lin[k]["pass"] for k in HARD)
    L=float(np.ptp(np.asarray(list(old["points"].values())),axis=0).max())
    cell_geometry=all(np.isfinite([c["V"],c["minCentroidPyramidVolume"],c["maximumVertexOutsideM"],c["relativeClosure"]]).all()
        and c["V"]>0 and c["minCentroidPyramidVolume"]>0 and c["maximumVertexOutsideM"]<=1e-10*L and c["relativeClosure"]<=1e-10
        and c["faceCentreConcavityPairTriggers"]==0 and c["edgesExactlyTwo"] and c["edgesOppositeOrientation"] for c in nq["cells"])
    face_geometry=all(np.isfinite([f["planarityErrorM"],f["polygonMinimumSupportM"],f["minimumCentreFanTetQuality"],f["bestSharedBasePointMinimumTetQuality"]]).all()
        and f["planarityErrorM"]<=1e-10*L and f["polygonMinimumSupportM"]>=-1e-10*L
        and f["minimumCentreFanTetQuality"]>1e-15 and f["bestSharedBasePointMinimumTetQuality"]>1e-15 for f in nq["faces"])
    outside=[]
    for c in old["outsideCells"]:
        a,b=om.cell(c),nm.cell(c)
        outside.append({"cell":c,"CC_DP_exact":same_dp(a[2],b[2]),"V_DP_exact":same_dp(a[3],b[3])})
    warning=[f["nonOrthogonalityDegrees"] for f in nq["faces"] if "nonOrthogonalityDegrees" in f]
    warning_pass=bool(np.isfinite(warning).all() and max(warning,default=0)<=warning_ceiling)
    counts=lambda q:{k:sum(not np.isfinite(z[k]) or (z[k]>v if upper else z[k]<v) for z in q["cells" if k=="D" else "faces"] if k in z) for k,(v,upper) in U.LIMITS.items()}
    oldv=sum(om.cell(c)[3] for c in old["children"]);newv=sum(nm.cell(c)[3] for c in old["children"])
    oldm=sum((om.cell(c)[3]*om.cell(c)[2] for c in old["children"]),np.zeros(3))
    newm=sum((nm.cell(c)[3]*nm.cell(c)[2] for c in old["children"]),np.zeros(3))
    return {"mathematicalLocalCandidateAccepted":bool(hard and cell_geometry and face_geometry and warning_pass and all(r["CC_DP_exact"] and r["V_DP_exact"] for r in outside)),
            "nativeAcceptance":False,"hardOriginalPassingRoleGuard":hard,"cellGeometryGuard":bool(cell_geometry),"faceGeometryGuard":bool(face_geometry),
            "warningGlobalCeilingGuard":warning_pass,"warningLabelExchangeAllowed":True,"warningCeilingDegrees":warning_ceiling,
            "oldCounts":counts(oq),"newCounts":counts(nq),"maximumWarningDegrees":max(warning,default=0),
            "lineage":lin,"scope":scope,"outsideByteMoments":outside,"oldActualMetrics":oq,"newActualMetrics":nq,
            "sumVolumeRelativeDifference":abs(newv-oldv)/oldv,"sumFirstMomentDifferenceM4":float(np.linalg.norm(newm-oldm)),
            "unchangedShellOrderedWorldCoordinatesAndRoles":all(om.faces[f]==nm.faces[f] and all(same_dp(old["points"][str(p)],new["points"][str(p)]) for p in om.faces[f]["pointIDs"]) for f in scope["shellFaces"])}

def global_gap(g,new,moving):
    out=[]
    for p in moving:
        coord=np.asarray(new["points"][str(p)]);dif=np.abs(g.points-coord);dif[int(p)]=np.inf
        # Compare proposed coordinates of the other moving points, too.
        for q in moving:
            if p!=q:dif[int(q)]=np.abs(np.asarray(new["points"][str(q)])-coord)
        l2=np.linalg.norm(dif,axis=1);linf=dif.max(axis=1)
        a=int(np.argmin(l2));b=int(np.argmin(linf))
        out.append({"point":int(p),"minimumOtherPointL2M":float(l2[a]),"nearestL2Point":a,
            "minimumOtherPointLInfM":float(linf[b]),"nearestLInfPoint":b,"exceedsWriter1MicrometreAnd3MicrometreSafety":bool(linf[b]>3e-6)})
    return out

def main():
    ap=argparse.ArgumentParser();ap.add_argument("--input",type=Path,required=True);ap.add_argument("--output",type=Path,required=True)
    ap.add_argument("--run",type=int,default=1);ap.add_argument("--fraction",type=float,default=.999)
    ap.add_argument("--mesh",type=Path);ap.add_argument("--case-manifest",type=Path);ap.add_argument("--rank",type=int,default=3)
    args=ap.parse_args();start=time.monotonic()
    x=json.loads(args.input.read_text());r=next(r for r in x["results"] if r["run"]==args.run and r["backtrackFraction"]==args.fraction)
    old,new=x["oldDocument"],r["candidateDocument"];moving=x["movingPoints"]
    result=authorize(old,new,moving)
    if args.mesh:
        g,t,binding=raw_binding(old,moving,args.mesh,args.rank,args.case_manifest)
        result["actualBinaryBinding"]=binding;result["globalRankPointClearance"]=global_gap(g,new,moving)
        result["nativePointMapping"]=[{"writtenPoint":p,"nativePoint":int(t["pointNative"][p]),"oldCoordinates":old["points"][str(p)],
            "proposedCoordinates":new["points"][str(p)],"displacementM":(np.asarray(new["points"][str(p)])-old["points"][str(p)]).tolist()} for p in moving]
        if not all(p["exceedsWriter1MicrometreAnd3MicrometreSafety"] for p in result["globalRankPointClearance"]):
            result["mathematicalLocalCandidateAccepted"]=False
    result.update({"format":"shared-internal-point-original-formula-audit/v1","inputSHA256":sha(args.input),"toolSHA256":sha(__file__),
        "elapsedSeconds":time.monotonic()-start,"noMeshOrSourceMutation":True})
    args.output.write_text(json.dumps(result,indent=2)+"\n")
    print(json.dumps({k:v for k,v in result.items() if k not in ("oldActualMetrics","newActualMetrics","outsideByteMoments","lineage","actualBinaryBinding","scope")},indent=2))
if __name__=="__main__":main()
