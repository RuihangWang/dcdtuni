from pathlib import Path
import sys,json,time,copy,hashlib
from collections import defaultdict
import numpy as np
N=Path(__file__).resolve().parent;A=N.parents[1]
sys.path[:0]=[str(N/'readers'),str(A/'src')]
import audit_air_mesh_geometry as G
import audit_air_cone_small_union_independent as U
import air_cone_trace_probe as T
M=A.parent/'integration/.codex-tmp/cases/Shinaide_MeshAbort_CUA/Mesh'
E=A/'.codex-tmp/installed-writer-cua-7785c33f'
old=json.loads((E/'case-file-manifest.json').read_text())
seeds=[(1,511185),(3,528947),(3,528941)]
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
 return h.hexdigest()
def coupled(p):return bool(p and any(v in p['type'].lower() for v in ['processor','cyclic','ami','mapped']))
def zone(t,f):
 b=int(t['faceBase'][f]);return int(t['zone'][b]) if b>=0 else -1
cache={};rows=[]
for rank,seed in seeds:
 if rank not in cache:
  t=T.read_trace(M,rank);g=G.Geometry(M/f'processor{rank}/constant/polyMesh')
  for name in ['points','faces','owner','neighbour','boundary']:
   rel=f'Mesh/processor{rank}/constant/polyMesh/{name}'
   assert sha(M/f'processor{rank}/constant/polyMesh/{name}')==old[rel]['sha256']
  cache[rank]=(t,g)
 t,g=cache[rank];sf=g.cell(seed)[0];ps=sorted({int(p) for f in sf for p in g.ids(int(f))})
 at=np.flatnonzero(np.isin(g.vertices,np.asarray(ps)))
 fids=np.searchsorted(g.offsets[1:],at,side='right');pf=defaultdict(set)
 for k,f in zip(at,fids):pf[int(g.vertices[k])].add(int(f))
 for p in ps:
  if any(x['rank']==rank and x['point']==p for x in rows):continue
  incident=sorted(pf[p]);core=sorted({int(g.owner[f]) for f in incident}|{int(g.neighbour[f]) for f in incident if f<len(g.neighbour)})
  fs=sorted({int(f) for c in core for f in g.cell(c)[0]})
  touched=set(core)
  for f in fs:
   touched.add(int(g.owner[f]))
   if f<len(g.neighbour):touched.add(int(g.neighbour[f]))
  allfaces=sorted({int(f) for c in touched for f in g.cell(c)[0]})
  points=sorted({int(q) for f in allfaces for q in g.ids(f)})
  physical=[f for f in incident if g.patch(f) and not coupled(g.patch(f))]
  fixedaxes=set();unsupported=[]
  for f in physical:
   xyz=g.points[g.ids(f)];exact=[a for a in range(3) if np.all(xyz[:,a]==xyz[0,a])]
   if len(exact)!=1:unsupported.append({'face':f,'reason':'notExactAxisPhysicalSupport'})
   else:fixedaxes.add(exact[0])
  doc={'points':{str(q):g.points[q].tolist() for q in points},'faces':{},'cells':{},
   'children':core,'outsideCells':sorted(touched-set(core)),'apexWrittenPoint':p,'originalApex':g.points[p].tolist()}
  for f in allfaces:
   doc['faces'][str(f)]={'owner':int(g.owner[f]),'neighbour':int(g.neighbour[f]) if f<len(g.neighbour) else None,
   'pointIDs':g.ids(f).tolist(),'patch':g.patch(f),'sourceBase':int(t['faceBase'][f]),'sourceZone':zone(t,f),'nativeFace':int(t['faceNative'][f])}
  for c in sorted(touched):
   fs0,sf0,fc0,cc,v,*_=g.cell(c)
   doc['cells'][str(c)]={'faces':list(map(int,fs0)),'sourceParent':int(t['cellParent'][c]),'nativeCell':int(t['cellNative'][c]),
   'writtenCentre':cc.tolist(),'writtenVolume':v}
  row={'rank':rank,'seedCell':seed,'point':p,'originalPoint':g.points[p].tolist(),'incidentFaceIDs':incident,'coreCells':core,
  'outsideCells':doc['outsideCells'],'hasTouchedCoupledOwner':any(coupled(g.patch(int(f))) for c in touched for f in g.cell(c)[0]),
  'hasTouchedSourceZone':any(zone(t,int(f))!=-1 for c in touched for f in g.cell(c)[0]),
  'allIncidentFacesTriangular':all(len(g.ids(f))==3 for f in incident),'physicalFaces':physical,
  'physicalPatchNames':sorted({g.patch(f)['name'] for f in physical}),'fixedCoordinateAxes':sorted(fixedaxes),
  'unsupportedPhysicalFaces':unsupported,'degreesBeforeBCInterfaceConstraints':3-len(fixedaxes),'doc':doc}
  rows.append(row)
out={'format':'actual-7785-full-point-star-input/v1','mesh':str(M),'seedCells':seeds,'rows':rows,
 'originalCaseManifestSHA256':sha(E/'case-file-manifest.json'),'toolSHA256':sha(Path(__file__)),'noActualMeshMutation':True}
(N/'pointstars.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps([{k:v for k,v in r.items() if k!='doc'} for r in rows],indent=2))
