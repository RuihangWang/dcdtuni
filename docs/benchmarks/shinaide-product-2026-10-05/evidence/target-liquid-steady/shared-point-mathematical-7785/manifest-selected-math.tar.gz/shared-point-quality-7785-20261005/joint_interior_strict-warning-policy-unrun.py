from pathlib import Path
import sys,json,copy,time,hashlib
import numpy as np
from scipy.optimize import minimize
N=Path(__file__).resolve().parent;A=N.parents[1]
sys.path[:0]=[str(N/'readers'),str(A/'src')]
import audit_air_cone_small_union_independent as U
rows=json.loads((N/'pointstars.json').read_text())['rows']
chosen=[next(r for r in rows if r['rank']==3 and r['point']==p) for p in [23651,569594,569592]]
assert all(not r['hasTouchedCoupledOwner'] and not r['hasTouchedSourceZone'] and not r['physicalFaces'] and r['allIncidentFacesTriangular'] for r in chosen)
doc=copy.deepcopy(chosen[0]['doc']);doc['points']={};doc['faces']={};doc['cells']={}
for r in chosen:
 for field in ['points','faces','cells']:
  for k,v in r['doc'][field].items():
   assert k not in doc[field] or doc[field][k]==v
   doc[field][k]=v
doc['children']=sorted(set(c for r in chosen for c in r['doc']['children']))
doc['outsideCells']=sorted(set(map(int,doc['cells']))-set(doc['children']))
doc['apexWrittenPoint']=chosen[0]['point'];doc['originalApex']=doc['points'][str(doc['apexWrittenPoint'])]
m,old=U.family_metrics(doc);old['cells']+=[m.cell_detail(c) for c in doc['outsideCells']]
pids=sorted(m.points);pindex={p:i for i,p in enumerate(pids)};xyz0=np.array([m.points[p] for p in pids])
fids=sorted(m.faces);fi={f:i for i,f in enumerate(fids)};cids=sorted(m.cells);ci={c:i for i,c in enumerate(cids)}
sf0=np.array([m.face(f)[0] for f in fids]);fc0=np.array([m.face(f)[1] for f in fids])
moveids=[pindex[r['point']] for r in chosen];initial=xyz0[moveids].copy();L=np.ptp(xyz0,axis=0).max()
changed=[fi[f] for f in fids if any(p in m.faces[f]['pointIDs'] for p in [r['point'] for r in chosen])]
assert all(len(m.faces[fids[i]]['pointIDs'])==3 for i in changed)
tri=np.array([[pindex[p] for p in m.faces[fids[i]]['pointIDs']] for i in changed])
ec=[];ef=[];es=[];selected=[]
for c in cids:
 for f in m.cells[c]['faces']:
  ec.append(ci[c]);ef.append(fi[f]);es.append(1 if m.faces[f]['owner']==c else -1)
  selected.append(m.faces[f]['patch'] is None)
ec=np.array(ec);ef=np.array(ef);es=np.array(es);sel=np.array(selected);nC=len(cids)
num=np.bincount(ec,minlength=nC)
af=np.array([fi[f] for f in fids if m.faces[f]['owner'] in doc['children'] or m.faces[f]['neighbour'] in doc['children']])
own=np.array([ci[m.faces[fids[f]]['owner']] for f in af])
nei=np.array([ci.get(m.faces[fids[f]]['neighbour'],-1) for f in af]);internal=nei>=0
avf=[];avp=[]
for a,j in enumerate(af):
 for p in m.faces[fids[j]]['pointIDs']:avf.append(a);avp.append(pindex[p])
avf=np.array(avf);avp=np.array(avp);core=np.array([ci[c] for c in doc['children']])
def fast(q):
 xyz=xyz0.copy();xyz[moveids]=initial+np.asarray(q[:9]).reshape(3,3)*L
 sf=sf0.copy();fc=fc0.copy();tp=xyz[tri]
 sf[changed]=.5*np.cross(tp[:,1]-tp[:,0],tp[:,2]-tp[:,0]);fc[changed]=tp.mean(axis=1)
 est=np.column_stack([np.bincount(ec,weights=fc[ef,k],minlength=nC)/num for k in range(3)])
 pv=np.einsum('ij,ij->i',sf[ef]*es[:,None],fc[ef]-est[ec])
 vp=np.bincount(ec,weights=pv,minlength=nC);vol=vp/3
 cc=np.column_stack([np.bincount(ec,weights=pv*(.75*fc[ef,k]+.25*est[ec,k]),minlength=nC)/vp for k in range(3)])
 ss=sf[ef[sel]];scc=ec[sel];norm=np.linalg.norm(ss,axis=1);cnt=np.bincount(scc,minlength=nC)
 avg=np.bincount(scc,weights=norm,minlength=nC)/np.maximum(cnt,1)
 tensor=np.array([np.bincount(scc,weights=ss[:,i]*ss[:,j],minlength=nC) for i in range(3) for j in range(3)]).T.reshape(nC,3,3)
 det=np.abs(np.linalg.det(tensor))/(8*np.maximum(avg,1e-150)**6)
 area=sf[af];fcaf=fc[af];normal=area/np.linalg.norm(area,axis=1)[:,None];co=cc[own];cn=cc[np.maximum(nei,0)]
 d=cn-co;d[~internal]=normal[~internal]*np.einsum('ij,ij->i',normal[~internal],fcaf[~internal]-co[~internal])[:,None]
 cpf=fcaf-co;doo=np.abs(np.einsum('ij,ij->i',area,cpf));dnn=np.abs(np.einsum('ij,ij->i',area,cn-fcaf))
 w=np.minimum(doo,dnn)/(doo+dnn+1e-300);w[~internal]=1
 r=np.minimum(vol[own],vol[np.maximum(nei,0)])/(np.maximum(vol[own],vol[np.maximum(nei,0)])+1e-300);r[~internal]=1
 n=np.degrees(np.arccos(np.clip(np.einsum('ij,ij->i',normal,d)/np.maximum(np.linalg.norm(d,axis=1),1e-150),-1,1)));n[~internal]=0
 sv=cpf-(np.einsum('ij,ij->i',area,cpf)/(np.einsum('ij,ij->i',area,d)+1e-150))[:,None]*d
 svmag=np.linalg.norm(sv,axis=1);svhat=sv/np.maximum(svmag[:,None],1e-150)
 fd=np.where(internal,.2,.4)*np.linalg.norm(d,axis=1)+1e-150
 np.maximum.at(fd,avf,np.abs(np.einsum('ij,ij->i',xyz[avp]-fcaf[avf],svhat[avf])))
 s=svmag/fd
 return det,w,r,s,n,vol,xyz
q0=np.zeros(10);q0[9]=min(fast(q0)[0][core])/.001
base=fast(q0);arrays=[base[0][core],base[1],base[2],base[3],base[4]]
lim=[.001,.05,.01,4,70];higher=[False,False,False,True,True]
beforeRows=[old['cells'],old['faces'],old['faces'],old['faces'],old['faces']]
def constraints(q):
 D,W,R,S,Nn,V,xyz=fast(q)
 vals=[D[core],W,R,S,Nn];out=[]
 for v,b,l,upper in zip(vals,arrays,lim,higher):
  if upper:
   bound=np.where(b<=l,l,max(l,float(b.max())));out.extend((bound-v)/l)
  else:
   bound=np.where(b>=l,l,min(l,float(b.min())));out.extend((v-bound)/l)
 out.extend((D[core]-.001*q[9])/.001)
 out.extend((V[core]-.00001*base[5][core])/np.maximum(base[5][core],1e-150))
 return np.asarray(out)
def actual(q):
 cand=copy.deepcopy(doc);pts=fast(q)[6]
 for idx,p in zip(moveids,[r['point'] for r in chosen]):cand['points'][str(p)]=pts[idx].tolist()
 cand['originalApex']=cand['points'][str(cand['apexWrittenPoint'])]
 mm,qq=U.family_metrics(cand);qq['cells']+=[mm.cell_detail(c) for c in cand['outsideCells']]
 lineage=U.lineage_pareto(old,qq,[],None)
 return cand,qq,lineage
start=time.monotonic()
lp=json.loads((N/'interior-relaxation.json').read_text())['rows']
seed=q0.copy()
for i,p in enumerate([23651,569594]):
 row=next(x for x in lp if x['point']==p)
 fraction=.25 if p==23651 else .1
 seed[i*3:i*3+3]=(np.asarray(row['LPpoint'])-initial[i])*fraction/L
seed[9]=min(fast(seed)[0][core])/.001
runs=[]
for x in [q0,seed]:
 opt=minimize(lambda q:-q[9]+1e-5*np.dot(q[:9],q[:9]),x,method='SLSQP',bounds=[(-.5,.5)]*9+[(0,2)],
 constraints=[{'type':'ineq','fun':constraints}],options={'maxiter':100,'ftol':1e-8})
 cand,quality,lineage=actual(opt.x)
 report={'success':bool(opt.success),'message':str(opt.message),'iterations':int(opt.nit),'fun':float(opt.fun),
 'minimumProposalConstraint':float(constraints(opt.x).min()),'parameters':opt.x.tolist(),'candidateDocument':cand,'actualMetrics':quality,'lineage':lineage,
 'counts':{k:sum(not np.isfinite(z[k]) or (z[k]>v if up else z[k]<v) for z in quality['cells' if k=='D' else 'faces'] if k in z) for k,(v,up) in U.LIMITS.items()}}
 runs.append(report)
 print(json.dumps({k:v for k,v in report.items() if k not in ['candidateDocument','actualMetrics','lineage']})+' actualLineagePass='+str(all(v['pass'] for v in lineage.values())),flush=True)
result={'format':'actual7785-joint-internal-point-relaxation-proposal/v1','movingPoints':[r['point'] for r in chosen],
 'oldDocument':doc,'oldActualMetrics':old,'coreCount':len(doc['children']),'outsideCount':len(doc['outsideCells']),
 'elapsedSeconds':time.monotonic()-start,'runs':runs,'toolSHA256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
 'proposalFormulaOnly':'Vectorized arithmetic proposes coordinates; actual original-formula stencil/geometry must authorize any positive. No native/mesh writes.'}
(N/'joint-internal-relaxation.json').write_text(json.dumps(result,indent=2)+'\n')
