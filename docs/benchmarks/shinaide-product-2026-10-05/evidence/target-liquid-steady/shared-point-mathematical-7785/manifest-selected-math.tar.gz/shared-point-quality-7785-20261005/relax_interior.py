from pathlib import Path
import sys,json,time,copy,hashlib
import numpy as np
from scipy.optimize import linprog
N=Path(__file__).resolve().parent;A=N.parents[1]
sys.path[:0]=[str(N/'readers'),str(A/'src')]
import audit_air_cone_small_union_independent as U
raw=json.loads((N/'pointstars.json').read_text())
out=[]
def evaluate(doc):
 m,q=U.family_metrics(doc)
 q['cells']+= [m.cell_detail(c) for c in doc['outsideCells']]
 return m,q
def counts(q):
 return {name:sum((x[name]>lim if upper else x[name]<lim) or not np.isfinite(x[name])
 for x in q['cells' if name=='D' else 'faces'] if name in x) for name,(lim,upper) in U.LIMITS.items()}
def five(q,core):
 cs=[x for x in q['cells'] if x['cell'] in core]
 return {'Dmin':min(x['D'] for x in cs),'Wmin':min(x.get('weight',1.) for x in q['faces']),
 'Rmin':min(x.get('ratio',1.) for x in q['faces']),'Smax':max(x['skew'] for x in q['faces']),
 'Nmax':max(x.get('nonOrthogonalityDegrees',0.) for x in q['faces'])}
for row in raw['rows']:
 if row['physicalFaces'] or not row['allIncidentFacesTriangular'] or row['hasTouchedCoupledOwner'] or row['hasTouchedSourceZone']:continue
 doc=row['doc'];p=row['point'];x0=np.asarray(row['originalPoint']);m,old=evaluate(doc)
 xyz=np.array([v for k,v in doc['points'].items()]);L=float(np.max(np.ptp(xyz,axis=0)))
 opp=[]
 for c in doc['children']:
  for f in m.cells[c]['faces']:
   r=m.faces[f]
   if p in r['pointIDs']:continue
   sf,fc=m.face(f);sf=sf if r['owner']==c else -sf;n=sf/np.linalg.norm(sf)
   opp.append((f,c,n,fc))
 coeff=np.array([np.r_[n*L,L] for f,c,n,fc in opp]);b=np.array([-np.dot(n,x0-fc) for f,c,n,fc in opp])
 bounds=[((xyz[:,a].min()-x0[a])/L,(xyz[:,a].max()-x0[a])/L) for a in range(3)]+[(0,None)]
 lp=linprog([0,0,0,-1],A_ub=coeff,b_ub=b,bounds=bounds,method='highs')
 record={k:v for k,v in row.items() if k!='doc'}
 record.update(oldFive=five(old,doc['children']),oldCounts=counts(old),oldDocument=doc,oppositePlaneCount=len(opp),
 oldActualMetrics=old,LPsuccess=bool(lp.success),LPradius=float(lp.x[3]*L) if lp.success else None,
 LPpoint=(x0+lp.x[:3]*L).tolist() if lp.success else None,candidates=[])
 if lp.success:
  for fraction in [.1,.25,.5,.75,1.]:
   x=x0+fraction*lp.x[:3]*L;cand=copy.deepcopy(doc);cand['points'][str(p)]=x.tolist();cand['originalApex']=x.tolist()
   cm,new=evaluate(cand);lineage=U.lineage_pareto(old,new,[],None)
   geom=all(z['V']>0 and z['faceCentreConcavityPairTriggers']==0 and z['edgesExactlyTwo'] and z['edgesOppositeOrientation']
    and z['minCentroidPyramidVolume']>0 and z['maximumVertexOutsideM']<=1e-10*L and z['relativeClosure']<1e-10 for z in new['cells'])
   geom &= all(z['minimumCentreFanTetQuality']>0 and z['bestSharedBasePointMinimumTetQuality']>0 and z['planarityErrorM']<1e-10*L and z['polygonMinimumSupportM']>=-1e-10*L for z in new['faces'])
   v0=sum(z['V'] for z in old['cells'] if z['cell'] in doc['children']);v1=sum(z['V'] for z in new['cells'] if z['cell'] in doc['children'])
   m0=sum((z['V']*np.asarray(z['CC']) for z in old['cells'] if z['cell'] in doc['children']),np.zeros(3))
   m1=sum((z['V']*np.asarray(z['CC']) for z in new['cells'] if z['cell'] in doc['children']),np.zeros(3))
   passes=geom and all(z['pass'] for z in lineage.values())
   record['candidates'].append({'fraction':fraction,'point':x.tolist(),'geometryPass':bool(geom),
   'lineagePass':all(z['pass'] for z in lineage.values()),'candidateFive':five(new,doc['children']),
   'candidateCounts':counts(new),'lineage':lineage,'sumVolumeRelativeError':abs(v1-v0)/v0,
   'firstMomentDifferenceM4':float(np.linalg.norm(m1-m0)),'candidateActualMetrics':new,'candidateDocument':cand,
   'qualifiedLocalImprovement':bool(passes and (counts(new)!=counts(old) or five(new,doc['children'])['Dmin']>five(old,doc['children'])['Dmin']))})
 out.append(record)
 report={k:v for k,v in record.items() if k not in ['oldDocument','oldActualMetrics','candidates','incidentFaceIDs','coreCells','outsideCells']}
 report['coreCellCount']=len(doc['children'])
 report['candidates']=[{k:v for k,v in x.items() if k not in ['candidateActualMetrics','candidateDocument','lineage']} for x in record['candidates']]
 print(json.dumps(report),flush=True)
(N/'interior-relaxation.json').write_text(json.dumps({'format':'actual7785-interior-star-relaxation/v1','rows':out,
 'toolSHA256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'noMeshWrite':True,'noNativeAcceptance':True},indent=2)+'\n')
