"""Semantic regressions on the actual 7785 frozen point-star proposal."""
from pathlib import Path
import copy,json,sys
import numpy as np
import pytest
N=Path(__file__).resolve().parent
sys.path.insert(0,str(N))
import audit_shared_point_candidate as A

@pytest.fixture(scope="module")
def f():
    return json.loads((N/"candidate-fixture.json").read_text())

@pytest.fixture(scope="module")
def positive(f):
    return A.authorize(f["oldDocument"],f["candidateDocument"],f["movingPoints"])

def test_original_has_hard_defects(positive):
    assert positive["oldCounts"]["D"]==18 and positive["oldCounts"]["weight"]==12
    assert positive["newCounts"]["D"]==11 and positive["newCounts"]["weight"]==2
    assert positive["newCounts"]["ratio"]==0 and positive["newCounts"]["skew"]==0

def test_joint_candidate_preserves_all_original_hard_passing_roles(positive):
    assert positive["mathematicalLocalCandidateAccepted"]
    assert all(not positive["lineage"][k]["originalPassingRoleFailures"] for k in A.HARD)
    assert positive["cellGeometryGuard"] and positive["faceGeometryGuard"]
    assert not positive["nativeAcceptance"]

def test_warning_label_exchange_is_recorded_and_not_a_hard_failure(positive):
    n=positive["lineage"]["nonOrthogonalityDegrees"]
    assert n["originalPassingRoleFailures"]  # Honest exchanged warning labels.
    assert not n["pass"]
    assert positive["newCounts"]["nonOrthogonalityDegrees"]==14
    assert positive["maximumWarningDegrees"]<=88.2022
    assert positive["warningGlobalCeilingGuard"] and positive["mathematicalLocalCandidateAccepted"]

def test_warning_global_ceiling_is_enforced(f):
    r=A.authorize(f["oldDocument"],f["candidateDocument"],f["movingPoints"],warning_ceiling=80.)
    assert not r["warningGlobalCeilingGuard"] and not r["mathematicalLocalCandidateAccepted"]

def test_unbacktracked_float_threshold_crossing_is_rejected(f):
    r=A.authorize(f["oldDocument"],f["unbacktrackedCandidateDocument"],f["movingPoints"])
    defects=r["lineage"]["D"]["originalPassingRoleFailures"]
    assert defects and any(d["value"]<.001 for d in defects)
    assert not r["hardOriginalPassingRoleGuard"] and not r["mathematicalLocalCandidateAccepted"]

def test_complete_outside_installed_formula_moments_are_dp_exact(positive):
    assert len(positive["outsideByteMoments"])==101
    assert all(r["CC_DP_exact"] and r["V_DP_exact"] for r in positive["outsideByteMoments"])
    assert positive["unchangedShellOrderedWorldCoordinatesAndRoles"]
    assert positive["sumVolumeRelativeDifference"]<1e-10
    assert positive["sumFirstMomentDifferenceM4"]<1e-10

def test_nonmoving_physical_coordinate_change_is_rejected(f):
    c=copy.deepcopy(f["candidateDocument"])
    physical=next(r for r in c["faces"].values() if r["patch"] is not None)
    point=physical["pointIDs"][0]
    assert point not in f["movingPoints"]
    c["points"][str(point)][0]=float(np.nextafter(c["points"][str(point)][0],np.inf))
    with pytest.raises(ValueError,match="nonmoving"):A.validate_structure(f["oldDocument"],c,f["movingPoints"])

def test_face_role_or_point_zero_change_is_rejected(f):
    c=copy.deepcopy(f["candidateDocument"])
    r=next(iter(c["faces"].values()));r["pointIDs"]=r["pointIDs"][1:]+r["pointIDs"][:1]
    with pytest.raises(ValueError,match="roles"):A.validate_structure(f["oldDocument"],c,f["movingPoints"])

def test_nonfinite_candidate_is_rejected(f):
    c=copy.deepcopy(f["candidateDocument"]);c["points"][str(f["movingPoints"][1])][1]=float("nan")
    with pytest.raises(ValueError,match="nonfinite"):A.validate_structure(f["oldDocument"],c,f["movingPoints"])

def test_complete_moving_point_star_is_required(f):
    old=copy.deepcopy(f["oldDocument"]);c=copy.deepcopy(f["candidateDocument"])
    removed=old["children"].pop();c["children"].remove(removed)
    with pytest.raises(ValueError,match="entire moving"):A.validate_structure(old,c,f["movingPoints"])

def test_unknown_coupled_face_refuses_full_stencil(f):
    old=copy.deepcopy(f["oldDocument"]);c=copy.deepcopy(f["candidateDocument"])
    face=next(r for r in old["faces"].values() if r["patch"] is not None)
    key=next(k for k,r in old["faces"].items() if r is face)
    old["faces"][key]["patch"]={"name":"unknown_proc","type":"processor"}
    c["faces"][key]["patch"]=copy.deepcopy(old["faces"][key]["patch"])
    with pytest.raises(ValueError,match="unknown coupled"):A.validate_structure(old,c,f["movingPoints"])

def test_protected_source_zone_refuses_full_stencil(f):
    old=copy.deepcopy(f["oldDocument"]);c=copy.deepcopy(f["candidateDocument"])
    key=next(iter(old["faces"]))
    old["faces"][key]["sourceZone"]=2;c["faces"][key]["sourceZone"]=2
    with pytest.raises(ValueError,match="protected source zone"):A.validate_structure(old,c,f["movingPoints"])

def test_stale_reader_apex_override_is_rejected(f):
    c=copy.deepcopy(f["candidateDocument"]);c["originalApex"]=f["oldDocument"]["originalApex"]
    with pytest.raises(ValueError,match="apex override"):A.validate_structure(f["oldDocument"],c,f["movingPoints"])

def test_dp_equality_preserves_sign_of_zero_and_rejects_nan():
    assert not A.same_dp([0.],[-0.])
    assert not A.same_dp([float("nan")],[0.])

def test_global_clearance_accounts_for_other_proposed_points():
    class Fake:points=np.array([[0.,0.,0.],[1.,0.,0.],[2.,0.,0.]])
    candidate={"points":{"0":[.5,0.,0.],"1":[.5+2e-7,0.,0.]}}
    rows=A.global_gap(Fake(),candidate,[0,1])
    assert all(not r["exceedsWriter1MicrometreAnd3MicrometreSafety"] for r in rows)

def test_actual_binary_full_star_and_provenance_binding(f):
    _,_,b=A.raw_binding(f["oldDocument"],f["movingPoints"],Path(f["sourceMesh"]),f["rank"],Path(f["caseManifest"]))
    assert b["coordinateAndCompleteIncidenceDPExact"] and b["binaryFullStarCount"]==131
    assert b["completeCellCount"]==232 and len(b["boundFileSHA256"])>=8

def test_partial_actual_point_star_refuses_even_if_metadata_is_tampered(f):
    old=copy.deepcopy(f["oldDocument"]);old["children"].pop()
    with pytest.raises(ValueError,match="binary full point star"):
        A.raw_binding(old,f["movingPoints"],Path(f["sourceMesh"]),f["rank"],Path(f["caseManifest"]))
