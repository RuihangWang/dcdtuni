from pathlib import Path
import sys,json,copy,hashlib
from fractions import Fraction as F
from collections import Counter
import numpy as np
N=Path(__file__).resolve().parent;A=N.parents[1]
sys.path[:0]=[str(N/'readers'),str(A/'src')]
import audit_air_cone_small_union_independent as U
d=json.loads((N/'joint-internal-relaxation.json').read_text())
old=d['oldDocument'];om,oq=U.family_metrics(old);oq['cells']+=[om.cell_detail(c) for c in old['outsideCells']]
core=set(old['children']);moving=d['movingPoints'];L=float(np.ptp(np.array(list(old['points'].values())),axis=0).max())
def counts(q):
 return {k:sum(not np.isfinite(z[k]) or (z[k]>v if up else z[k]<v) for z in q['cells' if k=='D' else 'faces'] if k in z) for k,(v,up) in U.LIMITS.items()}
shell=[f for f,r in om.faces.items() if ((r['owner'] in core)!=(r['neighbour'] in core))]
assert all(not set(om.faces[f]['pointIDs'])&set(moving) for f in shell)
results=[]
for runid,run in enumerate(d['runs']):
 for fraction in [.999,.99,.95]:
  cand=copy.deepcopy(old)
  for p in moving:
   x=np.array(old['points'][str(p)]);y=np.array(run['candidateDocument']['points'][str(p)])
   cand['points'][str(p)]=(x+fraction*(y-x)).tolist()
  cand['originalApex']=cand['points'][str(cand['apexWrittenPoint'])]
  mm,qq=U.family_metrics(cand);qq['cells']+=[mm.cell_detail(c) for c in cand['outsideCells']]
  lin=U.lineage_pareto(oq,qq,[],None);hard=all(lin[k]['pass'] for k in ['D','weight','ratio','skew'])
  geometry=all(z['V']>0 and z['minCentroidPyramidVolume']>0 and z['faceCentreConcavityPairTriggers']==0 and z['edgesExactlyTwo'] and z['edgesOppositeOrientation']
  and z['maximumVertexOutsideM']<=1e-10*L and z['relativeClosure']<=1e-10 for z in qq['cells'])
  geometry &= all(z['planarityErrorM']<=1e-10*L and z['polygonMinimumSupportM']>=-1e-10*L
   and z['minimumCentreFanTetQuality']>0 and z['bestSharedBasePointMinimumTetQuality']>0 for z in qq['faces'])
  unchangedOutside=[]
  for c in cand['outsideCells']:
   oc=om.cell(c);nc=mm.cell(c)
   unchangedOutside.append({'cell':c,'CC_DP_exact':bool(np.array_equal(oc[2].view(np.uint64),nc[2].view(np.uint64))),
   'V_DP_exact':bool(np.array_equal(np.asarray(oc[3]).view(np.uint64),np.asarray(nc[3]).view(np.uint64)))})
  oldv=sum(z['V'] for z in oq['cells'] if z['cell'] in core);newv=sum(z['V'] for z in qq['cells'] if z['cell'] in core)
  oldM=sum((z['V']*np.array(z['CC']) for z in oq['cells'] if z['cell'] in core),np.zeros(3))
  newM=sum((z['V']*np.array(z['CC']) for z in qq['cells'] if z['cell'] in core),np.zeros(3))
  nm=max(z.get('nonOrthogonalityDegrees',0) for z in qq['faces'])
  record={'run':runid,'backtrackFraction':fraction,'hardRolePass':hard,'geometryPass':bool(geometry),'warningCeilingPass':nm<=88.2022,
   'oldCounts':counts(oq),'newCounts':counts(qq),'maximumNonOrthogonalityDegrees':nm,'lineage':lin,'candidateDocument':cand,'actualMetrics':qq,
   'allShellOrderedCoordinatesAndRolesExact':all(om.faces[f]==mm.faces[f] and all(old['points'][str(p)]==cand['points'][str(p)] for p in om.faces[f]['pointIDs']) for f in shell),
   'allNonmovingPointsExact':all(v==cand['points'][p] for p,v in old['points'].items() if int(p) not in moving),
   'outsideByteMoments':unchangedOutside,'sumVolumeRelativeDifference':abs(newv-oldv)/oldv,'sumFirstMomentDifferenceM4':float(np.linalg.norm(newM-oldM))}
  results.append(record)
  print(json.dumps({k:v for k,v in record.items() if k not in ['candidateDocument','actualMetrics','lineage','outsideByteMoments']}),flush=True)
out={'format':'actual7785-shared-interior-point-backtracked-full-geometry/v1','source':str(N/'joint-internal-relaxation.json'),
 'oldDocument':old,'oldActualMetrics':oq,'movingPoints':moving,'shellFaceIDs':shell,'fullCoreCells':old['children'],'fullOutsideCells':old['outsideCells'],'results':results,
 'toolSHA256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'nativeAcceptance':False}
(N/'joint-interior-backtracked.json').write_text(json.dumps(out,indent=2)+'\n')
