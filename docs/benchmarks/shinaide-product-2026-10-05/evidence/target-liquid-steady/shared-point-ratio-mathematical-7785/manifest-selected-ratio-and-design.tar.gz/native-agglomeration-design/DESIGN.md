# Conditional finite agglomeration / interior-partition design

This is a read-only engineering hypothesis, not a mesh repair or case acceptance. It uses exactly two adjacent pairs from the current rank-1 written Shinaide mesh. No native/API/checker/browser/solver job was run, no geometry/input array was changed, and no broad union search was made. Current production source remains AIR C ead4a057 / H 4a5ef961 / app babd07c8.

## Primary formula and gate distinctions

Installed v2412 primitiveMeshTools.C:829–932 computes the 3D determinant from internal/coupled faces only:
a = mean(|Sf|); T = sum (Sf/a) outer (Sf/a); D = abs(det(T))/8.
Deleting an interface changes both the selected set and normalization, so determinants cannot be added or averaged across old cells. D can exceed one; the installed code does not clamp it. Physical boundary faces contribute no Sf to this measure.

polyMeshTools.C:175–274 gives W=min(|Sf.(Cf-Co)|,|Sf.(Cn-Cf)|)/(sum+VSMALL) and R=min(Vo,Vn)/(max+VSMALL). Physical uncoupled boundary values are one; coupled values require the actual remote CC/V. For strictly positive signed pyramid distances and negligible VSMALL, W>=.05 needs each distance no more than 19 times the other; R>=.01 needs each volume no more than 100 times the other. These are useful proposal bounds only: acceptance must recompute the exact installed floating formula, sign/pyramid/tets and complete actual outside geometry.

primitiveMeshCheck.C:808–899 tests each outward face-plane normal against every other face centre:
n_i.(Cf_j-Cf_i)/max(|Cf_j-Cf_i|,VSMALL) > -1e-6 is a concave-or-planar trigger.
A genuinely convex cell with separate coplanar exterior tiles therefore can fail this stock gate. That is different from a negative cell-centroid face pyramid and from an all-vertex halfspace violation. The upstream checkGeometry.C:937–955 caller increments the failed-check counter for this predicate (line942); allGeometry determinant is also a failed check. Its face-flatness block at893–913 leaves the failed counter commented out. Strict face planarity and all-vertex halfspaces are stronger conservative native/mathematical screens, not a proof that all omitted alternatives must fail stock.

N<=70 is the existing no-new-severity proposal/Pareto policy, not a claim that every >70 stock face adds a failed-check category. All actual stock full flags, pyramid/tet, skew and coupled gates remain required; thresholds are unchanged.

## Exact written evidence

Input stencil0-input.json SHA d2085e264e0b10a5c521066a8c1cbd37d2b8bb1de2d286126f40cd767d77cd11 binds 26 native/mesh files and case manifest fd372838caccb455b42ed67fd7b2c17dca88b1711955cb4973738bd5feea5fb7. This replay rehashed all 26 files; 82 original point coordinates, 332 actual face cycles/owner/neighbour/patch name/type, and 124 complete cell face lists/CC/V match the written files exactly. Written faceZones has five named empty collections; cellZones and pointZones are empty. Source zone labels in the two retained shells are -1.

1. Original R seed [508852,508856], shared face1468973: literal union retains eight external polygons and closed opposite edge cycles. Vsum is exact and centred first-moment difference is 8.33e-21 m^4; the other122 complete cells retain CC/V and CF bit-for-bit. D improves to6.41134, but the stock predicate has nine strictly positive-outside directed pairs, zero near-coplanar pairs. Face1468929 has merged-cell pyramid -6.18308e-7 m^3 and negative centre/original fans. Two previously passing exterior ratios fall to.00363621/.00708781; skew68.5912 and N89.1768 appear. This is a real geometry/role rejection, not only an optional all-vertex screen.

2. Two actual D-bad adjacent tets [508855,508858], shared face1468978: old D=.000585074/.000758630 become.0498756, Vrel=1.20e-16 and centred moment difference6.03e-21 m^4, with unchanged other122 complete cells. Nevertheless six positive-outside face-centre pairs, negative merged pyramids/fans, and an existing bad-N severity increase to97.598deg reject it. Improving the D label count alone would hide an invalid union.

Neither tested shell has a coplanar-pair trigger; coalescing coplanar tiles alone is not a repair of these two pairs. This result does not exclude larger cavities or a new internal partition, and is not a whole-case infeasibility certificate.

## Lawful bounded proposal mechanism

A. Build a face-adjacency cavity from bad-D/W/R seeds and unprotected internal faces, using stable coordinate keys. In the first implementation keep the existing two-to-four-cell, finite face/test/depth caps. Avoid any zone, material/interface, physical/coupled role, active-case or remote-state ambiguity. Use normal topology/metadata, never diagnostic trace ancestry as an algorithm dependency. Same original-parent is an implementation scope limit; a later cross-parent proposal requires explicit equality of physical material/zone/source semantics, not assumed equality from proximity.

B. Define the exact oriented external shell by cancelling faces whose owner and neighbour are both in the cavity. Each retained face keeps all original coordinates and a single counterpart role. Verify directed edges twice/opposite, original enclosed volume and centred first moment, actual OF polygon SF/FC, finite positive cell volume, pyramids, both official tet fan paths, and the stock face-centre predicate. All-vertex convexity can be an optional conservative filter, separately labelled. A positive-outside trigger is not fixed merely by merging coplanar triangles: either reject, or admit the responsible outside cell via a bounded closure step so that face becomes internal-to-cavity and is removed. Re-evaluate the shell after every extension; stop and reject when the finite cap or a protected frontier is met. No infinite/global propagation is authorized.

C. Coplanar exterior tile normalization is possible only when the complete role matches: same inside cell and same outside cell (or the same physical patch/BC/source/zone identity), a single exact coplanar outline, opposite-edge cancellation, no holes/self-touch, retained required boundary/zone nodes, and preserved area and first moment. One polyMesh face cannot have several outside neighbours. Distinct-neighbour tiles therefore require a coordinated neighbour agglomeration/repartition or rejection; they cannot be silently made one face. Both local counterpart CF lists must be updated together and each complete neighbour CC/V/SF tensor recomputed. Physical coalescing additionally needs uniform BC/source semantics on the joined footprint and preservation of integrated thermal/flow quantities.

D. If literal agglomeration fails but the finite cavity is suitable, a separate proposal can replace only its internal partition (canonical polygon refan, a new interior point/face, or a finite shared-node move). Cavity boundary point coordinates, oriented footprint, physical/zone/coupled identities stay fixed. Shared internal polygons must be assembled once with opposite orientation for both cells, with no duplicate faces or T-junctions. Existing internal face support planes are not a physical hard boundary: allowing an interior polygon/quad to rotate with a finite shared-node closure can explore a broader lawful domain than locking every old quad plane. This is conditional on positive/conforming cells and full original stock gates, not authorization for arbitrary warped physical faces. A new internal point must obey the existing writer point-gap/area/fan guards. Parent volume/first moment and original source/STL geometry remain unchanged.

E. For every proposal evaluate new core cells, all incident interfaces, and complete one-ring outside cells using the final intended ordering/orientation. A merged cell inherits every old passing cell role; a retained/coalesced interface inherits every old passing facet role. Explicitly identify deleted internal interfaces as topology removal. Protect no-new passing failures, bad counts and worst severity across D/W/R/skew/N; also enforce original geometry/tet/coupled gates independently. Renumbered labels cannot hide a regression, and arithmetic changes to outside CF/CC/V cannot be masked by stale cached values. Finite caps and local improvement do not replace global validation.

F. Canonical owner<neighbour requires swapping owner/neighbour and reversing the polygon tail while keeping the agreed point zero. Coupled polygon cycle/point-zero/remote CC/V must match the stock writer ABI and actual neighbour state. First scope should veto changed coupled/zone footprints. Unchanged coupled faces on an affected outside cell are safe only if that cell's full written CC/V and all coupled SF/FC remain exact; otherwise expand coordination or reject. Unsupported AMI/transformed/unknown neighbour state must fail closed. Preserve exact zone member identities after compaction.

G. Use cached actual face geometry and cheap selected-Sf census to order a finite number of local proposals; measure local time separately. Maintain flag-OFF behaviour and a common collective schedule on empty and non-empty ranks. The existing 300s whole product budget still covers export, native construction, strict full topology+geometry checking, receipts and hashing. No offline argument guarantees the proposed extension will meet it. Only a fresh real React/API run with matching source/binary/input, full checkMesh and the total deadline can authorize a product mesh.

## Current recommendation

Prefer a narrow cavity-shell closure / counterpart-role mechanism over a new blind apex search. For the R seed, the literal pair already creates genuinely outside face centres and two new ratio failures; use the actual trigger/counterpart map as rejection/closure information. AIR is independently examining shared internal-quad rotation with the physical/coupled outer ring fixed; that is complementary and has not yet established a accepted geometry. Do not promote the old 30-group all-vertex rejection into a stock impossibility statement.

All source mesh/STL/project/ports/routes are untouched. Preserving today's written physical footprint does not correct or validate the pre-existing 1.6203125mm raw-STL normal offset. No current or hypothetical candidate is a strict full Shinaide mesh PASS.


## Reproduction

From integration root, this read-only command overwrites only the scratch audit output; all mesh/native inputs are read-only.

```sh
PYTHONDONTWRITEBYTECODE=1 CUDA_VISIBLE_DEVICES='' OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 taskset -c 24-31 /mnt/lv/home/litianyu/miniconda3/envs/dcdtuni/bin/python .codex-tmp/native-agglomeration-design-20261005/replay_two_pairs.py --integration /mnt/lv/home/litianyu/mycode/dcdtuni/.codex-tmp/goal-20261005/integration --input /mnt/lv/home/litianyu/mycode/dcdtuni/.codex-tmp/goal-20261005/air/.codex-tmp/shared-point-ratio-7785-20261005/stencil0-input.json --output /mnt/lv/home/litianyu/mycode/dcdtuni/.codex-tmp/goal-20261005/integration/.codex-tmp/native-agglomeration-design-20261005/two-pair-written-audit.json
```
