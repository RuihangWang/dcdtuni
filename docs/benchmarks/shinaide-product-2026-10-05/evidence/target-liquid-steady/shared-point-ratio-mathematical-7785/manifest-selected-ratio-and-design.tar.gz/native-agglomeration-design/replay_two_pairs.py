#!/usr/bin/env python3
'''Read-only two-pair diagnostic; outputs evidence only, never mutates a mesh.'''
import argparse, hashlib, json, sys, re
from pathlib import Path
import numpy as np
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
p=argparse.ArgumentParser()
p.add_argument('--integration',type=Path,required=True)
p.add_argument('--input',type=Path,required=True)
p.add_argument('--output',type=Path,required=True)
args=p.parse_args()
sys.path.insert(0,str(args.integration/'tools'))
import audit_air_cone_small_union_independent as U
import audit_air_mesh_geometry as G
raw=json.loads(args.input.read_text());doc=raw['oldDocument']
binding=raw['actualSourceBinding'];mesh=Path(binding['mesh'])
root=args.integration.resolve()
assert args.output.resolve().is_relative_to(root)
manifest=root.parent/'air/.codex-tmp/installed-writer-cua-7785c33f/case-file-manifest.json'
assert sha(manifest)==binding['caseManifestSHA256']
bound=[]
for rel,digest in binding['boundFileSHA256'].items():
    file=mesh.parent/rel
    digest_now=sha(file)
    assert digest_now==digest,(file,digest_now,digest)
    bound.append({'path':str(file),'bytes':file.stat().st_size,'sha256':digest_now})
geo=G.Geometry(mesh/f"processor{raw['rank']}/constant/polyMesh")
point_exact=all(np.array_equal(geo.points[int(k)],v) for k,v in doc['points'].items())
face_exact=True
for key,row in doc['faces'].items():
    f=int(key);nei=int(geo.neighbour[f]) if f<len(geo.neighbour) else None
    face_exact &= list(map(int,geo.ids(f)))==row['pointIDs'] and int(geo.owner[f])==row['owner'] and nei==row['neighbour'] and geo.patch(f)==row['patch']
assert point_exact and face_exact
old,before=U.family_metrics(doc)
source_cell_rows=[]
for key,row in doc['cells'].items():
    c=int(key);fs,_,_,cc,V,*_=geo.cell(c)
    assert list(map(int,fs))==row['faces']
    assert np.array_equal(cc,row['writtenCentre']) and V==row['writtenVolume']
    source_cell_rows.append({'cell':c,'completeFaceListExact':True,'writtenCentreVolumeDPExact':True})
pairs=[]
for label,group in [('ratioSeed',[508852,508856]),('twoActualDBadTets',[508855,508858])]:
    cand,deleted,outer=U.union_document(doc,group)
    cand,flips=U.canonicalize_internal_roles(cand)
    new,after=U.family_metrics(cand);rep=min(group)
    areas,centres,CC,V=new.cell(rep);fs=new.cells[rep]['faces']
    triggers=[]
    for i,f in enumerate(fs):
        normal=areas[i]/max(np.linalg.norm(areas[i]),1e-300)
        for j,other in enumerate(fs):
            if i==j:continue
            delta=centres[j]-centres[i];length=float(np.linalg.norm(delta))
            unitdot=float(np.dot(normal,delta)/max(length,1e-300))
            if unitdot>-1e-6:
                a,b=new.faces[f],new.faces[other]
                outside=lambda row:row['neighbour'] if row['owner']==rep else row['owner']
                triggers.append({'face':f,'otherFace':other,'outwardUnitNormal':normal.tolist(),
                    'faceCentre':centres[i].tolist(),'otherFaceCentre':centres[j].tolist(),
                    'unitDot':unitdot,'normalOffsetM':float(np.dot(normal,delta)),
                    'classification':'positiveOutside' if unitdot>1e-6 else 'nearCoplanar',
                    'outsideCells':[outside(a),outside(b)],
                    'patches':[a['patch'],b['patch']],
                    'sourceZones':[a.get('sourceZone'),b.get('sourceZone')],
                    'sourceBases':[a.get('sourceBase'),b.get('sourceBase')],
                    'facePointIDs':a['pointIDs'],'otherFacePointIDs':b['pointIDs']})
    unchanged=[]
    for c in old.cells:
        if c in group:continue
        oc,nc=old.cell(c),new.cell(c)
        unchanged.append({'cell':c,'completeCFUnchanged':old.cells[c]['faces']==new.cells[c]['faces'],
             'centreDPExact':np.array_equal(oc[2],nc[2]),'volumeDPExact':oc[3]==nc[3],
             'centreDifferenceM':float(np.linalg.norm(oc[2]-nc[2])),'volumeDifferenceM3':nc[3]-oc[3]})
    assert all(r['completeCFUnchanged'] and r['centreDPExact'] and r['volumeDPExact'] for r in unchanged)
    origin=np.mean([old.cell(c)[2] for c in group],axis=0)
    oldV=sum(old.cell(c)[3] for c in group)
    M=sum((old.cell(c)[3]*(old.cell(c)[2]-origin) for c in group),np.zeros(3))
    area_unchanged=all(np.array_equal(old.face(f)[0],new.face(f)[0]) and np.array_equal(old.face(f)[1],new.face(f)[1]) for f in outer)
    lineage=U.lineage_pareto(before,after,group,rep)
    changed_rows=[new.face_detail(f) for f in outer]
    pairs.append({'name':label,'originalCells':group,'replacementCell':rep,
        'oldCells':[old.cell_detail(c) for c in group],'replacementCellGeometry':new.cell_detail(rep),
        'deletedInternalFaces':deleted,'retainedLiteralExteriorFaces':outer,'canonicalFacesFlipped':flips,
        'originalPointsUntouched':cand['points']==doc['points'],
        'retainedExteriorSFandFCDPExact':area_unchanged,
        'cellVolumeRelativeError':abs(V-oldV)/oldV,
        'centredVolumeFirstMomentDifferenceM4':float(np.linalg.norm(V*(CC-origin)-M)),
        'stockFaceCentrePairTriggers':triggers,
        'positiveOutsidePairCount':sum(t['classification']=='positiveOutside' for t in triggers),
        'nearCoplanarPairCount':sum(t['classification']=='nearCoplanar' for t in triggers),
        'newExteriorFaceMetrics':changed_rows,'passingRoleLineage':lineage,
        'unchangedCompleteCellCount':len(unchanged),'unchangedCompleteCells':unchanged,
        'unsupportedUnchangedCoupledFaces':after['unaffectedUnknownCoupledFaces'],
        'rejected':True,
        'rejectionScope':'Actual stock face-centre predicate plus pyramid/tet and exterior role metrics; not only all-vertex sufficient convexity.'
    })
OF=Path('/mnt/lv/home/litianyu/miniconda3/envs/dcdtuni/src/OpenFOAM/lnInclude')
up=args.integration/'docs/benchmarks/shinaide-product-2026-10-05/evidence/target-liquid-steady/conforming-cone-quad-union-independent/upstream-v2412-checkGeometry.C'
C=root.parent/'air/src/backend/aircooling/third_parties/dcCartMesh/src/mesh/dcCartMesh/dcCartCutCells/dcCartCutCells.C'
source_files=[OF/'primitiveMeshCheck.C',OF/'primitiveMeshTools.C',OF/'polyMeshTools.C',OF/'polyMeshCheck.C',up,C,Path(U.__file__),Path(G.__file__)]
zones={}
for z in ('faceZones','cellZones','pointZones'):
    path=geo.poly_dir/z;body=path.read_text()
    zones[z]={'sha256':sha(path),'emptyZoneCollection':bool(re.search(r'0\s*\(\)',body)),
        'faceLabelDeclaredCounts':list(map(int,re.findall(r'faceLabels\s+List<label>\s+(\d+)',body)))}
result={'scope':'Read-only actual-written local diagnostic of exactly two predetermined adjacent pairs; no candidate scan, native/checker/job, acceptance or mesh mutation.',
        'input':{'path':str(args.input),'sha256':sha(args.input)},'actualSourceBinding':binding,
        'boundFilesVerified':bound,'writtenPointCountDPExact':len(doc['points']),
        'writtenFaceCountExactIncludingPatchNameType':len(doc['faces']),
        'completeWrittenCellCountDPExact':len(source_cell_rows),'zoneFileObservations':zones,
        'sourceFiles':[{'path':str(f),'sha256':sha(f)} for f in source_files],
        'pairs':pairs,
        'limitations':['No coupled metrics recomputed where remote state is absent; their complete local cell state remains DP-exact in these literal candidates.',
            'Existing all-vertex halfspace and exact-planarity rejection are stronger sufficient screens than stock checkConcaveCells.',
            'Area tensor determinant may exceed one; installed formula is used without clipping.',
            'Both candidates are rejected offline; no local/full product acceptance is implied.']}
args.output.write_text(json.dumps(result,indent=2)+chr(10))
print(json.dumps({'output':str(args.output),'sha256':sha(args.output),'boundFiles':len(bound),
 'points':point_exact,'faces':face_exact,'completeCells':len(source_cell_rows),
 'pairs':[{'name':r['name'],'D':r['replacementCellGeometry']['D'],
   'stockPairTriggers':len(r['stockFaceCentrePairTriggers']),'positiveOutside':r['positiveOutsidePairCount'],
   'nearCoplanar':r['nearCoplanarPairCount'],'Vrel':r['cellVolumeRelativeError'],
   'momentDifferenceM4':r['centredVolumeFirstMomentDifferenceM4'],
   'passingRoleFailures':{k:len(v['originalPassingRoleFailures']) for k,v in r['passingRoleLineage'].items()},
   'completeUnchanged':r['unchangedCompleteCellCount']} for r in pairs]},indent=2))
