# Actual 7785 bounded ratio and shared-point mathematical candidates

This is a read-only mathematical checkpoint, not a native mesh acceptance. The original GUI job 7785c33f and all its case arrays remain unchanged: stock checkMesh still reports Failed 3 (909 determinant cells, 100 low-weight faces, 2 low-volume-ratio faces), with 755 non-orthogonality warnings. No C++ change, build, mesh/checker/solver job, service, API, browser or Git-index operation was performed.

The input is the current Shinaide_MeshAbort_CUA/Mesh named in each actualSourceBinding, not an older family or reused label set. The immutable case-file manifest is fd372838caccb455b42ed67fd7b2c17dca88b1711955cb4973738bd5feea5fb7. Every declared original array was rehashed at freezing, and the previously frozen N/P/F 116 payload files were rechecked unchanged.

## Bounded ratio tests

The two current failed ratio faces are rank 1 face 1468973 (cells 508852/508856, original parent 25237) and rank 3 face 1512587 (cells 522094/522097, parent 26947). rank{1,3}-bounded-ap-only.json holds complete original point stars, complete outside cells and original second-ring moments, source identities, all proposal and backtrack results. The generic count-proxy solver used two starts and at most 60 iterations; its numeric result is only a proposal, followed by the original full mathematical guards.

Rank 1's one-apex proposals reduced local D 8→6 and W 16→8 but left its ratio failure and very slightly worsened its existing failed-ratio severity; all six variants were rejected. This finite search does not prove that all apex positions, coordinated point movements or new topology are impossible.

Rank 3's apex-only candidate at run 0 / fraction 0.95 reduced D 6→4, W 1→0 and R 1→0 over 27 core and 21 outside cells. Its passing D minimum is 0.0010829532388321533. Four D failures remain in that stencil. The 0.95 backtrack was chosen for a larger positive passing-D margin than 0.999, without hardcoded production coordinates.

## Combined eleven-point candidate

combined-eleven-point-audit.json rebuilds the actual complete shared stencil for the prior ten-point candidate plus the rank 3 ratio apex, then round-trips an isolated copy through the actual binary64 points format. It covers 304 core and 209 outside cells. D 39→14, W 15→1, R 1→0 and S 0→0. Non-orthogonality warning labels are allowed to exchange: count 49→50, maximum 83.12715637727378 degrees, below the original global 88.2022-degree ceiling.

All original passing hard roles remain passing, and existing hard-failure count/severity do not increase. The full point-star and outside guards include positive volumes, exact directed-edge closure, stock face-centre concavity, positive tetrahedral fans, the declared conservative polygon domain, all actual outside CC/V, and rank-global point clearance. The 209 outside centres and volumes are DP-byte identical. Exact Fraction cavity volume and first moment are equal before/after. No unrelated point, face connectivity, patch, zone or BC data is changed.

One physical interior node moves tangentially within the same literal written ACU_03_Front_patch plane; its fixed ordered outer ring, signed footprint area and first moment are preserved. unchangedShellOrderedWorldCoordinatesAndRoles=false is expected for this physical triangulation: this does not claim every physical face coordinate is unchanged. The previously measured 1.6203125 mm normal deviation from the raw STL is retained, neither corrected nor increased; raw-STL exact geometry is not claimed.

The isolated combined-eleven-points.binary-format-copy preserves the source header/suffix and every non-moving raw scalar byte. LSB label32/scalar64 round-trip preserves the candidate's double bytes. This is not an invocation of the C++ writer, installed OpenFOAM recomputation, MPI exchange or final coupled certificate. The minimum passing D margin over the combined candidate is 8.597687517957007e-7; native implementation must retain a measured margin after its actual arithmetic and fail closed.

## Conditional support screen, not a physical impossibility result

The five stencil*-input.json snapshots inspect a second node adjacent to a ratio apex. Holding every original non-triangular support plane and every other vertex fixed gives that node zero degrees of freedom. This is a deliberately narrow conservative motion domain. It does not rule out rotating or reshaping internal polygons with coordinated neighboring nodes, or legitimate local remeshing with a fixed physical/coupled cavity boundary.

The official v2412 checkGeometry.C copy and line-numbered excerpt are saved under primary-source. Its face-flatness branch has //noFailedChecks++;, while face-centre cell concavity, face tetrahedra, low weights and low volume ratios increment failed checks. The mathematical auditor additionally requires strict face planarity and all-vertex halfspace containment. These are stronger conservative proposal-domain assumptions, not additional user requirements or proof that stock rejects every motion outside that domain. Final product acceptance keeps the original allTopology/allGeometry options and thresholds.

## Reproduction and preservation

Eight focused tests passed; stdout/stderr and the source-bound test receipt are included. Driver functions have no import-time computation. Their math-reader dependencies are the sibling frozen N/P/F directories named in receipt.json; the parent campaign preserves them together. Re-run the tests only from this AIR checkout with the recorded Python, CPU 8–15, CUDA empty and BLAS thread count 1.

manifest.json declares this directory's payload. It excludes only its own hash and test/cache transients. Preserve the binary-format scratch copy as an ignored archive or declared file rather than a large Git blob. This checkpoint does not preserve the whole worktree or authorize cleanup, a new native run, default promotion or solve.
