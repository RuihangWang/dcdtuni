from pathlib import Path
import sys,json,copy,time,ast
import numpy as np
HERE=Path(__file__).resolve().parent;AIR=HERE.parents[1]
N=HERE.parent/"shared-point-quality-7785-20261005";P=HERE.parent/"shared-point-components-7785-20261005";FF=HERE.parent/"flat-point-quality-7785-20261005"
sys.path[:0]=[str(FF),str(N),str(N/"readers"),str(AIR/"src")]
import flat_support as F
import audit_writer_point_format as W
V=F.V;G,T=V.G,V.T
M=AIR.parent/"integration/.codex-tmp/cases/Shinaide_MeshAbort_CUA/Mesh";E=AIR/".codex-tmp/installed-writer-cua-7785c33f"
tree=ast.parse((P/"run_bounded_joint.py").read_text());defs=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ("cf","document")]
exec(compile(ast.Module(body=defs,type_ignores=[]),str(P/"run_bounded_joint.py"),"exec"),globals())
def main():
 start=time.monotonic();base=json.loads((FF/"combined-flat-and-internal-components-audit.json").read_text());r=json.loads((HERE/"rank3-bounded-ap-only.json").read_text());selected=next(z for z in r["results"] if z["run"]==0 and z["fraction"]==.95)
 moving=base["movingPoints"]+r["movingPoints"];physical=base["physicalPoints"]
 g=G.Geometry(M/"processor3/constant/polyMesh");t=T.read_trace(M,3);old=document(g,t,moving);new=copy.deepcopy(old)
 for p in base["movingPoints"]:new["points"][str(p)]=base["candidateDocument"]["points"][str(p)]
 for p in r["movingPoints"]:new["points"][str(p)]=selected["candidateDocument"]["points"][str(p)]
 new["originalApex"]=new["points"][str(new["apexWrittenPoint"])]
 _,_,binding=V.raw_binding(old,moving,M,3,E/"case-file-manifest.json")
 points,serialization=W.write_binary_points_copy(M/"processor3/constant/polyMesh/points",HERE/"combined-eleven-points.binary-format-copy",{p:new["points"][str(p)] for p in moving})
 for p in new["points"]:new["points"][p]=points[int(p)].tolist()
 new["originalApex"]=new["points"][str(new["apexWrittenPoint"])]
 audit=F.authorize_flat(old,new,moving,physical_points=physical);audit["globalRankPointClearance"]=V.global_gap(g,new,moving)
 if not all(q["exceedsWriter1MicrometreAnd3MicrometreSafety"] for q in audit["globalRankPointClearance"]):audit["mathematicalLocalCandidateAccepted"]=False
 a=W.exact_core_moments(old);b=W.exact_core_moments(new)
 out={"format":"actual7785-eleven-point-shared-motion-with-one-ratio-repair/v1","movingPoints":moving,"physicalPoints":physical,"oldDocument":old,"candidateDocument":new,"actualSourceBinding":binding,"binaryFormat":serialization,"audit":audit,"passingHardMargin":W.margin_summary(audit["oldActualMetrics"],audit["newActualMetrics"]),"coreFractionVolumeMomentBefore":a,"coreFractionVolumeMomentAfter":b,"exactCoreFractionVolumeMoment":a==b,"inputSHA256":{"tenPoint":V.sha(FF/"combined-flat-and-internal-components-audit.json"),"oneAP":V.sha(HERE/"rank3-bounded-ap-only.json")},"selectedRatioBacktrack":{"run":0,"fraction":.95,"reason":"Same D/W/R counts as .999, larger passing D margin; no coordinate hardcoding."},"toolSHA256":V.sha(__file__),"elapsedSeconds":time.monotonic()-start,"noMeshMutation":True,"nativeAcceptance":False}
 (HERE/"combined-eleven-point-audit.json").write_text(json.dumps(out,indent=2)+"\n")
 print(json.dumps({"accepted":audit["mathematicalLocalCandidateAccepted"],"oldCounts":audit["oldCounts"],"newCounts":audit["newCounts"],"Nmax":audit["maximumWarningDegrees"],"core":len(old["children"]),"outside":len(old["outsideCells"]),"exactVM":a==b,"elapsedSeconds":out["elapsedSeconds"]}),flush=True)
if __name__=="__main__":main()
