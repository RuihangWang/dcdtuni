from pathlib import Path
import sys,json,copy,ast,time
import numpy as np
HERE=Path(__file__).resolve().parent;AIR=HERE.parents[1]
N=HERE.parent/"shared-point-quality-7785-20261005";P=HERE.parent/"shared-point-components-7785-20261005";F=HERE.parent/"flat-point-quality-7785-20261005"
sys.path[:0]=[str(F),str(N),str(N/"readers"),str(AIR/"src")]
import audit_shared_point_candidate as V
import joint_flat_count_proxy_solver as S
G,T=V.G,V.T
M=AIR.parent/"integration/.codex-tmp/cases/Shinaide_MeshAbort_CUA/Mesh";E=AIR/".codex-tmp/installed-writer-cua-7785c33f"
tree=ast.parse((P/"run_bounded_joint.py").read_text());defs=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ("cf","document")]
exec(compile(ast.Module(body=defs,type_ignores=[]),str(P/"run_bounded_joint.py"),"exec"),globals())
def main():
 started=time.monotonic();summaries=[]
 for rank,p in [(1,19983),(3,20894)]:
  if time.monotonic()-started>50:break
  g=G.Geometry(M/f"processor{rank}/constant/polyMesh");t=T.read_trace(M,rank);moving=[p];doc=document(g,t,moving)
  _,_,binding=V.raw_binding(doc,moving,M,rank,E/"case-file-manifest.json")
  proposal=S.solve(doc,moving,maxiter=60);results=[]
  for seq,run in enumerate(proposal["runs"]):
   for fraction in [.999,.95,.5]:
    new=copy.deepcopy(doc);a=np.asarray(doc["points"][str(p)]);b=np.asarray(run["candidateDocument"]["points"][str(p)])
    new["points"][str(p)]=(a+fraction*(b-a)).tolist();new["originalApex"]=new["points"][str(p)]
    audit=V.authorize(doc,new,moving);audit["globalRankPointClearance"]=V.global_gap(g,new,moving)
    if not all(q["exceedsWriter1MicrometreAnd3MicrometreSafety"] for q in audit["globalRankPointClearance"]):audit["mathematicalLocalCandidateAccepted"]=False
    results.append({"run":seq,"fraction":fraction,"candidateDocument":new,"audit":audit})
  out={"rank":rank,"movingPoints":moving,"oldDocument":doc,"actualSourceBinding":binding,"proposal":proposal,"results":results,"sourceSHA256":{"driver":V.sha(__file__),"solver":V.sha(F/"joint_flat_count_proxy_solver.py"),"auditor":V.sha(N/"audit_shared_point_candidate.py")},"nativeAcceptance":False,"noMeshMutation":True}
  (HERE/f"rank{rank}-bounded-ap-only.json").write_text(json.dumps(out,indent=2)+"\n")
  summary={"rank":rank,"point":p,"proposalSeconds":proposal["proposalElapsedSeconds"],"results":[{"run":r["run"],"fraction":r["fraction"],"accepted":r["audit"]["mathematicalLocalCandidateAccepted"],"oldCounts":r["audit"]["oldCounts"],"newCounts":r["audit"]["newCounts"],"Nmax":r["audit"]["maximumWarningDegrees"]} for r in results]};summaries.append(summary);print(json.dumps(summary),flush=True)
 (HERE/"bounded-ap-summary.json").write_text(json.dumps({"records":summaries,"elapsedSeconds":time.monotonic()-started,"noMeshMutation":True,"nativeAcceptance":False},indent=2)+"\n")
if __name__=="__main__":main()
