from pathlib import Path
import sys,json,numpy as np
import pytest
HERE=Path(__file__).resolve().parent;N=HERE.parent/"shared-point-quality-7785-20261005";F=HERE.parent/"flat-point-quality-7785-20261005"
sys.path[:0]=[str(F),str(N),str(N/"readers"),str(HERE.parents[1]/"src")]
import audit_shared_point_candidate as V
@pytest.fixture(scope="module")
def positive():return json.loads((HERE/"rank3-bounded-ap-only.json").read_text())
@pytest.fixture(scope="module")
def negative():return json.loads((HERE/"rank1-bounded-ap-only.json").read_text())
@pytest.fixture(scope="module")
def combined():return json.loads((HERE/"combined-eleven-point-audit.json").read_text())
def test_true_actual_ratio_identity_not_borrowed(positive):
 assert positive["rank"]==3 and positive["movingPoints"]==[20894]
 row=positive["oldDocument"]["faces"]["1512587"]
 assert row["owner"]==522094 and row["neighbour"]==522097
 assert positive["oldDocument"]["cells"]["522094"]["sourceParent"]==26947
def test_full_original_formulas_reproduce_positive(positive):
 r=next(z for z in positive["results"] if z["run"]==0 and z["fraction"]==.95)
 a=V.authorize(positive["oldDocument"],r["candidateDocument"],positive["movingPoints"])
 assert a["mathematicalLocalCandidateAccepted"]
 assert a["oldCounts"]["ratio"]==1 and a["newCounts"]["ratio"]==0
 assert a["oldCounts"]["weight"]==1 and a["newCounts"]["weight"]==0
 assert a["oldCounts"]["D"]==6 and a["newCounts"]["D"]==4
 assert all(z["CC_DP_exact"] and z["V_DP_exact"] for z in a["outsideByteMoments"])
def test_passing_and_warning_scope_distinct(positive):
 a=positive["results"][1]["audit"]
 assert a["hardOriginalPassingRoleGuard"] and a["maximumWarningDegrees"]<88.2022
 assert a["lineage"]["nonOrthogonalityDegrees"]["originalPassingRoleFailures"]
 assert a["warningLabelExchangeAllowed"]
def test_rank1_does_not_claim_ratio_repair(negative):
 assert all(z["audit"]["newCounts"]["ratio"]==1 for z in negative["results"])
 assert all(not z["audit"]["mathematicalLocalCandidateAccepted"] for z in negative["results"])
 assert all(not z["audit"]["lineage"]["ratio"]["worstFailedSeverityDoesNotIncrease"] for z in negative["results"])
def test_combined_full_original_stencil_and_bits(combined):
 a=combined["audit"]
 assert a["mathematicalLocalCandidateAccepted"]
 assert len(combined["oldDocument"]["children"])==304
 assert len(combined["oldDocument"]["outsideCells"])==209
 assert a["oldCounts"]["D"]==39 and a["newCounts"]["D"]==14
 assert a["oldCounts"]["weight"]==15 and a["newCounts"]["weight"]==1
 assert a["oldCounts"]["ratio"]==1 and a["newCounts"]["ratio"]==0
 assert combined["binaryFormat"]["doublePointsByteExactAfterRoundtrip"]
 assert combined["exactCoreFractionVolumeMoment"]
 assert all(z["exceedsWriter1MicrometreAnd3MicrometreSafety"] for z in a["globalRankPointClearance"])
def test_physical_normal_footprint_and_no_actual_mutation(combined):
 q=combined["audit"]["scope"]["flatPhysicalProofs"][0]
 assert q["literalWrittenFootprintPreserved"] and q["rawSTLNormalOffsetNotCorrected"]
 assert combined["noMeshMutation"] and not combined["nativeAcceptance"]
def test_finite_narrow_support_screen_is_conditional():
 rows=json.loads((HERE/"support-census.json").read_text())
 assert len(rows)==5 and not any(z["eligible"] for z in rows)
 for k in range(5):
  z=json.loads((HERE/f"stencil{k}-input.json").read_text())
  node=z["supportRows"][1]
  assert node["fixedAxes"]==[0,1,2] and node["dimension"]==0
  assert any(w["role"] is None for w in node["nonTriangularSupportWitness"])
def test_selected_backtrack_has_nonzero_hard_margin(combined):
 assert combined["selectedRatioBacktrack"]["fraction"]==.95
 assert all(z["minimumAbsolutePassingMargin"]>0 for z in combined["passingHardMargin"].values())
