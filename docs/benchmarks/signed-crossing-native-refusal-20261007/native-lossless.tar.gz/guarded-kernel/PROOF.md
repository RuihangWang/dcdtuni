# PRIVATE v2 callback FP admission
The v1 exact-zero/support/cycle proof is unchanged. The only product change is Budget::tick: a successful available callback is followed immediately by supportedFloatingEnvironment. An absent/false/throwing callback or a now unsupported FP mode returns false and therefore follows the existing unknown refusal path. The kernel never repairs the mode.

The retained counterexample uses a=(0,0,0), b=(2^1022,2^-1021,0), one original triangle [0,1,0], and q=b/8=(2^1019,2^-1024,0), exactly on the segment. Stable FP gives unknown. Under v1, a classify callback that enables DAZ after the public entry guard admits known degree 0. This demonstrates an API callback boundary; the production adapter constant-true callback does not mutate FP state.

Added controls cover classify, classifyRay and prepare callbacks that enable DAZ, assert unknown and no automatic correction, then restore the saved FP mode and confirm the same prepared cache still rejects exact ON and returns known degree 0 for its nextafter OFF neighbor. All existing 709 analytic checks, 9 static FP controls, extreme nonzero areas and saved fixture queries stay present.
