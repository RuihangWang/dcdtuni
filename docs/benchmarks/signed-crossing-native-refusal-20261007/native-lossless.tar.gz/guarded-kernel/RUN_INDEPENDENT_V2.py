#!/usr/bin/env python3
"""PRIVATE CPU v2 replay: one compile and one unchanged saved-fixture control run."""
import argparse,csv,hashlib,json,os,signal,subprocess,time
from pathlib import Path
B=Path('/mnt/lv/home/litianyu/mycode/dcdtuni').resolve()
F=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--output',required=True);a=p.parse_args()
out=Path(a.output).resolve()
if B not in out.parents or out.exists():raise SystemExit('output must be fresh inside B')
if not set(os.sched_getaffinity(0)).issubset({28,29}):raise SystemExit('require taskset CPU28-29')
manifest=json.loads((F/'MANIFEST.json').read_text())
for x in manifest['files']:
    q=F/x['path'];data=q.read_bytes()
    if q.is_symlink() or len(data)!=x['bytes'] or hashlib.sha256(data).hexdigest()!=x['sha256']:
        raise SystemExit('source mismatch '+x['path'])
binding=json.loads((F/'BINDING.json').read_text());fixture=Path(binding['fixturePath']).resolve()
if B not in fixture.parents or fixture.is_symlink():raise SystemExit('fixture must be held under B')
data=fixture.read_bytes()
if len(data)!=binding['fixtureBytes'] or hashlib.sha256(data).hexdigest()!=binding['fixtureSha256']:
    raise SystemExit('fixture mismatch')
out.mkdir(parents=True);(out/'tmp').mkdir()
env=os.environ.copy();env.update(CUDA_VISIBLE_DEVICES='',TMPDIR=str(out/'tmp'),TMP=str(out/'tmp'),TEMP=str(out/'tmp'),OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2')
receipt={'scope':'one PRIVATE standalone CPU compile/replay; no native/whole/services/GPU',
         'sourceManifestSha256':hashlib.sha256((F/'MANIFEST.json').read_bytes()).hexdigest(),
         'parentExactDegenerateManifestSha256':binding['parentExactDegenerateManifestSha256'],
         'parentOriginal17kbHeaderSha256':binding['parentOriginal17kbHeaderSha256'],
         'cpuAffinity':sorted(os.sched_getaffinity(0)),'cudaVisibleDevices':env['CUDA_VISIBLE_DEVICES'],
         'fixture':{'path':str(fixture),'sha256':binding['fixtureSha256'],'bytes':len(data)},
         'sourceInputs':[x for x in manifest['files'] if x['path'].startswith(('after/','controls/'))],'commands':[]}
def run(name,argv,deadline):
    started=time.monotonic();timed=False
    with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:
        child=subprocess.Popen(argv,cwd=out,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
        try:rc=child.wait(timeout=deadline)
        except subprocess.TimeoutExpired:
            timed=True
            try:os.killpg(child.pid,signal.SIGTERM)
            except ProcessLookupError:pass
            try:rc=child.wait(timeout=2)
            except subprocess.TimeoutExpired:
                try:os.killpg(child.pid,signal.SIGKILL)
                except ProcessLookupError:pass
                rc=child.wait()
    receipt['commands'].append({'name':name,'argv':argv,'returncode':rc,'timedOut':timed,'elapsedSeconds':time.monotonic()-started})
    (out/'RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n')
    if rc or timed:raise SystemExit(name+' failed; raw stdout/stderr retained')
run('compiler-version',['g++','--version'],5)
binary=out/'signed-crossing-controls-v2'
run('compile',['g++','-std=c++14','-O2','-fno-fast-math','-ffp-contract=off','-frounding-math','-Wall','-Wextra','-Werror','-I'+str(F/'after/src/mesh/dcCartMesh/dcCartSurfaces'),str(F/'controls/signed_crossing_controls.cpp'),'-o',str(binary)],40)
run('controls',[str(binary),str(fixture)],15)
lines=(out/'controls.stdout').read_text().splitlines()
summary=json.loads(next(line for line in reversed(lines) if line.startswith('{')))
actual={int(p[1]):p for line in lines if line.startswith('ACTUAL\t') for p in [line.split('\t')]}
native={int(row['query']):row for row in csv.DictReader((F/'fixtures/API_COMPARISONS.tsv').read_text().splitlines(),delimiter='\t') if row['shell']=='7'}
if set(actual)!=set(native):raise SystemExit('original saved-query ID mismatch')
delta=[];maximum=0.0
for query,p in actual.items():
    n=native[query];old=float(n['fullsum']);standalone=float(p[7]);maximum=max(maximum,abs(old-standalone))
    if int(p[5]) and ((abs(int(p[6]))>0.5)!=(n['oldside']=='-1')):delta.append(query)
comparison={'scope':'PRIVATE v2 standalone vs held original shell7 native TSV; no new native process','originalQueryCount':len(actual),'known':sum(int(p[5]) for p in actual.values()),'unknown':sum(not int(p[5]) for p in actual.values()),'nativeOriginalFastSideDifferences':delta,'maximumNativeStandaloneFullsumDifference':maximum,'summary':summary}
(out/'ACTUAL-NATIVE-TSV-COMPARISON.json').write_text(json.dumps(comparison,indent=2)+'\n')
receipt['comparison']=comparison
(out/'RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
if delta or maximum:raise SystemExit('saved native comparison mismatch')
