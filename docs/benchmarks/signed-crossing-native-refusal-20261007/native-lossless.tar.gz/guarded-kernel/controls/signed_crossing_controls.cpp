#include "dcCartSignedCrossing.H"
#include <iostream>
#include <map>
#include <string>
#include <stdexcept>
#include <iomanip>
#include <sstream>
#include <fstream>
#include <cfenv>
#if defined(__x86_64__) && defined(__SSE__)
#include <xmmintrin.h>
#endif
namespace S=dcCartSignedCrossing;
using P=S::Point;
struct Mesh {std::vector<P> points;std::vector<S::Triangle> triangles;};
void require(bool ok,const std::string& why){if(!ok)throw std::runtime_error(why);}
// Independent adapter of original source41 solidShellWinding: original triangle
// order, Van Oosterom/Strackee sum, double sqrt/atan2, same abs(.) > 0.5 oracle.
double fullWinding(const Mesh& m,const P& q)
{
    auto sub=[](P a,P b){P r;for(int d=0;d<3;++d)r[d]=a[d]-b[d];return r;};
    auto dot=[](P a,P b){return a[0]*b[0]+a[1]*b[1]+a[2]*b[2];};
    auto cross=[](P a,P b){return P{{a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]}};};
    double sum=0;
    for(const auto& t:m.triangles)
    {
        const P a=sub(m.points.at(t.vertices[0]),q),b=sub(m.points.at(t.vertices[1]),q),c=sub(m.points.at(t.vertices[2]),q);
        const double la=std::sqrt(dot(a,a)),lb=std::sqrt(dot(b,b)),lc=std::sqrt(dot(c,c));
        const double numerator=dot(a,cross(b,c));
        const double denominator=la*lb*lc+dot(a,b)*lc+dot(a,c)*lb+dot(b,c)*la;
        sum+=2.0*std::atan2(numerator,denominator);
    }
    return sum/(4.0*std::acos(-1.0));
}
void cube(Mesh& m,double lo,double hi,bool inward=false,unsigned subdivisions=1)
{
    const P corners[8]={P{{lo,lo,lo}},P{{hi,lo,lo}},P{{hi,hi,lo}},P{{lo,hi,lo}},
                         P{{lo,lo,hi}},P{{hi,lo,hi}},P{{hi,hi,hi}},P{{lo,hi,hi}}};
    const unsigned faces[6][4]={{0,3,2,1},{4,5,6,7},{0,4,7,3},{1,2,6,5},{0,1,5,4},{3,7,6,2}};
    // Each original layer retains its own vertex identities, including exact
    // coincident coordinates with another layer. Never geometry-deduplicates.
    std::map<P,std::uint64_t> ids;
    auto id=[&](P p)
    {
        auto it=ids.find(p);if(it!=ids.end())return it->second;
        const std::uint64_t v=m.points.size();m.points.push_back(p);ids[p]=v;return v;
    };
    for(const auto& f:faces)for(unsigned u=0;u<subdivisions;++u)for(unsigned v=0;v<subdivisions;++v)
    {
        auto point=[&](unsigned iu,unsigned iv)
        {
            P p;for(unsigned d=0;d<3;++d)p[d]=corners[f[0]][d]+
                double(iu)/subdivisions*(corners[f[1]][d]-corners[f[0]][d])+
                double(iv)/subdivisions*(corners[f[3]][d]-corners[f[0]][d]);
            return id(p);
        };
        const auto a=point(u,v),b=point(u+1,v),c=point(u+1,v+1),d=point(u,v+1);
        for(auto indices:{std::array<std::uint64_t,3>{{a,b,c}},std::array<std::uint64_t,3>{{a,c,d}}})
        {
            if(inward)std::swap(indices[1],indices[2]);
            S::Triangle t;t.vertices=indices;t.originalTriangle=m.triangles.size();m.triangles.push_back(t);
        }
    }
}
bool insideBox(const P& p,double lo,double hi)
{for(double x:p)if(!(x>lo&&x<hi))return false;return true;}
std::size_t comparisons=0,known=0,unknown=0,floatingEnvironmentControls=0;
std::size_t callbackFloatingEnvironmentControls=0;
std::size_t actualQueries=0,actualKnown=0,actualUnknown=0;
double maximumActualDegreeError=0;
double maximumDegreeError=0;
void compare(const std::string& name,const Mesh& m,const S::PreparedShell& shell,const P& q,int analyticalDegree,bool requireKnown=true)
{
    S::Stats stats;const auto fast=shell.classify(q,[](){return true;},&stats);
    const double old=fullWinding(m,q);++comparisons;
    const bool analyticalInside=std::abs(analyticalDegree)>0.5,oldInside=std::abs(old)>0.5;
    require(std::isfinite(old),name+" fullsum nonfinite");
    require(oldInside==analyticalInside,name+" fullsum/analytic side mismatch");
    maximumDegreeError=std::max(maximumDegreeError,std::abs(old-analyticalDegree));
    if(!fast.known){++unknown;require(!requireKnown,name+" fast unknown");return;}
    ++known;
    require(fast.degree==analyticalDegree,name+" signed degree mismatch");
    require((std::abs(double(fast.degree))>0.5)==oldInside,name+" fast/fullsum side mismatch");
}
void refuse(const std::string& name,const Mesh& m)
{
    S::PreparedShell shell;require(!shell.prepare(m.points,m.triangles,[](){return true;}),name+" unexpectedly certified");
    require(!shell.classify(P{{0,0,0}},[](){return true;}).known,name+" emitted known side");
}
std::size_t degenerateComparisons=0,degenerateOriginalSideDifferences=0;
void tetra(Mesh& m,const std::array<P,4>& vertices)
{
    const auto base=m.points.size();for(const auto& p:vertices)m.points.push_back(p);
    const unsigned faces[4][3]={{0,2,1},{0,1,3},{1,2,3},{2,0,3}};
    for(const auto& f:faces)
    {S::Triangle t;t.vertices={{base+f[0],base+f[1],base+f[2]}};t.originalTriangle=m.triangles.size();m.triangles.push_back(t);}
}
void auditDegenerate(const std::string& label,const Mesh& m,const S::PreparedShell& shell,const P& q,int expected,bool on)
{
    const auto fast=shell.classify(q,[](){return true;});const double old=fullWinding(m,q);
    require(std::isfinite(old),label+" old fullsum nonfinite");++degenerateComparisons;
    if(on)require(!fast.known,label+" exact support emitted a known degree");
    else require(fast.known&&fast.degree==expected,label+" off-support mathematical degree");
    const bool oldSide=std::abs(old)>0.5,expectedSide=std::abs(expected)>0.5;
    if(!on&&oldSide!=expectedSide)++degenerateOriginalSideDifferences;
    std::cout<<std::setprecision(17)<<"DEGENERATE\t"<<label<<'\t'<<q[0]<<'\t'<<q[1]<<'\t'<<q[2]
        <<'\t'<<on<<'\t'<<fast.known<<'\t'<<fast.degree<<'\t'<<old<<'\t'<<expected<<'\n';
}
void degenerateControls(const Mesh& normal)
{
    Mesh line;tetra(line,{{P{{2,0,0}},P{{3,0,0}},P{{4,0,0}},P{{5,0,0}}}});
    S::PreparedShell ls;require(ls.prepare(line.points,line.triangles,[](){return true;}),"collinear closed cycle prepare");
    require(ls.zeroAreaTriangles()==4,"collinear exact zero-area tags");
    for(const P& q:{P{{2,0,0}},P{{3.125,0,0}},P{{5,0,0}}})auditDegenerate("collinear ON",line,ls,q,0,true);
    for(const P& q:{P{{3.125,1e-6,0}},P{{3.125,std::nextafter(0.,1.),0}},P{{6,0,0}}})auditDegenerate("collinear OFF",line,ls,q,0,false);
    require(!ls.classifyRay(P{{3.125,0,0}},P{{6,0.1,0}},[](){return true;}).known,"explicit ray support gate");
    require(!ls.classify(P{{6,0,0}},[](){return false;}).known,"degenerate outside clock gate");
    require(!ls.classify(P{{3.125,1e-6,0}},[]()->bool{throw std::runtime_error("clock");}).known,"degenerate throwing clock gate");
    Mesh repeated;repeated.points={P{{2,0,0}},P{{3,0,0}}};S::Triangle rt;rt.vertices={{0,0,1}};repeated.triangles.push_back(rt);
    S::PreparedShell rs;require(rs.prepare(repeated.points,repeated.triangles,[](){return true;}),"repeated-ID zero-chain prepare");
    require(rs.zeroAreaTriangles()==1,"repeated-ID exactzero tag");
    auditDegenerate("repeated-ID ON",repeated,rs,P{{2.5,0,0}},0,true);
    auditDegenerate("repeated-ID OFF",repeated,rs,P{{2.5,1e-6,0}},0,false);
    Mesh point;tetra(point,{{P{{2,0,0}},P{{2,0,0}},P{{2,0,0}},P{{2,0,0}}}});
    S::PreparedShell ps;require(ps.prepare(point.points,point.triangles,[](){return true;}),"point closed cycle prepare");
    require(ps.zeroAreaTriangles()==4,"point exactzero tags");
    auditDegenerate("point ON",point,ps,P{{2,0,0}},0,true);
    auditDegenerate("point OFF",point,ps,P{{2,std::nextafter(0.,1.),0}},0,false);
    Mesh combined=normal;tetra(combined,{{P{{2,0,0}},P{{3,0,0}},P{{4,0,0}},P{{5,0,0}}}});
    S::PreparedShell cs;require(cs.prepare(combined.points,combined.triangles,[](){return true;}),"solid plus nullcycle prepare");
    auditDegenerate("solid plus null INSIDE",combined,cs,P{{0.1,0.2,0.3}},1,false);
    auditDegenerate("solid plus null OUTSIDE",combined,cs,P{{6,0,0}},0,false);
    auditDegenerate("solid plus null ON",combined,cs,P{{3.125,0,0}},0,true);
    auto open=line;open.triangles.pop_back();refuse("open nullcycle",open);
    auto reversed=line;std::swap(reversed.triangles[0].vertices[1],reversed.triangles[0].vertices[2]);refuse("reversed nullcycle",reversed);
    auto invalid=line;invalid.triangles[0].vertices[0]=std::numeric_limits<std::uint64_t>::max();refuse("invalid nullcycle reference",invalid);
    Mesh tiny;tetra(tiny,{{P{{0,0,0}},P{{1,0,0}},P{{0,std::numeric_limits<double>::denorm_min(),0}},P{{0,0,1}}}});
    S::PreparedShell ts;require(ts.prepare(tiny.points,tiny.triangles,[](){return true;}),"near-zero nonzero area cycle");
    require(ts.zeroAreaTriangles()==0,"nonzero dyadic area mislabeled zero");
    const std::function<bool()> no=[](){return false;};S::detail::Budget budget{no};
    require(!S::detail::areaSign(P{{2,0,0}},P{{3,0,0}},P{{4,0,0}},budget).known,"exact area budget failure must refuse");
    // Originally this valid indexed cycle with a collapsed coordinate was
    // blanket-rejected. The stronger invariant is exact support exclusion.
    auto collapsed=normal;collapsed.points[1]=collapsed.points[0];S::PreparedShell collapsedShell;
    require(collapsedShell.prepare(collapsed.points,collapsed.triangles,[](){return true;}),"collapsed solid cycle prepare");
    require(collapsedShell.zeroAreaTriangles()>0,"collapsed solid exactzero tags");
    auditDegenerate("collapsed solid ON",collapsed,collapsedShell,collapsed.points[0],0,true);
    auditDegenerate("collapsed solid INSIDE",collapsed,collapsedShell,P{{0.1,0.2,0.3}},1,false);
}
struct RestoreFloatingEnvironment
{
    fenv_t environment;
#if defined(__x86_64__) && defined(__SSE__)
    unsigned csr;
#endif
    RestoreFloatingEnvironment()
    {
        require(std::fegetenv(&environment)==0,"save floating environment");
#if defined(__x86_64__) && defined(__SSE__)
        csr=_mm_getcsr();
#endif
    }
    ~RestoreFloatingEnvironment()
    {
        std::fesetenv(&environment);
#if defined(__x86_64__) && defined(__SSE__)
        _mm_setcsr(csr);
#endif
    }
};
void rejectFloatingMode(const Mesh& mesh,const S::PreparedShell& cached,const std::string& label)
{
    require(!S::supportedFloatingEnvironment(),label+" unsupported environment not detected");
    const auto q=cached.classify(P{{0.1,0.2,0.3}},[](){return true;});
    const auto outside=cached.classify(P{{4,4,4}},[](){return true;});
    const auto ray=cached.classifyRay(P{{0.1,0.2,0.3}},P{{2,0.21,0.33}},[](){return true;});
    require(!q.known&&q.refusal==S::Refusal::floatingEnvironment,label+" cached query");
    require(!outside.known&&outside.refusal==S::Refusal::floatingEnvironment,label+" cached outside query");
    require(!ray.known&&ray.refusal==S::Refusal::floatingEnvironment,label+" cached explicit ray");
    S::PreparedShell fresh;
    require(!fresh.prepare(mesh.points,mesh.triangles,[](){return true;})&&fresh.refusal()==S::Refusal::floatingEnvironment,label+" fresh prepare");
    ++floatingEnvironmentControls;
}
void floatingModeControls(const Mesh& mesh,const S::PreparedShell& cached)
{
    require(S::supportedFloatingEnvironment(),"default floating environment supported");
    for(int mode:{FE_UPWARD,FE_DOWNWARD,FE_TOWARDZERO})
    {
        {RestoreFloatingEnvironment restore;require(std::fesetround(mode)==0,"set rounding");rejectFloatingMode(mesh,cached,"C rounding change");}
        require(S::supportedFloatingEnvironment(),"C rounding environment restored");
        require(cached.classify(P{{0.1,0.2,0.3}},[](){return true;}).known,"cache usable after C rounding restore");
    }
#if defined(__x86_64__) && defined(__SSE__)
    for(unsigned flags:{1u<<15,1u<<6,(1u<<15)|(1u<<6),1u<<13,2u<<13,3u<<13})
    {
        {RestoreFloatingEnvironment restore;_mm_setcsr(_mm_getcsr()|flags);rejectFloatingMode(mesh,cached,"MXCSR change");}
        require(S::supportedFloatingEnvironment(),"MXCSR environment restored");
        require(cached.classify(P{{0.1,0.2,0.3}},[](){return true;}).known,"cache usable after MXCSR restore");
    }
#endif
}

void callbackFloatingModeControl()
{
#if defined(__x86_64__) && defined(__SSE__)
    // The physical query is exactly b/8. DAZ can falsely separate this
    // subnormal-y point from its zero-area segment if enabled after admission.
    Mesh segment;segment.points={P{{0,0,0}},P{{std::ldexp(1.0,1022),std::ldexp(1.0,-1021),0}}};
    S::Triangle t;t.vertices={{0,1,0}};segment.triangles.push_back(t);
    S::PreparedShell shell;
    require(shell.prepare(segment.points,segment.triangles,[](){return true;}),"callback FP segment prepare");
    require(shell.zeroAreaTriangles()==1,"callback FP exactzero tag");
    const P on{{std::ldexp(1.0,1019),std::ldexp(1.0,-1024),0}};
    require(!shell.classify(on,[](){return true;}).known,"callback FP stable exact ON must refuse");
    for(unsigned entry=0;entry<3;++entry)
    {
        RestoreFloatingEnvironment restore;unsigned calls=0;
        const std::function<bool()> mutate=[&]()
        {++calls;_mm_setcsr(_mm_getcsr()|(1u<<6));return true;};
        S::Result result;
        if(entry==0)result=shell.classify(on,mutate);
        else if(entry==1)result=shell.classifyRay(on,P{{std::ldexp(1.0,1023),1,1}},mutate);
        else
        {
            S::PreparedShell fresh;
            require(!fresh.prepare(segment.points,segment.triangles,mutate),"callback FP prepare admitted unsupported mode");
            result=fresh.classify(on,[](){return true;});
        }
        require(calls>0,"callback FP mutation never invoked");
        require(!S::supportedFloatingEnvironment(),"callback FP mode was silently corrected");
        require(!result.known,"callback FP exact ON emitted known degree");
        std::cout<<"CALLBACK_FP\t"<<entry<<'\t'<<calls<<'\t'<<result.known<<'\t'<<int(result.refusal)<<'\n';
        ++callbackFloatingEnvironmentControls;
    }
    require(S::supportedFloatingEnvironment(),"callback FP environment restored");
    require(!shell.classify(on,[](){return true;}).known,"restored cache exact ON must refuse");
    P off=on;off[1]=std::nextafter(off[1],1.0);
    const auto recovered=shell.classify(off,[](){return true;});
    require(recovered.known&&recovered.degree==0,"same cache unusable after callback FP restore");
    std::cout<<"CALLBACK_FP_CACHE_RECOVERED\t"<<recovered.known<<'\t'<<recovered.degree<<'\n';
#endif
}

int main(int argc,char** argv)
{
    try
    {
        require(S::supportedFloatingEnvironment(),"default floating environment");
        // Analytic/random controls on valid closed, inward, repeated, opposite
        // and geometrically self-intersecting closed cycles. Integer degree
        // checks distinguish doubled=2 from parity zero, inward=-1 from zero.
        Mesh normal;cube(normal,-1,1);
        Mesh inward;cube(inward,-1,1,true);
        Mesh doubled;cube(doubled,-1,1);cube(doubled,-1,1);
        Mesh canceled;cube(canceled,-1,1);cube(canceled,-1,1,true);
        Mesh crossing;cube(crossing,-1,1);cube(crossing,0.25,1.75);
        std::uint64_t seed=0x73a619c045e12b6full;
        auto random=[&](){seed=seed*6364136223846793005ull+1442695040888963407ull;return double(seed>>11)/9007199254740992.0*4.0-2.0;};
        const Mesh* meshes[]={&normal,&inward,&doubled,&canceled,&crossing};
        const char* names[]={"closed","inward","doubled","canceled","selfintersecting-cycles"};
        for(unsigned kind=0;kind<5;++kind)
        {
            S::PreparedShell shell;require(shell.prepare(meshes[kind]->points,meshes[kind]->triangles,[](){return true;}),std::string(names[kind])+" certify");
            for(unsigned sample=0;sample<128;++sample)
            {
                P q{{random(),random(),random()}};const int one=insideBox(q,-1,1)?1:0;
                const int expected=kind==0?one:(kind==1?-one:(kind==2?2*one:(kind==3?0:one+(insideBox(q,0.25,1.75)?1:0))));
                compare(names[kind],*meshes[kind],shell,q,expected);
            }
            const int center=kind==1?-1:(kind==2?2:(kind==3?0:1));
            compare(names[kind],*meshes[kind],shell,P{{0,0,0}},center);
        }
        Mesh large;cube(large,-1,1,false,8);S::PreparedShell largeShell;
        require(largeShell.prepare(large.points,large.triangles,[](){return true;}),"large certify");
        for(unsigned sample=0;sample<64;++sample)
        {
            P q{{random()/3,random()/3,random()/3}};compare("tessellated",large,largeShell,q,1);
            S::Stats stats;require(largeShell.classify(q,[](){return true;},&stats).known,"large known");
            require(stats.triangles<large.triangles.size()/4,"slender BVH did not cull most triangle candidates");
        }
        S::PreparedShell shell;require(shell.prepare(normal.points,normal.triangles,[](){return true;}),"normal prepare");
        floatingModeControls(normal,shell);
        callbackFloatingModeControl();
        const auto graze=shell.classifyRay(P{{0,0,0}},P{{2,0,0}},[](){return true;});
        require(!graze.known&&graze.refusal==S::Refusal::ambiguous,"edge ray must refuse");
        require(shell.classify(P{{0,0,0}},[](){return true;}).known,"deterministic alternate ray must be positive");
        require(!shell.classify(P{{1,0.2,0.3}},[](){return true;}).known,"point on actual surface must refuse");
        require(!shell.classifyRay(P{{0,0,0}},P{{0.5,0.3,0.1}},[](){return true;}).known,"inside endpoint must refuse");
        require(!shell.classify(P{{0,0,0}},[](){return false;}).known,"query clock refusal");
        require(!shell.classify(P{{0,0,0}},[]()->bool{throw std::runtime_error("clock");}).known,"throwing query clock refusal");
        P poison{{std::numeric_limits<double>::quiet_NaN(),0,0}};
        require(!shell.classify(poison,[](){return true;}).known,"nonfinite query refusal");
        S::PreparedShell noClock;require(!noClock.prepare(normal.points,normal.triangles,[](){return false;}),"prepare clock refusal");
        auto open=normal;open.triangles.pop_back();refuse("open",open);
        auto reversed=normal;std::swap(reversed.triangles[0].vertices[1],reversed.triangles[0].vertices[2]);refuse("one reversed face",reversed);
        auto invalid=normal;invalid.triangles[0].vertices[0]=std::numeric_limits<std::uint64_t>::max();refuse("invalid point id",invalid);
        auto duplicate=normal;duplicate.triangles[1].originalTriangle=duplicate.triangles[0].originalTriangle;refuse("duplicate original identity",duplicate);
        auto sharedDouble=normal;
        for(auto t:normal.triangles){t.originalTriangle=sharedDouble.triangles.size();sharedDouble.triangles.push_back(t);}refuse("shared-id double not 2-cycle",sharedDouble);
        auto nonfinite=normal;nonfinite.points[0][0]=std::numeric_limits<double>::infinity();refuse("nonfinite vertex",nonfinite);
        degenerateControls(normal);
        S::PreparedShell limited;S::Limits limits;limits.triangles=1;
        require(!limited.prepare(normal.points,normal.triangles,[](){return true;},limits),"prepare capacity refusal");
        limits=S::Limits();limits.queryTriangles=1;
        require(limited.prepare(normal.points,normal.triangles,[](){return true;},limits),"limited prepare");
        const auto capped=limited.classify(P{{0.1,0.2,0.3}},[](){return true;});
        require(!capped.known&&capped.refusal==S::Refusal::capacity,"query capacity refusal");
        // Optional actual final-prepared source41 fixture. This format is an
        // explicit vertex/index snapshot, never raw STL pretend-welded data.
        // The fixture provider must bind prepared source41 surface/shell IDs
        // and original fullsum order in a separate receipt before execution.
        if(argc>1)
        {
            std::ifstream f(argv[1]);require(bool(f),"fixture open");std::size_t np=0,nt=0,nq=0;f>>np>>nt>>nq;require(bool(f),"fixture header");
            require(np>0&&nt>0&&nq>0&&np<=2097152&&nt<=1048576&&nq<=256,"fixture size");Mesh actual;
            actual.points.resize(np);actual.triangles.resize(nt);
            for(auto& p:actual.points)require(bool(f>>p[0]>>p[1]>>p[2]),"fixture point truncated");
            for(auto& t:actual.triangles)require(bool(f>>t.vertices[0]>>t.vertices[1]>>t.vertices[2]>>t.surface>>t.originalTriangle),"fixture triangle truncated");
            S::PreparedShell prepared;require(prepared.prepare(actual.points,actual.triangles,[](){return true;}),"actual fixture certificate");
            for(std::size_t i=0;i<nq;++i)
            {
                P q;require(bool(f>>q[0]>>q[1]>>q[2]),"fixture query truncated");++actualQueries;
                const auto fast=prepared.classify(q,[](){return true;});const double old=fullWinding(actual,q);
                std::cout<<std::setprecision(17)<<"ACTUAL\t"<<i<<'\t'<<q[0]<<'\t'<<q[1]<<'\t'<<q[2]<<'\t'<<fast.known<<'\t'<<fast.degree<<'\t'<<old<<'\t'<<int(std::abs(old)>0.5)<<'\n';
                require(std::isfinite(old),"actual fullsum nonfinite");
                if(fast.known)
                {
                    ++actualKnown;maximumActualDegreeError=std::max(maximumActualDegreeError,std::abs(old-double(fast.degree)));
                    require((std::abs(double(fast.degree))>0.5)==(std::abs(old)>0.5),"actual side mismatch");
                }
                else ++actualUnknown;
            }
            require(actualKnown>0,"actual fixture no positive known classifications");
            std::cout<<"ACTUAL_ZERO_AREA\t"<<prepared.zeroAreaTriangles()<<'\n';
            // Supplemental ON/OFF diagnostic queries derived only from saved
            // final vertices; original query prefix and geometry stay intact.
            for(const auto& t:actual.triangles)
            {
                const std::function<bool()> yes=[](){return true;};S::detail::Budget budget{yes};
                const auto& a=actual.points[t.vertices[0]];const auto& b=actual.points[t.vertices[1]];const auto& c=actual.points[t.vertices[2]];
                const auto area=S::detail::areaSign(a,b,c,budget);
                if(area.known&&!area.value)
                {
                    auditDegenerate("actual derived ON vertex",actual,prepared,a,0,true);
                    P off=a;unsigned d=0;
                    while(d<3&&a[d]!=b[d])++d;
                    if(d==3)d=0;
                    off[d]+=1e-6;
                    const auto fast=prepared.classify(off,yes);const double old=fullWinding(actual,off);
                    std::cout<<std::setprecision(17)<<"ACTUAL_DERIVED_OFF\t"<<off[0]<<'\t'<<off[1]<<'\t'<<off[2]<<'\t'<<fast.known<<'\t'<<fast.degree<<'\t'<<old<<'\n';
                    require(std::isfinite(old),"actual derived off fullsum nonfinite");
                    if(fast.known)require((std::abs(double(fast.degree))>0.5)==(std::abs(old)>0.5),"actual derived off side mismatch");
                    break;
                }
            }
        }
        std::cout<<std::setprecision(17)<<"{\"status\":\"PASS\",\"analyticComparisons\":"<<comparisons
          <<",\"known\":"<<known<<",\"unknown\":"<<unknown<<",\"maximumFullsumDegreeError\":"<<maximumDegreeError
          <<",\"floatingEnvironmentRefusalControls\":"<<floatingEnvironmentControls
          <<",\"callbackFloatingEnvironmentRefusalControls\":"<<callbackFloatingEnvironmentControls
          <<",\"actualQueries\":"<<actualQueries<<",\"actualKnown\":"<<actualKnown<<",\"actualUnknown\":"<<actualUnknown
          <<",\"maximumActualDegreeError\":"<<maximumActualDegreeError
          <<",\"degenerateComparisons\":"<<degenerateComparisons<<",\"degenerateOriginalSideDifferences\":"<<degenerateOriginalSideDifferences
          <<",\"bitEqualityClaim\":false,\"nativeOrWhole\":false}\n";
        return 0;
    }
    catch(const std::exception& e)
    {std::cerr<<"CONTROL FAILURE: "<<e.what()<<"\n";return 1;}
}
