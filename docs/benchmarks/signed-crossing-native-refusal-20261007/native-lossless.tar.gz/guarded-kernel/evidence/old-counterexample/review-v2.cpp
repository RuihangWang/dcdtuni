
#include "dcCartSignedCrossing.H"
#include <iostream>
#include <iomanip>
#include <cmath>
namespace S=dcCartSignedCrossing;
using P=S::Point;
int main()
{
    const unsigned original=_mm_getcsr();
    const double big=std::ldexp(1.0,1022),small=std::ldexp(1.0,-1021);
    std::vector<P> p={P{{0,0,0}},P{{big,small,0}}};
    S::Triangle t;t.vertices={{0,1,0}};
    S::PreparedShell shell;
    const bool prepared=shell.prepare(p,{t},[](){return true;});
    const P on{{std::ldexp(1.0,1019),std::ldexp(1.0,-1024),0}};
    const auto stable=shell.classify(on,[](){return true;});
    unsigned calls=0;
    const auto dynamic=shell.classify(on,[&](){++calls;_mm_setcsr(original|(1u<<6));return true;});
    _mm_setcsr(original);
    P off=on;off[1]=std::nextafter(on[1],1.0);
    const auto nearby=shell.classify(off,[](){return true;});
    S::Limits limits;limits.queryVisits=0;
    S::PreparedShell capped;const bool capPrepared=capped.prepare(p,{t},[](){return true;},limits);
    const auto cap=capped.classify(on,[](){return true;});
    std::cout<<std::setprecision(17)
      <<"{\"prepared\":"<<prepared<<",\"zeroAreaTriangles\":"<<shell.zeroAreaTriangles()
      <<",\"q\":["<<on[0]<<","<<on[1]<<",0]"
      <<",\"stableOnKnown\":"<<stable.known<<",\"stableOnRefusal\":"<<int(stable.refusal)
      <<",\"dynamicDazKnown\":"<<dynamic.known<<",\"dynamicDazDegree\":"<<dynamic.degree
      <<",\"dynamicDazRefusal\":"<<int(dynamic.refusal)<<",\"callbackCalls\":"<<calls
      <<",\"nextafterOffKnown\":"<<nearby.known<<",\"nextafterOffDegree\":"<<nearby.degree
      <<",\"capPrepared\":"<<capPrepared<<",\"capKnown\":"<<cap.known
      <<",\"capRefusal\":"<<int(cap.refusal)<<",\"restoredEnvironment\":"<<S::supportedFloatingEnvironment()<<"}\n";
    return (prepared&&!stable.known&&nearby.known&&nearby.degree==0&&capPrepared&&!cap.known&&S::supportedFloatingEnvironment())?0:2;
}
