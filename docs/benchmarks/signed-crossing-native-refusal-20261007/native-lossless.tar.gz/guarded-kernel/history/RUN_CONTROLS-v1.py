#!/usr/bin/env python3
"""Explicit CPU standalone controls; never starts OpenFOAM/native/whole/services."""
import argparse,hashlib,json,os,signal,subprocess,time
from pathlib import Path
B=Path('/mnt/lv/home/litianyu/mycode/dcdtuni').resolve()
p=argparse.ArgumentParser()
p.add_argument('--output',required=True)
p.add_argument('--compiler',default='g++')
p.add_argument('--fixture')
a=p.parse_args();F=Path(__file__).resolve().parent
out=Path(a.output).resolve()
if B not in out.parents or out.exists():raise SystemExit('output must be fresh and inside dcdtuni')
out.mkdir(parents=True);tmp=out/'tmp';tmp.mkdir()
manifest=json.loads((F/'MANIFEST.json').read_text())
for x in manifest['files']:
 q=F/x['path'];data=q.read_bytes()
 if q.is_symlink() or len(data)!=x['bytes'] or hashlib.sha256(data).hexdigest()!=x['sha256']:
  raise SystemExit('frozen input mismatch '+x['path'])
env=os.environ.copy();env.update(TMPDIR=str(tmp),TMP=str(tmp),TEMP=str(tmp),CUDA_VISIBLE_DEVICES='',OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2')
receipt={'scope':'standalone CPU only; no native/whole/services/GPU','manifestSha256':hashlib.sha256((F/'MANIFEST.json').read_bytes()).hexdigest(),'commands':[], 'sourceInputs':[x for x in manifest['files'] if x['path'].startswith(('after/','controls/'))]}
def run(name,argv,timeout,expected=0,required_error=None):
 start=time.monotonic()
 with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:
  child=subprocess.Popen(argv,cwd=out,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
  timed=False
  try:rc=child.wait(timeout=timeout)
  except subprocess.TimeoutExpired:
   timed=True
   try:os.killpg(child.pid,signal.SIGTERM)
   except ProcessLookupError:pass
   try:rc=child.wait(timeout=3)
   except subprocess.TimeoutExpired:
    try:os.killpg(child.pid,signal.SIGKILL)
    except ProcessLookupError:pass
    rc=child.wait()
 receipt['commands'].append({'name':name,'argv':argv,'returncode':rc,'timedOut':timed,'expectedReturncode':expected,'elapsedSeconds':time.monotonic()-start})
 (out/'RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n')
 if rc!=expected or timed:raise SystemExit(name+' failed; see owned raw logs')
 if required_error and required_error not in (out/(name+'.stderr')).read_text():raise SystemExit(name+' lacked expected refusal reason')
run('compiler-version',[a.compiler,'--version'],10)
binary=out/'signed-crossing-controls'
argv=[a.compiler,'-std=c++14','-O2','-fno-fast-math','-ffp-contract=off','-frounding-math','-Wall','-Wextra','-Werror',
      '-I'+str(F/'after/src/mesh/dcCartMesh/dcCartSurfaces'),str(F/'controls/signed_crossing_controls.cpp'),'-o',str(binary)]
run('compile',argv,60)
argv=[str(binary)]
if a.fixture:
 fixture=Path(a.fixture).resolve()
 if B not in fixture.parents or fixture.is_symlink():raise SystemExit('fixture must be owned by-value in dcdtuni')
 receipt['fixture']={'path':str(fixture),'bytes':fixture.stat().st_size,'sha256':hashlib.sha256(fixture.read_bytes()).hexdigest(),'preparedProducerBindingRequired':True}
 argv.append(str(fixture))
run('controls',argv,60)
# Pure malformed indexed snapshots; no real case or prepared identity claim.
points=[[-1,-1,-1],[1,-1,-1],[1,1,-1],[-1,1,-1],[-1,-1,1],[1,-1,1],[1,1,1],[-1,1,1]]
triangles=[[0,2,1],[0,3,2],[4,5,6],[4,6,7],[0,4,7],[0,7,3],[1,2,6],[1,6,5],[0,1,5],[0,5,4],[3,7,6],[3,6,2]]
point_text=''.join(' '.join(map(str,p))+'\n' for p in points)
triangle_text=''.join(' '.join(map(str,t))+' 0 '+str(i)+'\n' for i,t in enumerate(triangles))
negative=[('header','missing\n','fixture header'),('zero-size','0 0 0\n','fixture size'),
          ('point','8 12 1\n','fixture point truncated'),
          ('triangle','8 12 1\n'+point_text,'fixture triangle truncated'),
          ('query','8 12 1\n'+point_text+triangle_text,'fixture query truncated'),
          ('invalid-id','8 12 1\n'+point_text+triangle_text.replace('0 2 1 0 0','18446744073709551615 2 1 0 0',1)+'0.1 0.2 0.3\n','actual fixture certificate')]
for name,content,reason in negative:
 fixture=out/('negative-'+name+'.fixture');fixture.write_text(content)
 run('negative-'+name,[str(binary),str(fixture)],10,1,reason)
receipt['negativeFixtureControls']=len(negative)
(out/'RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
