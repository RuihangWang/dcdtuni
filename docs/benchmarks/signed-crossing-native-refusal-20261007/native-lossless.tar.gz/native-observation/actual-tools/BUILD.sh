#!/bin/bash
set -eo pipefail
cd "$(dirname "$0")/.."
source ./env.sh
[ "$WM_PROJECT_VERSION" = "v2412" ]
[ "$WM_PRECISION_OPTION" = "DP" ]
[ "$WM_OPTIONS" = "linux64GccDPInt32Opt" ]
export WM_NCOMPPROCS=2
export DCCART_OWNED_SOURCE_ROOT="$PWD"
printf 'OWNED_CONTEXT WM_OPTIONS=%s CONDA_PREFIX=%s FOAM_USER_LIBBIN=%s\n' "$WM_OPTIONS" "$CONDA_PREFIX" "$FOAM_USER_LIBBIN"
./Allwmake --cart-only -j 2
cd .codex-tools/prepared-probe
wmake -j 2
