#!/bin/bash
set -eo pipefail
cd "$(dirname "$0")/.."
source ./env.sh
export DCCART_OWNED_SOURCE_ROOT="$PWD"
python -B - <<'PY'
import os,json
print(json.dumps({k:os.environ.get(k,'') for k in ['WM_PROJECT_DIR','LIB_SRC','FOAM_LIBBIN','FOAM_USER_LIBBIN','FOAM_USER_APPBIN','WM_OPTIONS','WM_PRECISION_OPTION','WM_PROJECT_VERSION','WM_COMPILER','CONDA_PREFIX','LD_LIBRARY_PATH','DCCART_OWNED_SOURCE_ROOT']},indent=2))
PY
