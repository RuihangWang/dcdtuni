#!/bin/bash
set -eo pipefail
cd "$(dirname "$0")/.."
source ./env.sh
[ "$WM_OPTIONS" = linux64GccDPInt32Opt ]
[ "$WM_PRECISION_OPTION" = DP ]
export CUDA_VISIBLE_DEVICES=
export WM_NCOMPPROCS=2
export TMPDIR="$PWD/.codex-tmp"
export TMP="$TMPDIR"
export TEMP="$TMPDIR"
export XDG_CACHE_HOME="$PWD/.cache"
python -B "/mnt/lv/home/litianyu/mycode/dcdtuni/.codex-tmp/fresh-clone-actual-20261007/dcdtuni/.codex-tmp/carve-signed-crossing-private-v1/exact-degenerate-private-v1/FROZEN-OWNED-PLAN-v3/RUN_OWNED_PROBE.py" --owned-build "/mnt/lv/home/litianyu/mycode/dcdtuni/.codex-tmp/fresh-clone-actual-20261007/dcdtuni/.codex-tmp/carve-signed-crossing-private-v1/exact-degenerate-private-v1/owned-build-v3" --build-receipt "/mnt/lv/home/litianyu/mycode/dcdtuni/.codex-tmp/fresh-clone-actual-20261007/dcdtuni/.codex-tmp/carve-signed-crossing-private-v1/exact-degenerate-private-v1/build-evidence-v3/COMPILED_BUILD_RECEIPT.json" --probe-bin "/mnt/lv/home/litianyu/mycode/dcdtuni/.codex-tmp/fresh-clone-actual-20261007/dcdtuni/.codex-tmp/carve-signed-crossing-private-v1/exact-degenerate-private-v1/owned-build-v3/platforms/linux64GccDPInt32Opt/bin/dcCartOwnedPreparedProbe" --lib-bin "/mnt/lv/home/litianyu/mycode/dcdtuni/.codex-tmp/fresh-clone-actual-20261007/dcdtuni/.codex-tmp/carve-signed-crossing-private-v1/exact-degenerate-private-v1/owned-build-v3/platforms/linux64GccDPInt32Opt/lib/libdcCartMesh.so" --case "/mnt/lv/home/litianyu/mycode/dcdtuni/.codex-tmp/fresh-clone-actual-20261007/dcdtuni/.codex-tmp/carve-signed-crossing-private-v1/exact-degenerate-private-v1/probe-input-stage23eef-v3/case/Mesh" --output "/mnt/lv/home/litianyu/mycode/dcdtuni/.codex-tmp/fresh-clone-actual-20261007/dcdtuni/.codex-tmp/carve-signed-crossing-private-v1/exact-degenerate-private-v1/prepared-probe-actual-v3" --shells 6 7 --timeout 60
