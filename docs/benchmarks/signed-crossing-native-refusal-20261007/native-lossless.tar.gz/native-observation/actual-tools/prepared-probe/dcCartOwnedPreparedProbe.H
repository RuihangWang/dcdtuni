#include "Pstream.H"
#include <fstream>
#include <iomanip>
#include <sstream>
#include <stdexcept>
#include <cstdlib>
#include <algorithm>
#include <cmath>
#include <functional>
#include <cfenv>
#include <vector>
#include <string>
namespace dcCartOwnedPreparedProbe
{
std::vector<Foam::label> selected(const char* text,Foam::label count)
{
    std::vector<Foam::label> result;
    if(!text||!*text)throw std::runtime_error("explicit shell list required");
    std::stringstream in(text);std::string item;
    while(std::getline(in,item,','))
    {
        if(item.empty())throw std::runtime_error("empty shell index");
        char* end=nullptr;const long value=std::strtol(item.c_str(),&end,10);
        if(!end||*end||value<0||value>=count||result.size()>=8)throw std::runtime_error("invalid bounded shell selection");
        const Foam::label sh=Foam::label(value);
        if(std::find(result.begin(),result.end(),sh)!=result.end())throw std::runtime_error("duplicate shell index");
        result.push_back(sh);
    }
    if(result.empty())throw std::runtime_error("empty shell selection");
    return result;
}
void run(const Foam::dcCartSurfaces& surfaces,const char* directory,const char* shells,
         const std::function<bool()>& available)
{
    if(Foam::Pstream::parRun())throw std::runtime_error("owned prepared probe must be serial");
    const auto selection=selected(shells,surfaces.nSolidShells());
    std::ifstream maps("/proc/self/maps");
    std::ofstream ownedMaps(std::string(directory)+"/loaded-modules.maps");
    if(!maps||!ownedMaps)throw std::runtime_error("owned runtime library map required");
    ownedMaps<<maps.rdbuf();
    if(!ownedMaps)throw std::runtime_error("owned runtime map write");
    std::ofstream summary(std::string(directory)+"/API_COMPARISONS.tsv");
    if(!summary)throw std::runtime_error("owned pre-created output required");
    summary<<std::setprecision(17)<<"shell\tquery\tgeometryEpoch\tmembershipEpoch\tclosed\tknown\tdegree\tfullsum\toldside\tfastside\n";
    std::ofstream floating(std::string(directory)+"/FP_ENVIRONMENT.tsv");
    if(!floating)throw std::runtime_error("owned floating-mode receipt open");
    floating<<"stage\tshell\tquery\tC_rounding\tMXCSR\tsupported\n";
    const auto recordFloating=[&](const char* stage,Foam::label sh,long query)
    {
        long csr=-1;
#if defined(__x86_64__) && defined(__SSE__)
        csr=static_cast<long>(_mm_getcsr());
#endif
        floating<<stage<<'\t'<<sh<<'\t'<<query<<'\t'<<std::fegetround()<<'\t'<<csr<<'\t'
          <<dcCartSignedCrossing::supportedFloatingEnvironment()<<'\n';
        if(!floating)throw std::runtime_error("owned floating-mode receipt write");
    };
    recordFloating("entry",-1,-1);
    for(const auto sh:selection)
    {
        if(!available())throw std::runtime_error("probe clock exhausted");
        Foam::dcCartSurfaces::preparedShellSnapshot snapshot;
        if(!surfaces.solidShellPreparedSnapshot(sh,snapshot,available))throw std::runtime_error("prepared snapshot rejected");
        const auto& bb=surfaces.solidShellBounds(sh);
        std::vector<Foam::point> queries;
        const double fractions[5][3]={{0.5,0.5,0.5},{0.23,0.41,0.67},{0.73,0.31,0.19},{0.11,0.89,0.37},{0.61,0.17,0.83}};
        for(const auto& f:fractions)
        {
            Foam::point p;for(Foam::direction d=0;d<3;++d)p[d]=bb.min()[d]+f[d]*(bb.max()[d]-bb.min()[d]);queries.push_back(p);
        }
        queries.push_back(bb.max()+Foam::vector(1,1,1));
        // Explicit diagnostic query points derived from original final facets;
        // this does not perturb native carver points or alter prepared geometry.
        for(std::size_t ti:{std::size_t(0),snapshot.triangles.size()/2,snapshot.triangles.size()-1})
        {
            const auto& t=snapshot.triangles[ti];
            const auto& pa=snapshot.points[t.vertices[0]];
            const auto& pb=snapshot.points[t.vertices[1]];
            const auto& pc=snapshot.points[t.vertices[2]];
            const Foam::point a(pa[0],pa[1],pa[2]),b(pb[0],pb[1],pb[2]),c(pc[0],pc[1],pc[2]);
            Foam::vector n=(b-a)^(c-a);const Foam::scalar length=Foam::mag(n);
            if(!std::isfinite(length)||length==0)continue;
            n/=length;const Foam::point centre=(a+b+c)/3.0;
            const Foam::scalar distance=std::max(Foam::scalar(1e-5),Foam::mag(bb.span())*1e-4);
            queries.push_back(centre+distance*n);queries.push_back(centre-distance*n);
        }
        const std::string stem=std::string(directory)+"/shell-"+std::to_string(sh);
        std::ofstream fixture(stem+".fixture"),bindings(stem+".bindings.tsv");
        std::ofstream bits(stem+".coordinates.bits",std::ios::binary);
        if(!fixture||!bindings||!bits)throw std::runtime_error("owned snapshot output open");
        fixture<<std::setprecision(17)<<snapshot.points.size()<<' '<<snapshot.triangles.size()<<' '<<queries.size()<<'\n';
        bindings<<"geometryEpoch "<<snapshot.geometryEpoch<<" membershipEpoch "<<snapshot.membershipEpoch<<" surface "<<snapshot.surface<<'\n';
        for(std::size_t i=0;i<snapshot.points.size();++i)
        {
            const auto& p=snapshot.points[i];fixture<<p[0]<<' '<<p[1]<<' '<<p[2]<<'\n';
            bits.write(reinterpret_cast<const char*>(p.data()),3*sizeof(double));
            bindings<<"point "<<i<<' '<<snapshot.originalPointIds[i]<<'\n';
        }
        for(std::size_t i=0;i<snapshot.triangles.size();++i)
        {
            const auto& t=snapshot.triangles[i];
            fixture<<t.vertices[0]<<' '<<t.vertices[1]<<' '<<t.vertices[2]<<' '<<t.surface<<' '<<t.originalTriangle<<'\n';
            bindings<<"triangle "<<i<<' '<<t.surface<<' '<<t.originalTriangle<<' '<<snapshot.localRegions[i]<<'\n';
        }
        std::size_t known=0;
        for(std::size_t i=0;i<queries.size();++i)
        {
            if(!available())throw std::runtime_error("probe query clock exhausted");
            const auto& q=queries[i];fixture<<q.x()<<' '<<q.y()<<' '<<q.z()<<'\n';
            Foam::scalar degree=0;
            recordFloating("before-api",sh,static_cast<long>(i));
            const bool fast=surfaces.solidShellWindingDegree(sh,q,degree,available);
            recordFloating("after-api",sh,static_cast<long>(i));
            const Foam::scalar old=surfaces.solidShellWinding(sh,q);
            recordFloating("after-fullsum",sh,static_cast<long>(i));
            if(!std::isfinite(old))throw std::runtime_error("original fullsum nonfinite");
            const int oldside=std::abs(old)>0.5?-1:1;
            const int fastside=fast?(std::abs(degree)>0.5?-1:1):0;
            summary<<sh<<'\t'<<i<<'\t'<<snapshot.geometryEpoch<<'\t'<<snapshot.membershipEpoch<<'\t'
              <<surfaces.solidShellClosed(sh)<<'\t'<<fast<<'\t'<<degree<<'\t'<<old<<'\t'<<oldside<<'\t'<<fastside<<'\n';
            if(fast){++known;if(oldside!=fastside)throw std::runtime_error("actual prepared known-side mismatch");}
        }
        if(!fixture||!bindings||!bits||!summary)throw std::runtime_error("snapshot output write failure");
        if(surfaces.solidShellClosed(sh)&&!known)throw std::runtime_error("closed actual shell has no known positive query");
    }
}
}
