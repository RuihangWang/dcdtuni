import os,sys,json,hashlib,time,subprocess,signal
from pathlib import Path
sys.dont_write_bytecode=True
F=Path(__file__).resolve().parent;A=F.parent;C=F/'source42';R=A/'owned-build-v3';E=A/'build-evidence-v3'
D=A.parents[2];PREFIX=D/'.codex-tmp/envs/dcdtuni';CONDA='/mnt/lv/home/litianyu/miniconda3/bin/conda'
assert D.name=='dcdtuni' and PREFIX.is_dir()
assert not R.exists() and not E.exists();R.mkdir();E.mkdir();tmp=R/'.codex-tmp';tmp.mkdir();cache=R/'.cache';cache.mkdir()
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
freeze=json.loads((F/'MANIFEST.json').read_text())
for x in freeze['files']:
 q=F/x['path'];assert q.stat().st_size==x['bytes'] and sha(q)==x['sha256']
inputs=json.loads((F/'CANDIDATE_SOURCE_INPUTS.json').read_text())['files']
for x in inputs:
 q=C/x['path'];assert not q.is_symlink() and sha(q)==x['sha256'];dest=R/x['path'];dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(q.read_bytes())
(R/'Allwmake').chmod(0o755)
tool=R/'.codex-tools/prepared-probe'
for q in (F/'tools/prepared-probe').rglob('*'):
 if q.is_file():
  dest=tool/q.relative_to(F/'tools/prepared-probe');dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(q.read_bytes())
script=R/'.codex-tools/BUILD.sh'
script.write_text('''#!/bin/bash
set -eo pipefail
cd "$(dirname "$0")/.."
source ./env.sh
[ "$WM_PROJECT_VERSION" = "v2412" ]
[ "$WM_PRECISION_OPTION" = "DP" ]
[ "$WM_OPTIONS" = "linux64GccDPInt32Opt" ]
export WM_NCOMPPROCS=2
export DCCART_OWNED_SOURCE_ROOT="$PWD"
printf 'OWNED_CONTEXT WM_OPTIONS=%s CONDA_PREFIX=%s FOAM_USER_LIBBIN=%s\\n' "$WM_OPTIONS" "$CONDA_PREFIX" "$FOAM_USER_LIBBIN"
./Allwmake --cart-only -j 2
cd .codex-tools/prepared-probe
wmake -j 2
''')
env=os.environ.copy()
for k in list(env):
 if k.startswith(('WM_','FOAM_','SNAPPY_','DC_CART_')) or k in ['CONDA_PREFIX','CONDA_DEFAULT_ENV','CONDA_SHLVL']:env.pop(k,None)
env.update(PATH='/usr/bin:/bin:/usr/sbin:/sbin',LD_LIBRARY_PATH='',TMPDIR=str(tmp),TMP=str(tmp),TEMP=str(tmp),XDG_CACHE_HOME=str(cache),CUDA_VISIBLE_DEVICES='',WM_NCOMPPROCS='2',OMP_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',MKL_NUM_THREADS='2')
argv=[CONDA,'run','--no-capture-output','-p',str(PREFIX),'bash','--noprofile','--norc',str(script)]
receipt={'scope':'fresh42 source41+exact-degenerate pair/probe clean build; no whole/services/GPU','freezeManifestSha256':sha(F/'MANIFEST.json'),'sourceInputs':inputs,'ownedBuildRoot':str(R),'officialFreshPrefix':str(PREFIX),'argv':argv,'affinity':sorted(os.sched_getaffinity(0)),'jobs':2,'CUDA_VISIBLE_DEVICES':'','startedUnix':time.time()}
with (E/'build.stdout').open('wb') as stdout,(E/'build.stderr').open('wb') as stderr:
 child=subprocess.Popen(argv,cwd=R,env=env,stdout=stdout,stderr=stderr,start_new_session=True);receipt['ownedProcessGroup']=child.pid
 (E/'BUILD.live.json').write_text(json.dumps(receipt,indent=2)+'\n');start=time.monotonic();timed=False
 try:rc=child.wait(timeout=180)
 except subprocess.TimeoutExpired:
  timed=True
  try:os.killpg(child.pid,signal.SIGTERM)
  except ProcessLookupError:pass
  try:rc=child.wait(timeout=5)
  except subprocess.TimeoutExpired:
   try:os.killpg(child.pid,signal.SIGKILL)
   except ProcessLookupError:pass
   rc=child.wait()
receipt.update(returncode=rc,timedOut=timed,elapsedSeconds=time.monotonic()-start)
(E/'BUILD.result.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'returncode':rc,'timedOut':timed,'elapsedSeconds':receipt['elapsedSeconds'],'ownedBuildRoot':str(R),'evidence':str(E)},indent=2))
