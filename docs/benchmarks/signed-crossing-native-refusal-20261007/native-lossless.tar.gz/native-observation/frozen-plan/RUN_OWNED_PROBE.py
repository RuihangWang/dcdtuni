#!/usr/bin/env python3
"""CPU extraction only AFTER approved owned native pair/probe build; never builds."""
import argparse,hashlib,json,os,signal,struct,subprocess,time
from pathlib import Path
B=Path('/mnt/lv/home/litianyu/mycode/dcdtuni').resolve()
p=argparse.ArgumentParser()
p.add_argument('--owned-build',required=True);p.add_argument('--build-receipt',required=True)
p.add_argument('--probe-bin',required=True);p.add_argument('--lib-bin',required=True)
p.add_argument('--case',required=True);p.add_argument('--output',required=True)
p.add_argument('--shells',nargs='+',type=int,default=[6,7]);p.add_argument('--timeout',type=int,default=60)
a=p.parse_args();F=Path(__file__).resolve().parent
root=Path(a.owned_build).resolve();case=Path(a.case).resolve();out=Path(a.output).resolve()
app=Path(a.probe_bin).resolve();lib=Path(a.lib_bin).resolve();receiptPath=Path(a.build_receipt).resolve()
for q in [root,case,out,app,lib,receiptPath]:
 if B not in q.parents:raise SystemExit('all paths must stay inside dcdtuni')
if out.exists() or not 1<=a.timeout<=60:raise SystemExit('fresh output/timeout required')
if len(a.shells)>8 or len(set(a.shells))!=len(a.shells) or min(a.shells)<0:raise SystemExit('invalid bounded shell selection')
if root not in app.parents or root not in lib.parents or lib.name!='libdcCartMesh.so':raise SystemExit('app/lib must be owned by build root')
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
freeze=json.loads((F/'MANIFEST.json').read_text())
for x in freeze['files']:
 q=F/x['path']
 if q.is_symlink() or q.stat().st_size!=x['bytes'] or sha(q)!=x['sha256']:raise SystemExit('freeze input mismatch '+x['path'])
expected=json.loads((F/'CANDIDATE_SOURCE_INPUTS.json').read_text())['files']
for x in expected:
 q=root/x['path']
 if q.is_symlink() or sha(q)!=x['sha256']:raise SystemExit('actual owned source mismatch '+x['path'])
# This receipt must come from the actual clean build/dependency/ELF evidence,
# not from this extraction runner. Root reviews that provenance independently.
build=json.loads(receiptPath.read_text())
if build.get('borrowedProjectLibraries')!=0:raise SystemExit('build must prove zero borrowed project libraries')
inputs={x['path']:x['sha256'] for x in build['sourceInputs']}
if inputs!={x['path']:x['sha256'] for x in expected}:raise SystemExit('compiled source input closure mismatch')
for kind,q in [('probe',app),('lib',lib)]:
 item=build[kind]
 if Path(item['path']).resolve()!=q or item['sha256']!=sha(q):raise SystemExit('built '+kind+' identity mismatch')
caseInputs=[]
for relative in ['system','constant/triSurface']:
 directory=case/relative
 if not directory.is_dir():raise SystemExit('missing actual input '+relative)
 for q in sorted(directory.rglob('*')):
  if q.is_symlink():raise SystemExit('case input symlink forbidden '+str(q))
  if q.is_file():caseInputs.append({'path':str(q.relative_to(case)),'bytes':q.stat().st_size,'sha256':sha(q)})
out.mkdir();tmp=out/'tmp';tmp.mkdir();prepared=out/'prepared';prepared.mkdir();cache=out/'cache';cache.mkdir()
env=os.environ.copy();env.update(TMPDIR=str(tmp),TMP=str(tmp),TEMP=str(tmp),XDG_CACHE_HOME=str(cache),CUDA_VISIBLE_DEVICES='',OMP_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',MKL_NUM_THREADS='2',DCCART_OWNED_PREPARED_PROBE_DIR=str(prepared),DCCART_OWNED_PREPARED_PROBE_SHELLS=','.join(map(str,a.shells)))
env['LD_LIBRARY_PATH']=str(lib.parent)+os.pathsep+env.get('LD_LIBRARY_PATH','')
argv=[str(app),'-case',str(case),'-timeLimit',str(a.timeout)]
result={'scope':'actual final-prepared CPU extraction; no mesh/native whole/services/GPU','freezeManifestSha256':sha(F/'MANIFEST.json'),'buildReceiptSha256':sha(receiptPath),'caseInputs':caseInputs,'sourceInputs':expected,'probeSha256':sha(app),'libSha256':sha(lib),'argv':argv,'diagnosticEnvironment':{k:v for k,v in env.items() if k.startswith('DCCART_')},'shells':a.shells}
start=time.monotonic()
with (out/'probe.stdout').open('wb') as stdout,(out/'probe.stderr').open('wb') as stderr:
 child=subprocess.Popen(argv,cwd=out,env=env,stdout=stdout,stderr=stderr,start_new_session=True);timed=False
 try:rc=child.wait(timeout=a.timeout)
 except subprocess.TimeoutExpired:
  timed=True
  try:os.killpg(child.pid,signal.SIGTERM)
  except ProcessLookupError:pass
  try:rc=child.wait(timeout=3)
  except subprocess.TimeoutExpired:
   try:os.killpg(child.pid,signal.SIGKILL)
   except ProcessLookupError:pass
   rc=child.wait()
result.update(returncode=rc,timedOut=timed,elapsedSeconds=time.monotonic()-start)
(out/'RECEIPT.json').write_text(json.dumps(result,indent=2)+'\n')
if rc or timed:raise SystemExit('actual probe failed; preserve raw receipt and logs')
maps=(prepared/'loaded-modules.maps').read_text().splitlines()
project={Path(line.split()[-1]).resolve() for line in maps if 'libdcCartMesh.so' in line}
if project!={lib}:raise SystemExit('actual loaded project library does not match owned lib')
comparisons=(prepared/'API_COMPARISONS.tsv').read_text().splitlines();rows=[line.split('\t') for line in comparisons[1:]]
if not rows or {int(r[0]) for r in rows}!=set(a.shells):raise SystemExit('actual selected-shell comparison closure incomplete')
for r in rows:
 if int(r[5]) and int(r[8])!=int(r[9]):raise SystemExit('actual original/fast side mismatch')
for sh in a.shells:
 file=prepared/('shell-'+str(sh)+'.fixture');lines=file.read_text().splitlines();np,nt,nq=map(int,lines[0].split())
 points=[tuple(map(float,line.split())) for line in lines[1:1+np]]
 raw=b''.join(struct.pack('=ddd',*point) for point in points)
 if raw!=(prepared/('shell-'+str(sh)+'.coordinates.bits')).read_bytes():raise SystemExit('prepared DP point codec changed bytes')
 if len(lines)!=1+np+nt+nq:raise SystemExit('prepared fixture length mismatch')
 result.setdefault('snapshots',[]).append({'shell':sh,'points':np,'triangles':nt,'queries':nq,'fixtureSha256':sha(file),'coordinatesBitsSha256':sha(prepared/('shell-'+str(sh)+'.coordinates.bits')),'bindingsSha256':sha(prepared/('shell-'+str(sh)+'.bindings.tsv'))})
result.update(known=sum(int(r[5]) for r in rows),unknown=sum(not int(r[5]) for r in rows),originalFastSideDifferences=0,actualRuntimeLibraryVerified=True)
(out/'RECEIPT.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['scope','returncode','elapsedSeconds','known','unknown','originalFastSideDifferences','snapshots']},indent=2))
