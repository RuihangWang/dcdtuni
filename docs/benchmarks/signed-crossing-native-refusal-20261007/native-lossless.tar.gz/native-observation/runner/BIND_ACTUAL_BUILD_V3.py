import sys,os,json,hashlib,subprocess,re
from pathlib import Path
sys.dont_write_bytecode=True
A=Path(__file__).resolve().parent;R=A/'owned-build-v3';E=A/'build-evidence-v3';F=A/'FROZEN-OWNED-PLAN-v3';D=A.parents[2];P=D/'.codex-tmp/envs/dcdtuni';CONDA='/mnt/lv/home/litianyu/miniconda3/bin/conda';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
inputs=json.loads((F/'CANDIDATE_SOURCE_INPUTS.json').read_text())['files']
for x in inputs:assert sha(R/x['path'])==x['sha256']
script=R/'.codex-tools/INSPECT-BUILD.sh'
script.write_text('''#!/bin/bash
set -eo pipefail
cd "$(dirname "$0")/.."
source ./env.sh
export DCCART_OWNED_SOURCE_ROOT="$PWD"
python -B - <<'PY'
import os,json
print(json.dumps({k:os.environ.get(k,'') for k in ['WM_PROJECT_DIR','LIB_SRC','FOAM_LIBBIN','FOAM_USER_LIBBIN','FOAM_USER_APPBIN','WM_OPTIONS','WM_PRECISION_OPTION','WM_PROJECT_VERSION','WM_COMPILER','CONDA_PREFIX','LD_LIBRARY_PATH','DCCART_OWNED_SOURCE_ROOT']},indent=2))
PY
''')
env=os.environ.copy()
for k in list(env):
 if k.startswith(('WM_','FOAM_','SNAPPY_','DC_CART_')) or k in ['CONDA_PREFIX','CONDA_DEFAULT_ENV','CONDA_SHLVL']:env.pop(k,None)
env.update(PATH='/usr/bin:/bin:/usr/sbin:/sbin',LD_LIBRARY_PATH='',TMPDIR=str(R/'.codex-tmp'),TMP=str(R/'.codex-tmp'),TEMP=str(R/'.codex-tmp'),XDG_CACHE_HOME=str(R/'.cache'),CUDA_VISIBLE_DEVICES='',OMP_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',MKL_NUM_THREADS='2')
r=subprocess.run([CONDA,'run','--no-capture-output','-p',str(P),'bash','--noprofile','--norc',str(script)],env=env,cwd=R,capture_output=True,timeout=30);(E/'inspect-build.stdout').write_bytes(r.stdout);(E/'inspect-build.stderr').write_bytes(r.stderr);assert r.returncode==0
context=json.loads(r.stdout[r.stdout.index(b'{'):]);assert context['WM_OPTIONS']=='linux64GccDPInt32Opt' and context['WM_PRECISION_OPTION']=='DP' and Path(context['CONDA_PREFIX'])==P
(E/'ACTUAL_CONTEXT.json').write_text(json.dumps(context,indent=2)+'\n');inspectenv=env.copy();inspectenv['LD_LIBRARY_PATH']=context['LD_LIBRARY_PATH']
artifacts={};ELF=E/'elf';ELF.mkdir(exist_ok=True);depout=E/'compiler-dependencies';depout.mkdir(exist_ok=True)
for kind,rel in [('lib','platforms/linux64GccDPInt32Opt/lib/libdcCartMesh.so'),('app','platforms/linux64GccDPInt32Opt/bin/dcCartMesh'),('probe','platforms/linux64GccDPInt32Opt/bin/dcCartOwnedPreparedProbe')]:
 p=R/rel;assert p.is_file() and not p.is_symlink();artifacts[kind]={'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
 for tool,args in [('readelf',['-h','-d','-n',str(p)]),('ldd',[str(p)])]:
  q=subprocess.run([tool]+args,env=inspectenv,capture_output=True,timeout=30);(ELF/(kind+'.'+tool+'.stdout')).write_bytes(q.stdout);(ELF/(kind+'.'+tool+'.stderr')).write_bytes(q.stderr);assert q.returncode==0
  if tool=='ldd':
   text=q.stdout.decode();assert 'not found' not in text
   if kind!='lib':assert str(R/'platforms/linux64GccDPInt32Opt/lib/libdcCartMesh.so') in text
  artifacts[kind].setdefault('inspection',[]).append({'tool':tool,'stdoutSha256':sha(ELF/(kind+'.'+tool+'.stdout'))})
q=subprocess.run(['nm','-C',str(Path(artifacts['lib']['path']))],env=inspectenv,capture_output=True,timeout=30);(ELF/'lib.nm-C.stdout').write_bytes(q.stdout);assert q.returncode==0 and b'solidShellWindingDegree' in q.stdout and b'solidShellPreparedSnapshot' in q.stdout
units=[];resolved={}
for base in ['src/mesh/dcCartMesh','applications/utilities/mesh/generation/dcCartMesh','.codex-tools/prepared-probe']:
 for dep in sorted((R/base/'Make').rglob('*.dep')):
  text=dep.read_text();dest=depout/dep.relative_to(R);dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(dep.read_bytes());entries=[]
  for token in text.split(':',1)[1].replace('\\\n',' ').split():
   if token in ['\\','#END']:continue
   expanded=re.sub(r'\$\(([^)]+)\)',lambda m:context.get(m.group(1),m.group(0)),token)
   assert '$(' not in expanded,(str(dep),token)
   p=Path(expanded);p=p if p.is_absolute() else R/base/p;p=p.resolve();assert p.is_file(),(str(dep),str(p))
   if 'dcCart' in p.name and p.suffix in ['.H','.C']:assert R in p.parents, str(p)
   ident={'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)};resolved[str(p)]=ident;entries.append(ident)
  obj=dep.with_name(dep.name[:-6]+'.o');assert obj.is_file(),str(obj)
  units.append({'depPath':str(dep),'depSha256':sha(dep),'object':{'path':str(obj),'bytes':obj.stat().st_size,'sha256':sha(obj)},'dependencies':entries})
(E/'ACTUAL_DEPENDENCIES.json').write_text(json.dumps({'units':units,'resolvedFiles':list(resolved.values())},indent=2)+'\n')
result={'scope':'actual clean owned source41+exact-degenerate42 pair/probe; no borrowed project APP/LIB/dependencies','sourceInputs':inputs,'borrowedProjectLibraries':0,'ownedBuildRoot':str(R),'context':context,'sourceFreezeManifestSha256':sha(F/'MANIFEST.json'),'initialBuildResultSha256':sha(E/'BUILD.result.json'),'probeBuildResultSha256':sha(E/'BUILD.result.json'),'actualDependenciesSha256':sha(E/'ACTUAL_DEPENDENCIES.json'),'compileUnits':len(units),'uniqueDependencyFiles':len(resolved),'jobs':2,'affinity':sorted(os.sched_getaffinity(0)),**artifacts}
(E/'COMPILED_BUILD_RECEIPT.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['scope','compileUnits','uniqueDependencyFiles','borrowedProjectLibraries','app','lib','probe']},indent=2))
