#!/bin/bash
set -e
rank=$PMI_RANK
test -n "$rank"
case "$rank" in 0|1|2|3|4|5|6|7) ;; *) exit 93 ;; esac
exec taskset -c "$((16+rank))" /mnt/lv/home/litianyu/mycode/dcdtuni/.codex-tmp/fresh-clone-actual-20261007/dcdtuni/.codex-tmp/envs/dcdtuni/bin/checkMesh -allTopology -allGeometry -parallel > /mnt/lv/home/litianyu/mycode/dcdtuni/.codex-tmp/fresh-clone-actual-20261007/dcdtuni/.codex-tmp/carve-signed-crossing-private-v1/exact-degenerate-private-v1/whole-source42-23eef-finalguard-runtime-v1/logs/checkMesh-rank-${rank}.stdout 2> /mnt/lv/home/litianyu/mycode/dcdtuni/.codex-tmp/fresh-clone-actual-20261007/dcdtuni/.codex-tmp/carve-signed-crossing-private-v1/exact-degenerate-private-v1/whole-source42-23eef-finalguard-runtime-v1/logs/checkMesh-rank-${rank}.stderr
